package com.capgemini.hms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;

public class HotelAdminDaoImp implements IHotelAdminDao {

	Connection conn = DBUtil.getCon();
	IHotelDao hd = new HotelDaoImp();
	static Logger logger = Logger.getRootLogger();
	@Override
	public ArrayList<HotelDetails> viewAllHotel() throws HotelException {
		try {
			ArrayList<HotelDetails> hotelDetails = new ArrayList<>();

			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.HOTEL_ALL);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				HotelDetails hotel = new HotelDetails();
				hotel.setHotel_id(rs.getString(1));
				hotel.setHotel_name(rs.getString(3));
				hotel.setCity(rs.getString(2));
				hotelDetails.add(hotel);
			}
			logger.info("view all hotel function");
			return hotelDetails;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getLocalizedMessage());
			
		}

	}

	@Override
	public ArrayList<UserDetails> viewAllUser() throws HotelException {
		try {
			ArrayList<UserDetails> user = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_ALL_USER);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {

				UserDetails userdetail = new UserDetails();
				userdetail.setUser_id(rs.getString(1));
				userdetail.setRole(rs.getString(3));
				userdetail.setUser_name(rs.getString(4));
				userdetail.setAddress(rs.getString(6));
				userdetail.setPhone(rs.getString(5));
				userdetail.setEmail(rs.getString(7));
				user.add(userdetail);

			}
			logger.info("view all user function");
			return user;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public void addHotel(HotelDetails hotel) throws HotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ADD_HOTEL);
			pstmt.setString(1, hotel.getCity());
			pstmt.setString(2, hotel.getHotel_name());
			pstmt.setString(3, hotel.getAddress());
			pstmt.setString(4, hotel.getDescription());
			pstmt.setFloat(5, hotel.getAvg_rate_per_night());
			pstmt.setString(6, hotel.getPhone_no1());
			pstmt.setString(7, hotel.getPhone_no2());
			pstmt.setString(8, hotel.getRating());
			pstmt.setString(9, hotel.getEmail());
			pstmt.setString(10, hotel.getFax());
			pstmt.executeUpdate();
			logger.info("add hotel function");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.GET_HOTEL_ID);
			pstmt.setString(1, hotel.getHotel_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String hid = rs.getString(1);
				hotel.setHotel_id(hid);
			}
				logger.info("add hotel (got id) function");
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new HotelException(e.getMessage());
		}

	}

	@Override
	public boolean deleteHotel(String id) throws HotelException {
		try {
			boolean a = true;
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryMapper.HOTEL_ALL);
			ResultSet rs = pstmt1.executeQuery();
			while (rs.next()) {
				if ((rs.getString(1)).equals(id)) {
					a = true;
					break;
				} else {
					a = false;
				}
				logger.info("hotel delete function");
			}
			if (a == true) {
				PreparedStatement pstmt = conn
						.prepareStatement(IQueryMapper.DELETE_HOTEL);
				pstmt.setString(1, id);
				pstmt.executeUpdate();
				logger.info("hotel deleted");
				return true;
			} else {
				logger.info("hotel not delted");
				return false;
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public ArrayList<RoomDetails> roomView(String h_id) throws HotelException {

		try {
			ArrayList<RoomDetails> roomdetails = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ROOM_VIEW);
			pstmt.setString(1, h_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					RoomDetails room = new RoomDetails();

					if (h_id.equals(rs.getString(1))) {
						room.setAvailability(rs.getInt(6));
						room.setRoom_no(rs.getString(3));
						room.setPer_night_rate(rs.getFloat(5));
						room.setRoom_id(rs.getString(2));
						room.setRoom_type(rs.getString(4));
						roomdetails.add(room);
					}
				}
			}
			logger.info("room view function ");
			return roomdetails;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public ArrayList<String> displayIds() throws HotelException {
		try {
			ArrayList<String> ids = new ArrayList<String>();
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryMapper.HOTEL_ALL);
			ResultSet rs = pstmt1.executeQuery();
			while (rs.next()) {

				ids.add(rs.getString(1));
			}
			logger.info("display ids function");
			return ids;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public void addRoom(RoomDetails room) throws HotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ADD_ROOM);
			pstmt.setString(1, room.getHotel_id());
			pstmt.setString(2, room.getRoom_no());
			pstmt.setString(3, room.getRoom_type());
			pstmt.setFloat(4, room.getPer_night_rate());
			if (room.getAvailability() == 0)
				pstmt.setString(5, "0");
			else if (room.getAvailability() == 1)
				pstmt.setString(5, "1");
			pstmt.executeUpdate();
			logger.info("add room");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getLocalizedMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ROOM_VIEW);
			pstmt.setString(1, room.getHotel_id());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String rid = rs.getString(2);
				room.setRoom_id(rid);
			}
			logger.info("room id viewed");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public boolean deleteRoom(String room_id) throws HotelException {

		try {
			boolean a = true;
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryMapper.ROOM_ALL);
			ResultSet rs = pstmt1.executeQuery();
			while (rs.next()) {

				if ((rs.getString(1)).equals(room_id)) {
					a = true;
					break;
				} else {
					a = false;
				}
			}
			logger.info("delete room function");
			if (a == true) {
				PreparedStatement pstmt = conn
						.prepareStatement(IQueryMapper.DELETE_ROOM);
				pstmt.setString(1, room_id);
				pstmt.executeUpdate();
				return true;

			} else {
				return false;

			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public ArrayList<BookingDetails> viewBooking(String hotel_id)
			throws HotelException {

		try {
			ArrayList<BookingDetails> booking = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_BOOKING_HOTEL);
			pstmt.setString(1, hotel_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					BookingDetails book = new BookingDetails();
					book.setBooking_id(rs.getString(1));
					book.setRoom_id(rs.getString(2));
					book.setUser_id(rs.getString(3));
					book.setBooked_from(hd.dateChange(rs.getString(4)));
					book.setBooked_to(hd.dateChange(rs.getString(5)));
					book.setNo_of_adults(rs.getInt(6));
					book.setNo_of_children(rs.getInt(7));
					book.setAmount(rs.getFloat(8));
					booking.add(book);
				}
			}
			logger.info(" view bookings function");
			return booking;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public ArrayList<BookingDetails> viewByDate(LocalDate dateChange)
			throws HotelException {

		try {
			ArrayList<BookingDetails> booking = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_BOOKING_BY_DATE);
			pstmt.setDate(1, Date.valueOf(dateChange));
			pstmt.setDate(2, Date.valueOf(dateChange));
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					BookingDetails book = new BookingDetails();
					book.setBooking_id(rs.getString(1));
					book.setRoom_id(rs.getString(2));
					book.setUser_id(rs.getString(3));
					book.setBooked_from(hd.dateChange(rs.getString(4)));
					book.setBooked_to(hd.dateChange(rs.getString(5)));
					book.setNo_of_adults(rs.getInt(6));
					book.setNo_of_children(rs.getInt(7));
					book.setAmount(rs.getFloat(8));
					booking.add(book);
				}
			}
			logger.info("view booking by date");
			return booking;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public ArrayList<String[]> guestList(String hotel_id)
			throws HotelException {
		ArrayList<String[]> guests = new ArrayList<>();
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(IQueryMapper.GUEST_LIST);
			pstmt.setString(1, hotel_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					String[] guest = new String[4];
					guest[1] = rs.getString(1);
					guest[2] = rs.getString(2);
					guest[3] = rs.getString(3);
					guests.add(guest);
				}
			}
			logger.info(" guest list function");
			return guests;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public void modifyHotel(String modify,String name,String id)
			throws HotelException {
		column_name1=name;
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.MODIFY_HOTEL);
			pstmt.setString(1, modify);
			pstmt.setString(2, id);
			pstmt.executeUpdate();
			logger.info("modify hotel function");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getLocalizedMessage());
		}
	}

	static String column_name1="";
	
	@Override
	public HotelDetails viewHotelById(String hotel_id) throws HotelException {
		try {
			HotelDetails hotel = new HotelDetails();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.HOTEL_ALL_ID);
			pstmt.setString(1, hotel_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					hotel.setHotel_name(rs.getString(3));
					hotel.setAvg_rate_per_night(rs.getFloat(6));
					hotel.setDescription(rs.getString(5));
					hotel.setEmail(rs.getString(10));
					hotel.setFax(rs.getString(11));
					hotel.setPhone_no1(rs.getString(7));
					hotel.setPhone_no2(rs.getString(8));
					hotel.setRating(rs.getString(9));

				}
			}
			logger.info("view hotel by id function ");
			return hotel;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getLocalizedMessage());
		}
	}
	
	@Override
	public RoomDetails viewRoomById(String room_id) throws HotelException {
		try {
			RoomDetails room = new RoomDetails();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ROOM_BY_ID);
			pstmt.setString(1, room_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					room.setRoom_no(rs.getString(3));
					room.setRoom_type(rs.getString(4));
					room.setAvailability(rs.getInt(6));
				}
			}
			logger.info("view room by id function ");
			return room;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public void modifyRoom(String room_id, String modify, String column_name)
			throws HotelException {
		column_name1=column_name;
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.MODIFY_ROOM);
			if(column_name.equals("availability"))
			pstmt.setInt(1, Integer.parseInt(modify));
			else
				pstmt.setString(1, modify);
			pstmt.setString(2, room_id);
			pstmt.executeUpdate();
			logger.info("modify room function ");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HotelException(e.getLocalizedMessage());
		}
	}



}
