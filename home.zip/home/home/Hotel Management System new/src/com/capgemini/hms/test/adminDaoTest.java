package com.capgemini.hms.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.hms.exception.HotelException;

public class adminDaoTest {

	@Test
	public void testViewAllHotel() throws HotelException{
		
	}

	@Test
	public void testViewAllUser() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddHotel() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteHotel() {
		fail("Not yet implemented");
	}

	@Test
	public void testRoomView() {
		fail("Not yet implemented");
	}

	@Test
	public void testDisplayIds() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddRoom() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteRoom() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewBooking() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewByDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testGuestList() {
		fail("Not yet implemented");
	}

	@Test
	public void testModifyHotel() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewHotelById() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewRoomById() {
		fail("Not yet implemented");
	}

	@Test
	public void testModifyRoom() {
		fail("Not yet implemented");
	}

}
