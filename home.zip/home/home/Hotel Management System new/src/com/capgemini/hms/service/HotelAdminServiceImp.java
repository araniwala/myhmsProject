package com.capgemini.hms.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.dao.HotelAdminDaoImp;
import com.capgemini.hms.dao.IHotelAdminDao;
import com.capgemini.hms.exception.HotelException;

public class HotelAdminServiceImp implements IHotelAdminService{

	IHotelAdminDao hd1 = new HotelAdminDaoImp();
	IHotelService hs=new HotelServiceImp();
	@Override
	public boolean checklogin(UserDetails user) throws HotelException {
		return false;
	}

	@Override
	public ArrayList<HotelDetails> view_all_hotel() throws HotelException {
		return hd1.view_all_hotel();
	}

	@Override
	public ArrayList<HotelDetails> view_hotel_city(String city) throws HotelException {
		if (hs.isValidName(city) == true)
			return hs.view_hotel_city(city);
		else
			return null;
	}

	@Override
	public ArrayList<UserDetails> view_all_user() throws HotelException {
		return hd1.view_all_user();
	}

	@Override
	public void add_hotel(HotelDetails hotel) throws HotelException {
		hd1.add_hotel(hotel);
	}

	@Override
	public boolean delete_hotel(String id) throws HotelException {
		return hd1.delete_hotel(id);
	}

	@Override
	public ArrayList<RoomDetails> room_view(String h_id) throws HotelException {
		
		return hd1.room_view(h_id);
	}

	@Override
	public ArrayList<String> display_ids() throws HotelException {
		 return hd1.display_ids();
	}

	@Override
	public void add_room(RoomDetails room) throws HotelException {
		hd1.add_room(room);
	}

	@Override
	public boolean delete_room(String room_id) throws HotelException {
		return hd1.delete_room(room_id);
	}

	@Override
	public ArrayList<BookingDetails> view_booking(String hotel_id) throws HotelException {
		return hd1.view_booking(hotel_id);
	}

	@Override
	public ArrayList<BookingDetails> view_by_date(LocalDate dateChange) throws HotelException {
		return hd1.view_by_date(dateChange);
	}

	@Override
	public ArrayList<String[]> guest_list(String hotel_id) throws HotelException {
		return hd1.guest_list(hotel_id);
	}

}
