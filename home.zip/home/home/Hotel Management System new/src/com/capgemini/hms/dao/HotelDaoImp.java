package com.capgemini.hms.dao;

import java.sql.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;

public class HotelDaoImp implements IHotelDao {
	static boolean flag;
	Connection conn = DBUtil.getCon();
	BookingDetails book = new BookingDetails();
	HotelDetails hotel = new HotelDetails();
	static Logger logger = Logger.getRootLogger();

	@Override
	public boolean checkLogin(UserDetails user) throws HotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.USER_LOGIN_QUERY);
			pstmt.setString(1, user.getUser_id());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				flag = false;

			} else {
				while (rs.next()) {
					if (user.getUser_id().equals(rs.getString(1))
							&& user.getPassword().equals(rs.getString(2))) {
						flag = true;
						break;
					}
				}
			}
			logger.info("user details function");
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getLocalizedMessage());
		}

		return flag;
	}

	@Override
	public ArrayList<HotelDetails> viewAllHotel() throws HotelException {

		try {

			ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.HOTEL_ALL);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					HotelDetails hotel = new HotelDetails();
					hotel.setHotel_id(rs.getString(1));
					hotel.setCity(rs.getString(2));
					hotel.setHotel_name(rs.getString(3));
					hotel.setAddress(rs.getString(4));
					hotel.setAvg_rate_per_night(rs.getFloat(6));
					hotel.setDescription(rs.getString(5));
					hotel.setEmail(rs.getString(10));
					hotel.setFax(rs.getString(11));
					hotel.setPhone_no1(rs.getString(7));
					hotel.setPhone_no2(rs.getString(8));
					hotel.setRating(rs.getString(9));
					hotelDetail.add(hotel);
					logger.info("view all hotel of customer dao");
				}
			}
			return hotelDetail;
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public ArrayList<String> roomIds() throws HotelException {
		try {
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryMapper.ROOM_ALL);
			ResultSet rs = pstmt1.executeQuery();
			ArrayList<String> ids = new ArrayList<>();
			while (rs.next()) {

				ids.add(rs.getString(1));

			}
			logger.info("display room ids function");

			return ids;

		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public ArrayList<HotelDetails> viewHotelCity(String city)
			throws HotelException {
		try {
			ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.HOTEL_CITY);
			pstmt.setString(1, city);
			pstmt.setString(2, city);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					HotelDetails hotel = new HotelDetails();
					hotel.setHotel_id(rs.getString(1));
					hotel.setCity(rs.getString(2));
					hotel.setHotel_name(rs.getString(3));
					hotel.setAddress(rs.getString(4));
					hotel.setAvg_rate_per_night(rs.getFloat(6));
					hotel.setDescription(rs.getString(5));
					hotel.setEmail(rs.getString(10));
					hotel.setFax(rs.getString(11));
					hotel.setPhone_no1(rs.getString(7));
					hotel.setPhone_no2(rs.getString(8));
					hotel.setRating(rs.getString(9));
					hotelDetail.add(hotel);
				}
			}
			logger.info("view hotel by city in customer dao");
			return hotelDetail;
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public void registerNewCustomer(UserDetails user) throws HotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.REGISTER_NEW_CUSTOMER);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getRole());
			pstmt.setString(3, user.getUser_name());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getEmail());
			pstmt.executeUpdate();
			logger.info("register new customer function");
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.USERID_GET);
			pstmt.setString(1, user.getUser_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String uid = rs.getString(1);
				user.setUser_id(uid);
				logger.info("get id function");
			}
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public void registerNewEmployee(UserDetails user) throws HotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.REGISTER_NEW_EMPLOYEE);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getRole());
			pstmt.setString(3, user.getUser_name());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.USERID_GET);
			pstmt.setString(1, user.getUser_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String uid = rs.getString(1);
				user.setUser_id(uid);
			}
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public ArrayList<RoomDetails> viewRoomHotel(String name)
			throws HotelException {
		try {
			ArrayList<RoomDetails> roomdetails = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ROOM_HOTEL);
			pstmt.setString(1, name);
			pstmt.setString(2, name);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					RoomDetails room = new RoomDetails();
					room.setAvailability(rs.getInt(6));
					room.setRoom_no(rs.getString(3));
					room.setPer_night_rate(rs.getFloat(5));
					room.setRoom_id(rs.getString(2));
					room.setRoom_type(rs.getString(4));
					roomdetails.add(room);

				}
			}
			return roomdetails;

		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public ArrayList<RoomDetails> roomTypeAvailable(String option)
			throws HotelException {
		try {
			ArrayList<RoomDetails> roomdetails = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ROOM_TYPE_AVAIL);
			pstmt.setString(1, option);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					RoomDetails room = new RoomDetails();
					room.setAvailability(rs.getInt(6));
					room.setRoom_no(rs.getString(3));
					room.setPer_night_rate(rs.getFloat(5));
					room.setRoom_id(rs.getString(2));
					room.setRoom_type(rs.getString(4));
					room.setHotel_name(rs.getString(7));
					roomdetails.add(room);

				}
			}
			return roomdetails;
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public String bookRoom(BookingDetails book) throws HotelException {

		try {
			float amount = 0;
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryMapper.ROOM_AMOUNT);
			pstmt1.setString(1, book.getRoom_id());
			ResultSet rs1 = pstmt1.executeQuery();
			while (rs1.next()) {
				amount = rs1.getFloat(1);
			}

			PreparedStatement pstmt3 = conn
					.prepareStatement(IQueryMapper.BOOKING_VIEW);
			pstmt3.setString(1, book.getRoom_id());
			ResultSet rs2 = pstmt3.executeQuery();
			String room_id = null;
			Date date_from = null;
			
			while (rs2.next()) {
				room_id = rs2.getString(1);
				date_from = rs2.getDate(2);
				
			}
			if (room_id.equals(book.getRoom_id())
					&& (date_from == Date.valueOf(book.getBooked_from()))) {
				return null;
			} else {
				PreparedStatement pstmt = conn
						.prepareStatement(IQueryMapper.BOOK_ROOM);
				pstmt.setString(1, book.getRoom_id());
				pstmt.setString(2, book.getUser_id());
				String booking_id=book.getBooking_id();
				pstmt.setDate(3, Date.valueOf(book.getBooked_from()));
				pstmt.setDate(4, Date.valueOf(book.getBooked_to()));
				pstmt.setInt(5, book.getNo_of_adults());
				pstmt.setInt(6, book.getNo_of_children());
				Period intervalPeriod = Period.between(book.getBooked_from(),
						book.getBooked_to());
				int daysOfStay = intervalPeriod.getDays();
				book.setAmount(amount * daysOfStay);
				pstmt.setFloat(7, amount * daysOfStay);
				pstmt.executeUpdate();

				PreparedStatement pstmt2 = conn
						.prepareStatement(IQueryMapper.BOOKING_BY_USERID_VIEW);
				pstmt2.setString(1, booking_id);
				ResultSet rs = pstmt2.executeQuery();
				while (rs.next()) {
					book.setBooking_id(rs.getString(1));
				}
		}
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getMessage());
		}
		return book.getBooking_id();
	}

	@Override
	public ArrayList<BookingDetails> viewBooking(String user_id)
			throws HotelException {

		try {
			ArrayList<BookingDetails> booking = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.BOOKING_BY_USERID_VIEW);
			pstmt.setString(1, user_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					BookingDetails book = new BookingDetails();
					book.setBooking_id(rs.getString(1));
					book.setRoom_id(rs.getString(2));
					book.setUser_id(rs.getString(3));
					book.setBooked_from(dateChange(rs.getString(4)));
					book.setBooked_to(dateChange(rs.getString(5)));
					book.setNo_of_adults(rs.getInt(6));
					book.setNo_of_children(rs.getInt(7));
					book.setAmount(rs.getFloat(8));
					booking.add(book);
				}
			}
			return booking;
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public LocalDate dateChange(String dateOld) {
		String datearr[] = dateOld.split("/");
		int year = Integer.parseInt(datearr[2]);
		int month = Integer.parseInt(datearr[1]);
		int day = Integer.parseInt(datearr[0]);
		return LocalDate.of(year, month, day);
	}

	@Override
	public boolean checkUserId(String user_id) throws HotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.USERID_CHECK);
			pstmt.setString(1, user_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return false;

			} else {
				while (rs.next()) {
					if (user_id.equals(rs.getString(1))) {
						return true;
					}
				}
				return false;
			}
		} catch (SQLException e) {
			logger.error(e);
			throw new HotelException(e.getLocalizedMessage());
		}

	}

}
