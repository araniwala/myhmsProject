package com.capgemini.hms.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.dao.HotelDaoImp;
import com.capgemini.hms.dao.IHotelDao;
import com.capgemini.hms.exception.HotelException;

public class HotelServiceImp implements IHotelService {

	IHotelDao hd = new HotelDaoImp();

	@Override
	public boolean checklogin(UserDetails user) throws HotelException {

		return hd.checklogin(user);
	}

	@Override
	public ArrayList<HotelDetails> view_all_hotel() throws HotelException {
		return hd.view_all_hotel();

	}

	@Override
	public ArrayList<HotelDetails> view_hotel_city(String city) throws HotelException {
		if (isValidName(city) == true)
			return hd.view_hotel_city(city);
		else
		return null;
	}

	@Override
	public void register_new_customer(UserDetails user) throws HotelException {
		hd.register_new_customer(user);
	}

	@Override
	public void register_new_employee(UserDetails user) throws HotelException {
		hd.register_new_employee(user);
	}

	@Override
	public ArrayList<RoomDetails> view_room_hotel(String name) throws HotelException {
		if (isValidName(name) == true)
			return hd.view_room_hotel(name);
		else
			return null;
	}

	@Override
	public boolean isValidName(String name) {
		Pattern p = Pattern.compile("^[A-Za-z\\s]{1,}$");
		Matcher m = p.matcher(name);
		return m.matches();
	}

	@Override
	public boolean isValidUser(String user) {
		Pattern p = Pattern.compile("^(emp|cus|emp)[0-9]{1,2}$");
		Matcher m = p.matcher(user);
		return m.matches();
	}

	@Override
	public boolean isValidHotel_id(String hotel_id) {
		Pattern p = Pattern.compile("^(hot)[0-9]{1,2}$");
		Matcher m = p.matcher(hotel_id);
		return m.matches();
	}
	
	@Override
	public boolean isValidNumber(String phone) {
		Pattern p = Pattern.compile("(9|8|7){1}[0-9]{9}$");
		Matcher m = p.matcher(phone);
		return m.matches();
	}

	@Override
	public boolean isValidEmail(String email) {
		Pattern p = Pattern
				.compile("[A-Za-z0-9]{1,20}@[A-Za-z0-9]{1,7}.[a-z]{1,3}$");
		Matcher m = p.matcher(email);
		return m.matches();
	}

	@Override
	public ArrayList<RoomDetails> room_type_available(String option) throws HotelException {
		return hd.room_type_available(option);
	}

	@Override
	public String book_room(BookingDetails book) throws HotelException {
		return hd.book_room(book);
	}

	@Override
	public ArrayList<BookingDetails> view_booking(String user_id) throws HotelException {
		return hd.view_booking(user_id);
	}
	@Override
	public LocalDate dateChange(String dateOld)
	{
		return hd.dateChange(dateOld);
	}

	@Override
	public boolean isValidDate(String date) {
		Pattern p = Pattern
				.compile("([0-2]{1}[0-9]{1}|(3)[0-1]{1})\\/((0)[0-9]{1}|(1)[0-2])\\/[0-9]{4}");
		Matcher m = p.matcher(date);
		return m.matches();
	}

	@Override
	public boolean todayDate(LocalDate date) { 
		
		if(date.isEqual(LocalDate.now()) || date.isAfter(LocalDate.now()))
			return true;
		else
			return false;
	}

	@Override
	public boolean check_userid(String user_id) throws HotelException {
		return hd.check_userid(user_id);
	}

	@Override
	public ArrayList<String> room_ids() throws HotelException {
		return hd.room_ids();
	}

	@Override
	public boolean isValidUserName(String user_name) throws HotelException {
		Pattern p = Pattern
				.compile("[a-zA-Z]{20}");
		Matcher m = p.matcher(user_name);
		return m.matches();
	}

	@Override
	public boolean isValidPassword(String password) throws HotelException {
		Pattern p = Pattern
				.compile("[a-zA-Z0-9]{7}");
		Matcher m = p.matcher(password);
		return m.matches();
	}

	@Override
	public boolean isValidAddress(String address) throws HotelException {
		Pattern p = Pattern
				.compile("[a-zA-Z0-9#]{25}");
		Matcher m = p.matcher(address);
		return m.matches();
	}
	
}
