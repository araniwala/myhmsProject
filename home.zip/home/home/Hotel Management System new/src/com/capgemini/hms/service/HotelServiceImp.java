package com.capgemini.hms.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.dao.HotelDaoImp;
import com.capgemini.hms.dao.IHotelDao;
import com.capgemini.hms.exception.HotelException;

public class HotelServiceImp implements IHotelService {

	IHotelDao hd = new HotelDaoImp();

	@Override
	public boolean checkLogin(UserDetails user) throws HotelException {

		return hd.checkLogin(user);
	}

	@Override
	public ArrayList<HotelDetails> viewAllHotel() throws HotelException {
		return hd.viewAllHotel();

	}

	@Override
	public ArrayList<HotelDetails> viewHotelByCity(String city) throws HotelException {
		if (isValidName(city) == true)
			return hd.viewHotelCity(city);
		else
		return null;
	}

	@Override
	public void registerNewCustomer(UserDetails user) throws HotelException {
		hd.registerNewCustomer(user);
	}

	@Override
	public void registerNewEmployee(UserDetails user) throws HotelException {
		hd.registerNewEmployee(user);
	}

	@Override
	public ArrayList<RoomDetails> viewRoomHotel(String name) throws HotelException {
		if (isValidName(name) == true)
			return hd.viewRoomHotel(name);
		else
			return null;
	}

	@Override
	public boolean isValidName(String name) {
		Pattern p = Pattern.compile("^[A-Za-z\\s]{1,}$");
		Matcher m = p.matcher(name);
		return m.matches();
	}

	@Override
	public boolean isValidUser(String user) {
		Pattern p = Pattern.compile("^(emp|cus|emp)[0-9]{1,2}$");
		Matcher m = p.matcher(user);
		return m.matches();
	}

	@Override
	public boolean isValidHotel_id(String hotel_id) {
		Pattern p = Pattern.compile("^(hot)[0-9]{1,2}$");
		Matcher m = p.matcher(hotel_id);
		return m.matches();
	}
	
	@Override
	public boolean isValidNumber(String phone) {
		Pattern p = Pattern.compile("(9|8|7){1}[0-9]{9}$");
		Matcher m = p.matcher(phone);
		return m.matches();
	}
	
	@Override
	public boolean isValidRoom_id(String room_id) {
		Pattern p = Pattern.compile("(room)[0-9]{1,2}$");
		Matcher m = p.matcher(room_id);
		return m.matches();
	}

	@Override
	public boolean isValidEmail(String email) {
		Pattern p = Pattern
				.compile("^ [_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		Matcher m = p.matcher(email);
		return m.matches();
	}

	@Override
	public ArrayList<RoomDetails> roomTypeAvailable(String option) throws HotelException {
		return hd.roomTypeAvailable(option);
	}

	@Override
	public String bookRoom(BookingDetails book) throws HotelException {
		return hd.bookRoom(book);
	}

	@Override
	public ArrayList<BookingDetails> viewBooking(String user_id) throws HotelException {
		return hd.viewBooking(user_id);
	}
	@Override
	public LocalDate dateChange(String dateOld)
	{
		return hd.dateChange(dateOld);
	}

	@Override
	public boolean isValidDate(String date) {
		Pattern p = Pattern
				.compile("([0-2]{1}[0-9]{1}|(3)[0-1]{1})\\/((0)[0-9]{1}|(1)[0-2])\\/[0-9]{4}");
		Matcher m = p.matcher(date);
		return m.matches();
	}
	
	@Override
	public boolean todayDate(LocalDate date) { 
		
		if(date.isEqual(LocalDate.now()) || date.isAfter(LocalDate.now()))
			return true;
		else
			return false;
	}

	@Override
	public boolean checkUserId(String user_id) throws HotelException {
		return hd.checkUserId(user_id);
	}

	@Override
	public ArrayList<String> roomIds() throws HotelException {
		return hd.roomIds();
	}

	@Override
	public boolean isValidUserName(String user_name) throws HotelException {
		Pattern p = Pattern
				.compile("[a-zA-Z\\s]{1,20}");
		Matcher m = p.matcher(user_name);
		return m.matches();
	}

	@Override
	public boolean isValidHotelName(String hotel_name) throws HotelException {
		Pattern p = Pattern
				.compile("[a-zA-Z0-9\\s]{1,20}");
		Matcher m = p.matcher(hotel_name);
		return m.matches();
	}
	
	@Override
	public boolean isValidPassword(String password) throws HotelException {
		Pattern p = Pattern
				.compile("[a-zA-Z0-9]{1,7}");
		Matcher m = p.matcher(password);
		return m.matches();
	}

	@Override
	public boolean isValidAddress(String address) throws HotelException {
		Pattern p = Pattern
				.compile("[a-zA-Z0-9,#\\s\\/]{1,25}");
		Matcher m = p.matcher(address);
		return m.matches();
	}

	@Override
	public boolean isValidDesc(String desc) throws HotelException {
		Pattern p = Pattern
				.compile("[a-zA-Z0-9#\\s]{1,50}");
		Matcher m = p.matcher(desc);
		return m.matches();
	}

	@Override
	public boolean isValidRating(String rating) {
		Pattern p = Pattern
				.compile("[0-5]{1}[\\.]{0,1}[0-5]{0,2}");
		Matcher m = p.matcher(rating);
		return m.matches();
	}

	
	
}
