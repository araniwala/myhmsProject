package com.capgemini.hms.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;

//------------------------ Hotel Management System --------------------------
	/*******************************************************************************************************
	 - Interface Name	:	IHotelService (Service interface for customer and employee)
	 - Throws			:  	hotelException
	 - Author			:	Anisha
	 - Creation Date	:	03/09/2018
	 - Description		:	function signatures for customer/employee.
	 ********************************************************************************************************/


public interface IHotelService {

	public abstract boolean checkLogin(UserDetails user) throws HotelException;

	public abstract ArrayList<HotelDetails> viewAllHotel() throws HotelException;

	public abstract ArrayList<HotelDetails> viewHotelByCity(String city)
			throws HotelException;

	public abstract void registerNewCustomer(UserDetails user)
			throws HotelException;

	public abstract void registerNewEmployee(UserDetails user)
			throws HotelException;

	public abstract ArrayList<RoomDetails> viewRoomHotel(String name) throws HotelException;

	public abstract boolean isValidName(String name);

	public abstract boolean isValidUser(String user);

	public abstract boolean isValidNumber(String phone);

	public abstract boolean isValidEmail(String email);
	
	public abstract boolean isValidDate(String date);

	public abstract ArrayList<RoomDetails> roomTypeAvailable(String option) throws HotelException;

	public abstract String bookRoom(BookingDetails book) throws HotelException;

	public abstract ArrayList<BookingDetails> viewBooking(String user_id)
			throws HotelException;

	public abstract LocalDate dateChange(String dateOld);
	
	public abstract boolean todayDate(LocalDate dateOld);

	public abstract boolean checkUserId(String user_id) throws HotelException;
	
	public abstract ArrayList<String> roomIds() throws HotelException;

	public abstract boolean isValidHotel_id(String hotel_id) throws HotelException;

	public abstract boolean isValidUserName(String user_name) throws HotelException;

	public abstract boolean isValidPassword(String password) throws HotelException;
	
	public abstract boolean isValidAddress(String address) throws HotelException;
	
	public abstract boolean isValidDesc(String desc) throws HotelException;

	public abstract boolean isValidHotelName(String hotel_name) throws HotelException;

	public abstract boolean isValidRoom_id(String room_id);
	
	public abstract boolean isValidRating(String rating);
	
}
