package com.capgemini.hms.management;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;





import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;
import com.capgemini.hms.login.LoginUsers;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

public class Management {
	static Scanner scanner = null;
	static BufferedReader buffer = null;
	static UserDetails user = new UserDetails();
	static HotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static LoginUsers uLogin = null;

	static Logger logger = Logger.getRootLogger();
	static Management mngmt = null;
	static RoomDetails room = null;
	static BookingDetails book = null;

	public boolean hotelMngmt() throws HotelException {
		scanner = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		buffer = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("--------------------------");
			System.out
					.println("||Hotel Management Tasks:||\n[1]:Add Hotel\n [2]:Delete Hotel\n [3]:Modify Hotel\n [4]:To exit");
			System.out.println("--------------------------");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1: {
				System.out.print("Enter the Details for The hotel");
				System.out.print("Hotel Name(20 characters):");
				String name = buffer.readLine();
				while (service.isValidHotelName(name) == false) {
					System.out.println("Enter valid name");
					name = buffer.readLine();
				}
				hotel.setHotel_name(name);
				System.out.print("City(10 characters):");
				String city = buffer.readLine();
				while (service.isValidName(city) == false) {
					System.out.print("Enter valid city");
					city = buffer.readLine();
				}
				hotel.setCity(city);
				System.out.print("Address:(25 characters)");
				String address = buffer.readLine();
				while (service.isValidAddress(address) == false) {
					System.out.println("Enter valid address");
					address = buffer.readLine();
				}
				hotel.setAddress(address);
				System.out.print("Description(50 characters):");
				String desc = buffer.readLine();
				while (service.isValidDesc(desc) == false) {
					System.out.println("Enter valid description");
					desc = buffer.readLine();
				}
				hotel.setDescription(desc);

				System.out.print("Average Rate Per night:");
				float rate = scanner.nextFloat();
				hotel.setAvg_rate_per_night(rate);
				System.out.print("Phone Number 1:");
				String phone1 = buffer.readLine();
				while (service.isValidNumber(phone1) == false) {
					System.out.print("Enter valid phone number");
					phone1 = buffer.readLine();
				}
				hotel.setPhone_no1(phone1);
				System.out.print("Phone Number 2:");
				String phone2 = buffer.readLine();
				while (service.isValidNumber(phone2) == false) {
					System.out.print("Enter valid phone number");
					phone2 = buffer.readLine();
				}
				hotel.setPhone_no2(phone2);
				System.out.print("Rating:");
				String rating = buffer.readLine();
				hotel.setRating(rating);
				System.out.print("Email:");
				String email = buffer.readLine();
				while (service.isValidEmail(email) == false) {
					System.out.print("Enter valid email");
					email = buffer.readLine();
				}
				hotel.setEmail(email);
				System.out.print("Fax:");
				String fax = buffer.readLine();
				while (service.isValidNumber(fax) == false) {
					System.out.print("Enter valid fax number");
					fax = buffer.readLine();
				}
				hotel.setFax(fax);

				s_admin.addHotel(hotel);

				System.out.println("Hotel ID for the added hotel is:"
						+ hotel.getHotel_id());

			}
				break;
			case 2: {
				ArrayList<String> ids = new ArrayList<String>();
				System.out.println("Available hotel IDs are:");
				ids = s_admin.displayIds();
				for (String id1 : ids) {
					System.out.println(id1);
				}
				System.out.print("Enter the hotel Id to be deleted");
				String id = buffer.readLine();
				boolean flag = s_admin.deletehotel(id);
				if (flag == true) {
					System.out.println("Hotel with ID: " + id + " is delted");
				} else {
					System.out.println("Entered ID does not exist");
				}
			}
				break;

			case 3: {
				ArrayList<String> ids = new ArrayList<>();
				System.out.println("Available hotel ids are:");
				ids = s_admin.displayIds();
				for (String id : ids) {
					System.out.println(id);
				}
				System.out.println("Enter the hotel Id to be modify");
				String id = buffer.readLine();
				while (service.isValidHotel_id(id) == false) {
					System.out.println("Enter valid hotel id");
					id = buffer.readLine();
				}
				hotel = s_admin.viewHotelById(id);
				if (hotel == null) {
					System.out.println("Id does not exist");
				} else {
					String option = "";
					do {
						System.out
								.println("Select things you want to change about this hotel");
						System.out.println("[1] Hotel Name");
						System.out.println("[2] Description");
						System.out.println("[3] Fax");
						System.out.println("[4] Phone Number 1");
						System.out.println("[5] Phone Number 2");
						System.out.println("[6] Rating");
						System.out.println("[7] E-mail");
						System.out.println("[8] Exit");
						System.out.print("Choose one:");
						option = buffer.readLine();
						switch (option) {
						case "1": {
							System.out.println("Present Hotel Name is: "
									+ hotel.getHotel_name());
							System.out.println("Enter the new name: ");
							String hotel_name = buffer.readLine();
							while (service.isValidHotelName(hotel_name) == false) {
								System.out.println("Enter valid hotel name:");
								hotel_name = buffer.readLine();
							}
							s_admin.modifyHotel(hotel_name, "hotel_name", id);
						}
							break;
						case "2": {
							System.out.println("Present Hotel Description:"
									+ hotel.getDescription());
							System.out.println("Enter new description");
							String description = buffer.readLine();
							while (service.isValidDesc(description) == false) {
								System.out.println("Enter valid description:");
								description = buffer.readLine();
							}

							s_admin.modifyHotel(description, "description", id);
						}
							break;
						case "4": {
							System.out.println("Present Hotel phone number 1:"
									+ hotel.getPhone_no1());
							System.out.println("Enter new phone number 1");
							String phone = buffer.readLine();
							while (service.isValidNumber(phone) == false) {
								System.out.println("Enter valid phone number:");
								phone = buffer.readLine();
							}
							s_admin.modifyHotel(phone, "phone_no1", id);
						}
							break;
						case "5": {
							System.out.println("Present Hotel phone number 2:"
									+ hotel.getPhone_no1());
							System.out.println("Enter new phone number 2");
							String phone = buffer.readLine();
							while (service.isValidNumber(phone) == false) {
								System.out.println("Enter valid phone number:");
								phone = buffer.readLine();
							}
							s_admin.modifyHotel(phone, "phone_no2", id);
						}
							break;
						case "3": {
							System.out.println("Present Hotel fax number:"
									+ hotel.getPhone_no1());
							System.out.println("Enter new fax number");
							String phone = buffer.readLine();
							while (service.isValidNumber(phone) == false) {
								System.out.println("Enter valid fax number:");
								phone = buffer.readLine();
							}
							s_admin.modifyHotel(phone, "fax", id);
						}
							break;
						case "6": {
							System.out.println("Present Hotel rating:"
									+ hotel.getRating());
							System.out.println("Enter new rating");
							String rating = buffer.readLine();
							while (service.isValidRating(rating) == false) {
								System.out.println("Enter valid rating");
								rating = buffer.readLine();
							}
							s_admin.modifyHotel(rating, "rating", id);
						}
							break;
						case "7": {
							System.out.println("Present Hotel E-mail:"
									+ hotel.getPhone_no1());
							System.out.println("Enter new E-mail");
							String email = buffer.readLine();
							while (service.isValidEmail(email) == false) {
								System.out.println("Enter valid email:");
								email = buffer.readLine();
							}
							s_admin.modifyHotel(email, "email", id);
						}
							break;

						}
					} while (Integer.parseInt(option) > 0
							&& Integer.parseInt(option) < 8);
				}
			}
				break;
			case 4: {
				return false;
			}

			}

		} catch (InputMismatchException e) {
			logger.error(e);
			System.out.println("Try again");
			hotelMngmt();
		} catch (IOException e) {
			logger.error(e);
			System.out.println("Try again");
			hotelMngmt();
		}
		return true;
	}

	public boolean roomMngmt() throws HotelException {
		scanner = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		room = new RoomDetails();
		mngmt = new Management();
		buffer = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out
					.println("||Room Management Tasks:|| \n[1]:View Rooms\t [2]:Add Room\t [3]:Delete Room\t [4]:Modify Room\t [5]:To exit");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1: {
				ArrayList<RoomDetails> roomdetails = new ArrayList<>();

				s_admin.displayIds();
				System.out.print("Enter the hotel ID, to view rooms");
				String h_id = buffer.readLine();
				roomdetails = s_admin.roomView(h_id);
				if (roomdetails == null) {
					System.out.println("No rooms in this hotel.");
				} else {
					System.out.format("\n%-10s %-12s %-20s %30s", "Room id",
							"Room number", "Room Type", "Room rate per night");
					System.out.println();
					System.out
							.println("------------------------------------------------------------------------------------------");
					
					for (RoomDetails room : roomdetails) {
						System.out.format("\n%-10s %-12s %-20s %30s",
								room.getRoom_id(), room.getRoom_no(),
								room.getRoom_type(), room.getPer_night_rate());

					}
				}
			}
				break;
			case 2: {
				s_admin.displayIds();
				System.out.println("Enter details of the room to be added");

				System.out.println("Avaialable hotel Ids are:");
				ArrayList<String> ids = new ArrayList<>();

				ids = s_admin.displayIds();
				for (String id : ids) {
					System.out.println(id);
				}
				System.out.print("Enter the hotel ID:");
				String hotel_id = buffer.readLine();
				while (service.isValidHotel_id(hotel_id) == false) {
					System.out.println("Enter valid hotel Id");
					hotel_id = buffer.readLine();
				}
				room.setHotel_id(hotel_id);
				System.out.print("Enter the room number:");
				String room_no = buffer.readLine();
				room.setRoom_no(room_no);
				System.out.print("Enter the room type:(choose one)");
				System.out.println("[1] AC-Delux");
				System.out.println("[2] Non-AC-Delux");
				System.out.println("[3] AC-Standard");
				System.out.println("[4] Non-AC-Standard");
				int choose = scanner.nextInt();
				if (choose == 1)
					room.setRoom_type("AC-Delux");
				else if (choose == 2)
					room.setRoom_type("Non-AC-Delux");
				else if (choose == 3)
					room.setRoom_type("AC-Standard");
				else if (choose == 4)
					room.setRoom_type("Non-AC-Standard");
				else
					System.out.print("choose one of the above");

				System.out.print("Enter the rate per night");
				float rate = scanner.nextFloat();
				room.setPer_night_rate(rate);
				System.out.print("Enter the Availability:(choose one)");
				System.out.print("[0] Avaialable");
				System.out.println("[1] Unavaialable");
				int choose1 = scanner.nextInt();
				if (choose1 == 0)
					room.setAvailability(0);
				else if (choose1 == 1)
					room.setAvailability(1);
				else
					System.out.print("choose correctly");

				s_admin.addRoom(room);

				System.out.println("Room ID for the added room is:"
						+ room.getRoom_id());
			}
				break;
			case 3: {
				String room_id=null;
				System.out.println("available room ids are:");
				ArrayList<String> ids = new ArrayList<>();
				ids = service.roomIds();
				for (String id : ids) {
					System.out.println(id);
				}
				System.out.print("enter the room Id to be deleted");
				 room_id = buffer.readLine();
				while (service.isValidRoom_id(room_id) == false) {
					System.out.println("Enter valid room id");
					room_id = buffer.readLine();
				}
				boolean flag = s_admin.deleteRoom(room_id);
				if (flag == true) {
					System.out.println("room with id " + room_id
							+ " is deleted");
				} else
					System.out.println("Room ID does not exist");
			}
				break;
			case 4: {
				System.out.println("available room ids are:");
				ArrayList<String> ids = new ArrayList<>();
				ids = service.roomIds();
				if(ids==null)
				{
					System.out.println("no room availabel");
				}
				else{
				for (String id : ids) {
					System.out.println(id);
				}}
				System.out.println("Enter room Id to be modified");
				String room_id = buffer.readLine();
				while (service.isValidRoom_id(room_id) == false) {
					System.out.println("Enter valid room id");
					room_id = buffer.readLine();
				}
				room = s_admin.viewRoomById(room_id);
				if (room == null) {
					System.out.println("room does not exist");
				} else {
					System.out.println("Choose what you need to modify:");
					System.out.println("[1] Room Number");
					System.out.println("[2] Room Type");
					System.out.println("[3] Availability");
					System.out.println("[4] Exit");
					System.out.print("Select one:");
					String ch = buffer.readLine();
					switch (ch) {

					case "1": {
						System.out.println("present Room number:"
								+ room.getRoom_no());
						System.out
								.println("Enter new room number:(max 3 characters)");
						String room_no = buffer.readLine();
						s_admin.modifyRoom(room_id, room_no, "room_no");

					}
						break;
					case "2": {
						System.out.println("Present Room type:"
								+ room.getRoom_type());
						System.out.print("Enter the room type:(choose one)");
						System.out.println("[1] AC-Delux");
						System.out.println("[2] Non-AC-Delux");
						System.out.println("[3] AC-Standard");
						System.out.println("[4] Non-AC-Standard");
						int choose = scanner.nextInt();
						String room_type = "";
						if (choose == 1)
							room_type = "AC-Delux";
						else if (choose == 2)
							room_type = "Non-AC-Delux";
						else if (choose == 3)
							room_type = "AC-Standard";
						else if (choose == 4)
							room_type = "Non-AC-Standard";
						else
							System.out.print("choose one of the above");
						s_admin.modifyRoom(room_id, room_type, "room_no");
					}
						break;
					case "3": {
						String room_avail = "";
						System.out.println("Present Availability:");
						System.out.print("Enter the Availability:(choose one)");
						System.out.print("[0] Avaialable");
						System.out.println("[1] Unavaialable");
						int choose1 = scanner.nextInt();
						if (choose1 == 0)
							room_avail = "0";
						else if (choose1 == 1)
							room_avail = "1";
						else
							System.out.print("choose correctly");
						s_admin.modifyRoom(room_id, room_avail, "availability");
					}
						break;
					}
				}
			}
				break;
			case 5:
				return false;
			}
		} catch (InputMismatchException e) {
			logger.error(e);
			System.out.println("Try again");
			roomMngmt();
			
		} catch (IOException e) {
			logger.error(e);
			System.out.println("Try again");
			roomMngmt();
			
		}
		return true;
	}

	public void bookingMngmt(String user_id) throws HotelException {
		scanner = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		book = new BookingDetails();
		buffer = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out
					.println("--------------------------------------------------------------------------");
			System.out.println("||Press [1] to show rooms by hotel name\t||");
			System.out.println("||Press [2] to show rooms by type||");
			System.out.println("||Press [3] to exit||");
			System.out
					.println("--------------------------------------------------------------------------");
			int option1 = scanner.nextInt();
			switch (option1) {
			default: {
				System.err.println("Enter valid option");
				bookingMngmt(user_id);
			}
			case 1: {
				System.out
						.println("Enter the hotel name in which you need rooms");
				ArrayList<RoomDetails> roomdetails = new ArrayList<>();

				String name = buffer.readLine();
				roomdetails = service.viewRoomHotel(name);
				if (roomdetails == null) {
					System.err
							.println("Either we don't provide service with this hotel or no rooms in this hotel. Please try another hotel. Thank you!!!");
				} else {
					System.out.format("\n%-10s %-12s %-20s %30s", "Room id",
							"Room number", "Room Type", "Room rate per night");
					System.out.println();
					System.out
							.println("------------------------------------------------------------------------------------------");
					
					for (RoomDetails room : roomdetails) {
						System.out.format("\n%-10s %-12s %-20s %30s",
								room.getRoom_id(), room.getRoom_no(),
								room.getRoom_type(), room.getPer_night_rate());
					}
					System.out.println();
					System.out.println("----------------------------------------");
					System.out
							.println("Press [1] to make booking of selected room");
					System.out.println("Press [2] to go to previous menu");
					System.out.println("----------------------------------------");
					int ch = scanner.nextInt();
					if (ch == 1) {
						booking(user_id);
					} else if (ch == 2)
						bookingMngmt(user_id);
					else {
						System.out.println("enter valid option");
						ch = scanner.nextInt();
					}

				}

			}
				break;
			case 2: {
				ArrayList<RoomDetails> roomdetails = new ArrayList<>();
				System.out.println("Select one of the room types:");
				System.out
						.println("[1] AC-Delux\t[2] Non-AC-Delux\t[3] AC-standard\t[4] Non-AC-standard");
				int option = scanner.nextInt();
				if (option == 1)
					roomdetails = service.roomTypeAvailable("AC-Delux");
				else if (option == 2)
					roomdetails = service.roomTypeAvailable("Non-AC-Delux");
				else if (option == 3)
					roomdetails = service.roomTypeAvailable("AC-standard");
				else if (option == 4)
					roomdetails = service.roomTypeAvailable("Non-AC-standard");
				else
					System.out.println("select a valid option");

				if (roomdetails == null) {
					System.out.println("No rooms of this type");
				} else {
					System.out.format("\n%-10s %-12s %-20s %30s", "Room id",
							"Room number", "Room Type", "Room rate per night");
					System.out.println();
					System.out
							.println("------------------------------------------------------------------------------------------");
					
					for (RoomDetails room : roomdetails) {

						System.out.format("\n%-10s %-12s %-20s %30s",
								room.getRoom_id(), room.getRoom_no(),
								room.getRoom_type(), room.getPer_night_rate());

					}
					System.out.println();
					System.out.println("----------------------------------------");
					System.out
							.println("Press [1] to make booking of selected room");
					System.out.println("Press [2] to go to previous menu");
					System.out.println("----------------------------------------");
					int ch = scanner.nextInt();
					if (ch == 1) {
						booking(user_id);
					} else if (ch == 2)
						bookingMngmt(user_id);
					else {
						System.out.println("enter valid option");
						ch = scanner.nextInt();
					}
				}

			}
				break;
			case 3: {
				System.out.println("you are logged out");
				System.exit(0);
			}
				break;

			}
		} catch (InputMismatchException e) {
			logger.error(e);
			System.out.println("Try again");
			bookingMngmt(user_id);
			
		} catch (IOException e) {
			logger.error(e);
			System.out.println("Try again");
			bookingMngmt(user_id);
			
		}
	}

	public void booking(String user_id) throws HotelException {
		scanner = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		book = new BookingDetails();
		buffer = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Enter the room Id you want to book");
			String room_id = buffer.readLine();
			while (service.isValidRoom_id(room_id) == false) {
				System.out.println("Enter valid room id");
				room_id = buffer.readLine();
			}
			book.setRoom_id(room_id);
			System.out.println("Enter the date to book from (dd/mm/yyyy)");
			String startDate = buffer.readLine();
			while (service.isValidDate(startDate) == false) {
				System.out
						.println("Enter valid Date in the given format: (dd/mm/yyyy)");
				startDate = buffer.readLine();
			}
			LocalDate date = service.dateChange(startDate);
			if (date.isEqual(LocalDate.now()) || date.isAfter(LocalDate.now())) {
				book.setBooked_from(date);
			} else {
				System.out
						.println("Booking intial date should be today or date after today");
				startDate = buffer.readLine();
				while (service.isValidDate(startDate) == false) {
					System.out
							.println("Enter valid Date in the given format: (dd/mm/yyyy)");
					startDate = buffer.readLine();
				}
			}
			System.out.println("Enter the date to book till (dd/mm/yyyy)");
			String endDate = buffer.readLine();
			while (service.isValidDate(endDate) == false) {
				System.out
						.println("Enter valid Date in the given format: (dd/mm/yyyy)");
				endDate = buffer.readLine();
			}
			LocalDate to_date = service.dateChange(endDate);
			if (to_date.isEqual(date) || to_date.isBefore(date)) {
				System.out
						.println("Booking till date should be one or more day(s) after booking date");
				endDate = buffer.readLine();
				while (service.isValidDate(endDate) == false) {
					System.out
							.println("Enter valid Date in the given format: (dd/mm/yyyy)");
					endDate = buffer.readLine();
				}
			} else {

				book.setBooked_to(to_date);
			}
			System.out.println("enter the number of adults");
			int no_adult = scanner.nextInt();
			while(no_adult>3)
			{
				System.out.println("Number of adults in one room can be max 3");
				no_adult = scanner.nextInt();
			}
			book.setNo_of_adults(no_adult);
			System.out.println("Enter the number of children");
			int no_child = scanner.nextInt();
			while(no_child>5)
			{
				System.out.println("Number of children in one room can be max 5");
				no_child = scanner.nextInt();
			}
			book.setNo_of_children(no_child);
			book.setUser_id(user_id);
			String book_id = service.bookRoom(book);
			if (book_id == null) {
				System.out
						.println("this room is not available try other dates");
			} else {
				System.out
						.println("------------------------------------------------------------");
				System.out.println("your booking id is:" + book_id);
				System.out.println("You've booked the room from: "
						+ book.getBooked_from() + " to:" + book.getBooked_to()
						+ " for amount: " + book.getAmount() + " for "
						+ book.getNo_of_adults() + " adults and "
						+ book.getNo_of_children() + " children.");
				System.out
						.println("------------------------------------------------------------");
			}
		} catch (InputMismatchException e) {
			logger.error(e);
			System.out.println("try again");
			booking(user_id);
		} catch (IOException e) {
			logger.error(e);
			System.out.println("try again");
			booking(user_id);
		}
	}
}
