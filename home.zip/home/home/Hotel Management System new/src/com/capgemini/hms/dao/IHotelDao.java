package com.capgemini.hms.dao;

import java.time.LocalDate;

//------------------------ Hotel Management System --------------------------
	/*******************************************************************************************************
	 - Interface Name	:	IHotelDao (Dao interface for customer and employee)
	 - Throws			:  	hotelException
	 - Author			:	Anisha
	 - Creation Date	:	03/09/2018
	 - Description		:	function signatures for customer/employee.
	 ********************************************************************************************************/

import java.util.ArrayList;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;

public interface IHotelDao {
	public abstract boolean checkLogin(UserDetails user) throws HotelException;

	public abstract ArrayList<HotelDetails> viewAllHotel() throws HotelException;

	public abstract ArrayList<HotelDetails> viewHotelCity(String city) throws HotelException;

	public abstract void registerNewCustomer(UserDetails user) throws HotelException;

	public abstract void registerNewEmployee(UserDetails user) throws HotelException;

	public abstract ArrayList<RoomDetails> viewRoomHotel(String name) throws HotelException;

	ArrayList<RoomDetails> roomTypeAvailable(String option) throws HotelException;

	public abstract String bookRoom(BookingDetails book) throws HotelException;

	public abstract ArrayList<BookingDetails> viewBooking(String user_id) throws HotelException;

	public abstract LocalDate dateChange(String dateOld);

	public abstract boolean checkUserId(String user_id) throws HotelException;

	public abstract ArrayList<String> roomIds() throws HotelException;

	

}
