/*USER TABLE CREATION*/
CREATE TABLE USERS (user_id varchar(6) PRIMARY KEY,
password varchar(7),
role varchar(10),
user_name varchar (20),
phone varchar(10),
address varchar(25),
email varchar(15));


/*HOTEL TABLE CREATION*/
CREATE TABLE HOTEL (hotel_id varchar(6) PRIMARY KEY,
city varchar(10),
hotel_name varchar (20),
address varchar(25),
description varchar(50),
avg_rate_per_night number(10,2),
phone_no1 varchar(10),
phone_no2 varchar(10),
rating varchar(4),
email varchar(30),
fax varchar(15));



/*Room Details table creation*/
CREATE TABLE ROOM_DETAILS(
hotel_id varchar(6) REFERENCES HOTEL(hotel_id) on delete cascade,
room_id varchar(6) PRIMARY KEY,
room_no varchar(3),
room_type varchar(20),
per_night_rate number(10,2),
availability varchar(1));




/*booking_details table creation*/
CREATE TABLE BOOKING_DETAILS(
booking_id varchar(6) PRIMARY KEY,
room_id varchar(6) REFERENCES room_details(room_id) on delete cascade,
user_id varchar(6) REFERENCES users(user_id) on delete cascade,
booked_from date,
booked_to date,
no_of_adults number(2),
no_of_children number(2),
amount number(6,2));



/*sequences*/

CREATE SEQUENCE user_id_cust start with 01 increment by 1;

CREATE SEQUENCE user_id_staff start with 01 increment by 1;

CREATE SEQUENCE user_id_admin start with 01 increment by 1;

CREATE SEQUENCE hotel_id_seq start with 01 increment by 1;

CREATE SEQUENCE room_id_seq start with 01 increment by 1;

CREATE SEQUENCE booking_seq start with 100001 increment by 1;

/*drop*/
 drop table room_details;
 drop table booking_details;

