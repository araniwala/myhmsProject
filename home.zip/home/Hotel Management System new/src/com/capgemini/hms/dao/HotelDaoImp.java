package com.capgemini.hms.dao;

import java.sql.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;

public class HotelDaoImp implements IHotelDao {
	static boolean flag;
	Connection conn = DBUtil.getCon();
	BookingDetails book = new BookingDetails();
	HotelDetails hotel = new HotelDetails();

	@Override
	public boolean checklogin(UserDetails user) throws HotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.LOGIN_QUERY);
			pstmt.setString(1, user.getUser_id());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				flag = false;

			} else {
				while (rs.next()) {
					if (user.getUser_id().equals(rs.getString(1))
							&& user.getPassword().equals(rs.getString(2))) {
						flag = true;
						break;
					}
				}
			}
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}

		return flag;
	}

	@Override
	public ArrayList<HotelDetails> view_all_hotel() throws HotelException {

		try {

			ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.HOTEL_ALL);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				HotelDetails hotel = new HotelDetails();
				hotel.setHotel_id(rs.getString(1));
				hotel.setCity(rs.getString(2));
				hotel.setHotel_name(rs.getString(3));
				hotel.setAddress(rs.getString(4));
				hotel.setAvg_rate_per_night(rs.getFloat(6));
				hotel.setDescription(rs.getString(5));
				hotel.setEmail(rs.getString(10));
				hotel.setFax(rs.getString(11));
				hotel.setPhone_no1(rs.getString(7));
				hotel.setPhone_no2(rs.getString(8));
				hotel.setRating(rs.getString(9));

				hotelDetail.add(hotel);
			}

			return hotelDetail;
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public ArrayList<HotelDetails> view_hotel_city(String city)
			throws HotelException {
		try {
			ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.HOTEL_CITY);
			pstmt.setString(1, city);
			pstmt.setString(2, city);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					HotelDetails hotel = new HotelDetails();
					hotel.setHotel_id(rs.getString(1));
					hotel.setCity(rs.getString(2));
					hotel.setHotel_name(rs.getString(3));
					hotel.setAddress(rs.getString(4));
					hotel.setAvg_rate_per_night(rs.getFloat(6));
					hotel.setDescription(rs.getString(5));
					hotel.setEmail(rs.getString(10));
					hotel.setFax(rs.getString(11));
					hotel.setPhone_no1(rs.getString(7));
					hotel.setPhone_no2(rs.getString(8));
					hotel.setRating(rs.getString(9));

					hotelDetail.add(hotel);
				}
			}
			return hotelDetail;
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public void register_new_customer(UserDetails user) throws HotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.REGISTER_NEW_CUSTOMER);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getRole());
			pstmt.setString(3, user.getUser_name());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.GET_ID);
			pstmt.setString(1, user.getUser_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String uid = rs.getString(1);
				user.setUser_id(uid);
			}
		} catch (SQLException e) {

			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public void register_new_employee(UserDetails user) throws HotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.REGISTER_NEW_EMPLOYEE);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getRole());
			pstmt.setString(3, user.getUser_name());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.GET_ID);
			pstmt.setString(1, user.getUser_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String uid = rs.getString(1);
				user.setUser_id(uid);
			}
		} catch (SQLException e) {

			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public ArrayList<RoomDetails> view_room_hotel(String name)
			throws HotelException {

		try {
			ArrayList<RoomDetails> roomdetails = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ROOM_HOTEL);
			pstmt.setString(1, name);
			pstmt.setString(2, name);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					RoomDetails room = new RoomDetails();
					room.setAvailability(rs.getInt(6));
					room.setRoom_no(rs.getString(3));
					room.setPer_night_rate(rs.getFloat(5));
					room.setRoom_id(rs.getString(2));
					room.setRoom_type(rs.getString(4));
					roomdetails.add(room);

				}
			}
			return roomdetails;

		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public ArrayList<RoomDetails> room_type_available(String option) throws HotelException {
		try {
			ArrayList<RoomDetails> roomdetails = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ROOM_TYPE_AVAIL);
			pstmt.setString(1, option);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {	
					RoomDetails room = new RoomDetails();
					room.setAvailability(rs.getInt(6));
					room.setRoom_no(rs.getString(3));
					room.setPer_night_rate(rs.getFloat(5));
					room.setRoom_id(rs.getString(2));
					room.setRoom_type(rs.getString(4));
					roomdetails.add(room);

				}
			}
			return roomdetails;
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}
		

	}

	@Override
	public String book_room(BookingDetails book) throws HotelException {

		try {
			float amount = 0;
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryMapper.ROOM_AMOUNT);
			pstmt1.setString(1, book.getRoom_id());
			ResultSet rs1 = pstmt1.executeQuery();
			while (rs1.next()) {
				amount = rs1.getFloat(1);
			}
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.BOOK_ROOM);
			pstmt.setString(1, book.getRoom_id());
			pstmt.setString(2, book.getUser_id());
			pstmt.setDate(3, Date.valueOf(book.getBooked_from()));
			pstmt.setDate(4, Date.valueOf(book.getBooked_to()));
			pstmt.setInt(5, book.getNo_of_adults());
			pstmt.setInt(6, book.getNo_of_children());
			Period intervalPeriod = Period.between(book.getBooked_from(),
					book.getBooked_to());
			int daysOfStay = intervalPeriod.getDays();
			pstmt.setFloat(7, amount * daysOfStay);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_BOOKING);
			pstmt.setString(1, book.getUser_id());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String booking_id = rs.getString(1);
				book.setBooking_id(booking_id);
			}
		} catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}
		return book.getBooking_id();
	}

	@Override
	public ArrayList<BookingDetails> view_booking(String user_id)
			throws HotelException {

		try {
			ArrayList<BookingDetails> booking = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_BOOKING);
			pstmt.setString(1, user_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					BookingDetails book = new BookingDetails();
					book.setBooking_id(rs.getString(1));
					book.setRoom_id(rs.getString(2));
					book.setUser_id(rs.getString(3));
					book.setBooked_from(dateChange(rs.getString(4)));
					book.setBooked_to(dateChange(rs.getString(5)));
					book.setNo_of_adults(rs.getInt(6));
					book.setNo_of_children(rs.getInt(7));
					book.setAmount(rs.getFloat(8));
					booking.add(book);
				}
			}
			return booking;
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public LocalDate dateChange(String dateOld) {
		String datearr[] = dateOld.split("/");
		int year = Integer.parseInt(datearr[2]);
		int month = Integer.parseInt(datearr[1]);
		int day = Integer.parseInt(datearr[0]);
		return LocalDate.of(year, month, day);
	}

}
