package com.capgemini.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;

public class HotelAdminDaoImp implements IHotelAdminDao {

	Connection conn = DBUtil.getCon();
	IHotelDao hd = new HotelDaoImp();

	@Override
	public ArrayList<HotelDetails> view_all_hotel() throws HotelException {
		try {
			ArrayList<HotelDetails> hotelDetails = new ArrayList<>();

			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.HOTEL_ALL);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				HotelDetails hotel = new HotelDetails();
				hotel.setHotel_id(rs.getString(1));
				hotel.setHotel_name(rs.getString(3));
				hotel.setCity(rs.getString(2));
				hotelDetails.add(hotel);
			}
			return hotelDetails;
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public ArrayList<UserDetails> view_all_user() throws HotelException {
		try {
			ArrayList<UserDetails> user = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_ALL_USER);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {

				UserDetails userdetail = new UserDetails();
				userdetail.setUser_id(rs.getString(1));
				userdetail.setRole(rs.getString(3));
				userdetail.setUser_name(rs.getString(4));
				userdetail.setAddress(rs.getString(6));
				userdetail.setPhone(rs.getString(5));
				userdetail.setEmail(rs.getString(7));
				user.add(userdetail);

			}
			return user;
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public void add_hotel(HotelDetails hotel) throws HotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ADD_HOTEL);
			pstmt.setString(1, hotel.getCity());
			pstmt.setString(2, hotel.getHotel_name());
			pstmt.setString(3, hotel.getAddress());
			pstmt.setString(4, hotel.getDescription());
			pstmt.setFloat(5, hotel.getAvg_rate_per_night());
			pstmt.setString(6, hotel.getPhone_no1());
			pstmt.setString(7, hotel.getPhone_no2());
			pstmt.setString(8, hotel.getRating());
			pstmt.setString(9, hotel.getEmail());
			pstmt.setString(10, hotel.getFax());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.GET_HOTEL_ID);
			pstmt.setString(1, hotel.getHotel_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String hid = rs.getString(1);
				hotel.setHotel_id(hid);
			}
		} catch (SQLException e) {

			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public boolean delete_hotel(String id) throws HotelException {
		try {
			boolean a = true;
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryMapper.HOTEL_ALL);
			ResultSet rs = pstmt1.executeQuery();
			while (rs.next()) {
				if ((rs.getString(1)).equals(id)) {
					a = true;
					break;
				} else {
					a = false;
				}
			}
			if (a == true) {
				PreparedStatement pstmt = conn
						.prepareStatement(IQueryMapper.DELETE_HOTEL);
				pstmt.setString(1, id);
				pstmt.executeUpdate();
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public ArrayList<RoomDetails> room_view(String h_id) throws HotelException {

		try {
			ArrayList<RoomDetails> roomdetails = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ROOM_VIEW);
			pstmt.setString(1, h_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					RoomDetails room = new RoomDetails();

					if (h_id.equals(rs.getString(1))) {
						room.setAvailability(rs.getInt(6));
						room.setRoom_no(rs.getString(3));
						room.setPer_night_rate(rs.getFloat(5));
						room.setRoom_id(rs.getString(2));
						room.setRoom_type(rs.getString(4));
						roomdetails.add(room);
					}
				}
			}
			return roomdetails;
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public ArrayList<String> display_ids() throws HotelException {
		try {
			ArrayList<String> ids = new ArrayList<String>();
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryMapper.HOTEL_ALL);
			ResultSet rs = pstmt1.executeQuery();
			while (rs.next()) {

				ids.add(rs.getString(1));
			}
			return ids;
		} catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public void add_room(RoomDetails room) throws HotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ADD_ROOM);
			pstmt.setString(1, room.getHotel_id());
			pstmt.setString(2, room.getRoom_no());
			pstmt.setString(3, room.getRoom_type());
			pstmt.setFloat(4, room.getPer_night_rate());
			if (room.getAvailability() == 0)
				pstmt.setString(5, "0");
			else if (room.getAvailability() == 1)
				pstmt.setString(5, "1");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.ROOM_VIEW);
			pstmt.setString(1, room.getHotel_id());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String rid = rs.getString(1);
				room.setRoom_id(rid);
			}
		} catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public boolean delete_room(String room_id) throws HotelException {

		try {
			boolean a = true;
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryMapper.ROOM_ALL);

			ResultSet rs = pstmt1.executeQuery();
			while (rs.next()) {

				if ((rs.getString(1)).equals(room_id)) {
					a = true;
					break;
				} else {
					a = false;
				}
			}
			if (a == true) {
				PreparedStatement pstmt = conn
						.prepareStatement(IQueryMapper.DELETE_ROOM);
				pstmt.setString(1, room_id);
				pstmt.executeUpdate();
				return true;

			} else {
				return false;

			}

		} catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public ArrayList<BookingDetails> view_booking(String hotel_id)
			throws HotelException {

		try {
			ArrayList<BookingDetails> booking = new ArrayList<>();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_BOOKING_HOTEL);
			pstmt.setString(1, hotel_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				return null;
			} else {
				while (rs.next()) {
					BookingDetails book = new BookingDetails();
					book.setBooking_id(rs.getString(1));
					book.setRoom_id(rs.getString(2));
					book.setUser_id(rs.getString(3));
					book.setBooked_from(hd.dateChange(rs.getString(4)));
					book.setBooked_to(hd.dateChange(rs.getString(5)));
					book.setNo_of_adults(rs.getInt(6));
					book.setNo_of_children(rs.getInt(7));
					book.setAmount(rs.getFloat(8));
					booking.add(book);
				}
			}
			return booking;
		} catch (SQLException e) {
			throw new HotelException(e.getLocalizedMessage());
		}

	}

}
