package com.capgemini.hms.dao;



import java.time.LocalDate;

import com.capgemini.hms.bean.bookingDetails;
import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;

public interface IHotelDao {
	public abstract boolean checklogin(userDetails user) throws hotelException;

	public abstract hotelDetails view_all_hotel() throws hotelException;

	public abstract hotelDetails view_hotel_city(String city) throws hotelException;

	//public abstract void register_new_admin(userDetails user) throws hotelException;

	public abstract void register_new_customer(userDetails user) throws hotelException;

	public abstract void register_new_employee(userDetails user) throws hotelException;

	public abstract void view_room_hotel(String name) throws hotelException;

	

	void room_type_available(String option) throws hotelException;

	public abstract String book_room(bookingDetails book) throws hotelException;

	public abstract bookingDetails view_booking(String user_id) throws hotelException;

	public abstract LocalDate dateChange(String dateOld);

}
