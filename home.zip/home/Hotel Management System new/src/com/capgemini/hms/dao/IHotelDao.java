package com.capgemini.hms.dao;

import java.time.LocalDate;

//------------------------ Hotel Management System --------------------------
	/*******************************************************************************************************
	 - Interface Name	:	IHotelDao (Dao interface for customer and employee)
	 - Throws			:  	hotelException
	 - Author			:	Anisha
	 - Creation Date	:	03/09/2018
	 - Description		:	function signatures for customer/employee.
	 ********************************************************************************************************/

import java.util.ArrayList;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;

public interface IHotelDao {
	public abstract boolean checklogin(UserDetails user) throws HotelException;

	public abstract ArrayList<HotelDetails> view_all_hotel() throws HotelException;

	public abstract ArrayList<HotelDetails> view_hotel_city(String city) throws HotelException;

	//public abstract void register_new_admin(userDetails user) throws hotelException;

	public abstract void register_new_customer(UserDetails user) throws HotelException;

	public abstract void register_new_employee(UserDetails user) throws HotelException;

	public abstract ArrayList<RoomDetails> view_room_hotel(String name) throws HotelException;

	

	ArrayList<RoomDetails> room_type_available(String option) throws HotelException;

	public abstract String book_room(BookingDetails book) throws HotelException;

	public abstract ArrayList<BookingDetails> view_booking(String user_id) throws HotelException;

	public abstract LocalDate dateChange(String dateOld);

	public abstract boolean check_userid(String user_id) throws HotelException;

	public abstract ArrayList<String> room_ids() throws HotelException;

}
