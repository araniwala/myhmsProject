package com.capgemini.hms.dao;

public interface IQueryMapper {
	
	public final static String LOGIN_QUERY="Select user_id,password from users where user_id=? and password=?";
	public final static String HOTEL_ALL="select * from hotel order by hotel_id";
	//public final static String HOTEL_BASIC="select hotel_id,hotel_name from hotel order by hotel_id";
	public final static String HOTEL_CITY="select * from hotel where (lower(city)=? OR UPPER(CITY)=?) order by hotel_id";
	//public final static String REGISTER_NEW_ADMIN="INSERT INTO USERS VALUES(('adm'||to_char(user_id_admin.nextval)),?,?,?,?,?,?)";
	public final static String REGISTER_NEW_CUSTOMER="INSERT INTO USERS VALUES(('cus'||to_char(user_id_cust.nextval)),?,?,?,?,?,?)";
	public final static String REGISTER_NEW_EMPLOYEE="INSERT INTO USERS VALUES(('emp'||to_char(user_id_staff.nextval)),?,?,?,?,?,?)";
	public final static String GET_ID = "SELECT user_id FROM users where user_name=?";
	public final static String GET_HOTEL_ID = "SELECT hotel_id FROM hotel where hotel_name=? order by hotel_id";
	public final static String VIEW_ALL_USER="SELECT * FROM users order by user_id";
	public final static String ADD_HOTEL="INSERT INTO HOTEL VALUES(('hot'||to_char(hotel_id_seq.nextval)),?,?,?,?,?,?,?,?,?,?)";
	public final static String DELETE_HOTEL="DELETE FROM HOTEL WHERE hotel_id=?";
	public final static String ROOM_VIEW="SELECT * FROM ROOM_DETAILS WHERE lower(HOTEL_ID)=?";
	public final static String ROOM_ALL="SELECT room_id FROM ROOM_DETAILS";
	public final static String ROOM_AMOUNT="SELECT per_night_rate FROM ROOM_DETAILS WHERE ROOM_ID=?";
	public final static String ADD_ROOM="INSERT INTO ROOM_DETAILS VALUES(?,('room'||to_char(room_id_seq.nextval)),?,?,?,?)";
	public final static String DELETE_ROOM="DELETE FROM ROOM_DETAILS WHERE ROOM_ID=?";
	public final static String ROOM_TYPE="SELECT r.*,h.hotel_name from room_details r,hotel h where room_type=? and r.hotel_id=h.hotel_id";
	public final static String ROOM_HOTEL="SELECT * from room_details where hotel_id in (select hotel_id from hotel where (lower(hotel_name)=? or upper(hotel_name)=?))";
	public final static String ROOM_TYPE_AVAIL="SELECT r.*,h.hotel_name from room_details r,hotel h where room_type=? and r.hotel_id=h.hotel_id and availability='0'";
	public final static String BOOK_ROOM="INSERT INTO BOOKING_DETAILS VALUES(booking_seq.nextval,?,?,?,?,?,?,?)";
	public final static String VIEW_BOOKING="SELECT booking_id,room_id,user_id,to_char(booked_from,'dd/mm/yyyy'),to_char(booked_to,'dd/mm/yyyy'),no_of_adults,no_of_children,amount FROM BOOKING_Details WHERE USER_ID=?";
	public final static String VIEW_BOOKING_HOTEL="SELECT b.booking_id,b.room_id,b.user_id,to_char(b.booked_from,'dd/mm/yyyy'),to_char(b.booked_to,'dd/mm/yyyy'),b.no_of_adults,b.no_of_children,b.amount FROM BOOKING_Details b,room_details r WHERE r.hotel_id=? and r.room_id=b.room_id";
}
