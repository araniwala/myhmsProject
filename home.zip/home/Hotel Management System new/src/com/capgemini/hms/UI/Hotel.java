package com.capgemini.hms.UI;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;
import com.capgemini.hms.login.LoginUsers;
import com.capgemini.hms.management.Management;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

//------------------------ Hotel Management System --------------------------
/*******************************************************************************************************
 * - Class Name : Main class - Input Parameters : Scanner User Input - Throws :
 * hotelException - Author : Anisha - Creation Date : 03/09/2018 - Description :
 * Calls all the functions and displays output accordingly.
 ********************************************************************************************************/

public class Hotel {

	static Scanner s = null;
	static BufferedReader bf = null;
	static UserDetails user = null;
	static HotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static LoginUsers uLogin = null;
	static Logger logger = Logger.getRootLogger();
	static Management mngmt = null;
	static BookingDetails book = null;

	public static void main(String[] args) throws HotelException {
		s = new Scanner(System.in);
		user = new UserDetails();
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		book = new BookingDetails();
		bf = new BufferedReader(new InputStreamReader(System.in));
		int check = 0;
		String user_id = null;
		try {
			System.out
					.println("--------------------------------------------------");
			System.out.println("||\tWelcome to Hotel Booking portal\t\t||");
			System.out
					.println("--------------------------------------------------");
			System.out.println("||\t\tPress [1] to login\t\t||");
			System.out.println("||\t\tPress [2] to Register\t\t||");
			System.out.println("||\t\tPress [3] to Exit\t\t||");
			System.out
					.println("--------------------------------------------------");
			int login = s.nextInt();
			if (login == 1) {
				user_id = uLogin.login();
				logger.info("LOGGED IN " + user_id);
			} else if (login == 3) {
				System.exit(0);
			} else {
				user_id = uLogin.register();
				System.out.println("User ID for you is:" + user_id
						+ "\nNow you can login");
				uLogin.login();
				logger.info("REGISTERED " + user_id);
			}
			if (user_id.contains("adm")) {

				System.out.println("You are logged in as Admin");

				while (true) {
					System.out.println("---------------------------------");
					System.out.println("||Press [1] to Manage hotels   ||");
					System.out.println("||Press [2] to manage Rooms    ||");
					System.out.println("||Press [3] to generate Reports||");
					System.out.println("||Press [4] to Exit            ||");
					System.out.println("---------------------------------");
					check = s.nextInt();
					switch (check) {

					case 1: {
						mngmt.hotelmngmt();
					}
						break;
					case 2: {
						mngmt.room_mngmt();
					}
						break;
					case 4: {
						System.exit(0);
						logger.info("EXITED");
					}
						break;
					case 5:
						main(args);
						break;
					case 3: {
						System.out
								.println("----------------------------------------------------------");
						System.out
								.println("||\tPress [1] to view all hotels\t\t\t||");
						System.out
								.println("||\tPress [2] to view hotels w.r.t to city\t\t||");
						System.out
								.println("||\tPress [3] to view all users\t\t\t||");
						System.out
								.println("||\tPress [4] to view booking of specific hotel\t||");
						System.out.println("||\tPress [5] to login as different user\t||");
						System.out
								.println("----------------------------------------------------------");
						check = s.nextInt();
						switch (check) {

						case 1: {
							ArrayList<HotelDetails> hotelDetails = new ArrayList<>();
							hotelDetails = s_admin.view_all_hotel();
							for (HotelDetails hotel1 : hotelDetails) {
								System.out
										.println("--------------------------------------------------------------------------");
								System.out.println("||Hotel ID:					||"
										+ hotel1.getHotel_id()
										+ "\n||Hotel City:        		||"
										+ hotel1.getCity()
										+ "\n||Hotel Name:        		||"
										+ hotel1.getHotel_name());
								System.out
										.println("--------------------------------------------------------------------------");
							}
							logger.info("VIEWED ALL HOTELS");
						}
							break;

						case 2: {
							System.out.println("Enter the city:");
							String city = s.next();
							ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
							hotelDetail = s_admin.view_hotel_city(city);
							for (HotelDetails hotel1 : hotelDetail) {
								System.out
										.println("--------------------------------------------------------------------------");
								System.out.println("||Hotel City:        		||"
										+ hotel1.getCity()
										+ "\n||Hotel Name:        		||"
										+ hotel1.getHotel_name()
										+ "\n||Hotel Address:     		||"
										+ hotel1.getAddress()
										+ "\n||Hotel description: 		||"
										+ hotel1.getDescription()
										+ "\n||Hotel rate of room per night: ||"
										+ hotel1.getAvg_rate_per_night()
										+ "\n||Hotel phone 1:     		||"
										+ hotel1.getPhone_no1()
										+ "\n||Hotel phone 2:     		||"
										+ hotel1.getPhone_no2()
										+ "\n||Hotel rating:      		||"
										+ hotel1.getRating()
										+ "\n||Hotel email:       		||"
										+ hotel1.getEmail()
										+ "\n||Hotel fax:         		||"
										+ hotel1.getFax());
								System.out
										.println("--------------------------------------------------------------------------");
							}
						
							logger.info("VIEWED ALL HOTELS by city");
						}
							break;
						case 3: {
							System.out.println("All the Registered users are:");
							ArrayList<UserDetails> userdetails = new ArrayList<>();
							userdetails = s_admin.view_all_user();
							for (UserDetails user1 : userdetails) {
								System.out
										.println("--------------------------------------------------------------------------");
								System.out.println("||User ID:      ||"
										+ user1.getUser_id()
										+ "\n||User Role:    ||"
										+ user1.getRole()
										+ "\n||User Name:    ||"
										+ user1.getUser_name()
										+ "\n||User Address: ||"
										+ user1.getAddress()
										+ "\n||User phone:   ||"
										+ user1.getPhone()
										+ "\n||User email:   ||"
										+ user1.getEmail());
								System.out
										.println("--------------------------------------------------------------------------");
							}
							logger.info("VIEWED ALL users");
						}
							break;
						case 4: {
							ArrayList<BookingDetails> booking = new ArrayList<>();
							System.out.println("Enter the hotel Id:");
							String hotel_id = s.next();
							booking = s_admin.view_booking(hotel_id);
							if (booking == null) {
								System.out.println("No bookings in this hotel");
							} else {
								for (BookingDetails book : booking) {
									System.out.println("Bookings are:");
									System.out.println("||Booking ID: 	 ||"
											+ book.getBooking_id()
											+ "\n||Room ID:	 ||"
											+ book.getRoom_id()
											+ "\n||User ID:	 ||"
											+ book.getUser_id()
											+ "\n||Booked From:	 ||"
											+ book.getBooked_from()
											+ "\n||Booked till:	 ||"
											+ book.getBooked_to()
											+ "\n||No of adults:	 ||"
											+ book.getNo_of_adults()
											+ "\n||No of children:||"
											+ book.getNo_of_children()
											+ "\n||Amount:	 ||"
											+ book.getAmount());
								}
							}
							logger.info("Viewed all bookings for a particular hotel");
						}
							break;
						}
					}
					}
				}

			} else if ((user_id.contains("cus")) || (user_id.contains("emp"))) {
				System.out.println("You are logged in as Customer/Employee");
				while (true) {
					System.out
							.println("--------------------------------------------------------------------------");
					System.out.println("||\tPress [1] for all hotels\t\t||");
					System.out
							.println("||\tPress [2] for hotels w.r.t to city\t||");
					System.out.println("||\tPress [3] to Make a booking\t\t||");
					System.out
							.println("||\tPress [4] to view booking status\t||");
					System.out.println("||\tPress [5] to login as different user\t||");
					System.out.println("||\tPress [6] to exit\t\t\t||");
					System.out
							.println("--------------------------------------------------------------------------");

					check = s.nextInt();
					switch (check) {

					case 1: {
						ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
						hotelDetail = service.view_all_hotel();
						for (HotelDetails hotel1 : hotelDetail) {
							System.out
									.println("--------------------------------------------------------------------------");
							System.out.println("||Hotel City:        		||"
									+ hotel1.getCity()
									+ "\n||Hotel Name:        		||"
									+ hotel1.getHotel_name()
									+ "\n||Hotel Address:     		||"
									+ hotel1.getAddress()
									+ "\n||Hotel description: 		||"
									+ hotel1.getDescription()
									+ "\n||Hotel rate of room per night: ||"
									+ hotel1.getAvg_rate_per_night()
									+ "\n||Hotel phone 1:     		||"
									+ hotel1.getPhone_no1()
									+ "\n||Hotel phone 2:     		||"
									+ hotel1.getPhone_no2()
									+ "\n||Hotel rating:      		||"
									+ hotel1.getRating()
									+ "\n||Hotel email:       		||"
									+ hotel1.getEmail()
									+ "\n||Hotel fax:         		||"
									+ hotel1.getFax());
							System.out
									.println("--------------------------------------------------------------------------");
						}
						logger.info("VIEWED ALL hotels");
					}
						break;
					case 2: {
						System.out.println("Enter the city:");
						String city = s.next();
						ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
						hotelDetail = service.view_hotel_city(city);
						for (HotelDetails hotel1 : hotelDetail) {
							System.out
									.println("--------------------------------------------------------------------------");
							System.out.println("||Hotel City:        		||"
									+ hotel1.getCity()
									+ "\n||Hotel Name:        		||"
									+ hotel1.getHotel_name()
									+ "\n||Hotel Address:     		||"
									+ hotel1.getAddress()
									+ "\n||Hotel description: 		||"
									+ hotel1.getDescription()
									+ "\n||Hotel rate of room per night: ||"
									+ hotel1.getAvg_rate_per_night()
									+ "\n||Hotel phone 1:     		||"
									+ hotel1.getPhone_no1()
									+ "\n||Hotel phone 2:     		||"
									+ hotel1.getPhone_no2()
									+ "\n||Hotel rating:      		||"
									+ hotel1.getRating()
									+ "\n||Hotel email:       		||"
									+ hotel1.getEmail()
									+ "\n||Hotel fax:         		||"
									+ hotel1.getFax());
							System.out
									.println("--------------------------------------------------------------------------");
						}
					
						logger.info("VIEWED ALL HOTELS by city");
					}
						break;
					case 5:
						//System.exit(0);
						main(args);
						break;
					case 6:
						System.exit(0);
						
						break;
					case 3: {
						System.out
								.println("||\tChoose the options to make a booking:\t||");
						mngmt.booking_mngmt(user_id);
						logger.info("booking made");
					}
						break;
					case 4: {
						ArrayList<BookingDetails> booking = new ArrayList<>();
						booking = service.view_booking(user_id);
						
						if (booking == null) {
							System.out.println("No bookings in this hotel");
						} else {
							System.out.println("Bookings made are:");
							for (BookingDetails book : booking) {
								System.out.println("Bookings are:");
								System.out.println("||Booking ID: 	 ||"
										+ book.getBooking_id()
										+ "\n||Room ID:	 ||"
										+ book.getRoom_id()
										+ "\n||User ID:	 ||"
										+ book.getUser_id()
										+ "\n||Booked From:	 ||"
										+ book.getBooked_from()
										+ "\n||Booked till:	 ||"
										+ book.getBooked_to()
										+ "\n||No of adults:	 ||"
										+ book.getNo_of_adults()
										+ "\n||No of children:||"
										+ book.getNo_of_children()
										+ "\n||Amount:	 ||"
										+ book.getAmount());
							}
						logger.info("booking status viewed");
					}
					}
				}
			}
			}
		} catch (InputMismatchException e) {
			throw new HotelException("Please enter the right option");
		}
	}
}
