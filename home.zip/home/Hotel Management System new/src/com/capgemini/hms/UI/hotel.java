package com.capgemini.hms.UI;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.bookingDetails;
import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;
import com.capgemini.hms.login.loginUsers;
import com.capgemini.hms.management.management;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

public class hotel {

	static Scanner s = null;
	static BufferedReader bf = null;
	static userDetails user = null;
	static hotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static loginUsers uLogin = null;
	static Logger logger = Logger.getRootLogger();
	static management mngmt = null;
	static bookingDetails book=null;

	public static void main(String[] args) throws hotelException {
		s = new Scanner(System.in);
		user = new userDetails();
		service = new HotelServiceImp();
		uLogin = new loginUsers();
		hotel = new hotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new management();
		book=new bookingDetails();
		bf = new BufferedReader(new InputStreamReader(System.in));
		int check = 0;
		String user_id = null;
		try {
			System.out.println("\tWelcome to Hotel Booking portal");
			System.out.println("--------------------------------------------------------------------------");
			System.out.println("Login if existing user or Register for further operations");
			System.out.println("-----------------------------------------------------------------");
			System.out.println("||Press 1 to login\t||Press 2 to Register\t||Press 3 to exit");
			System.out.println("-----------------------------------------------------------------");
			int login = s.nextInt();
			if (login == 1) {
				user_id = uLogin.login();
				logger.info("LOGGED IN " + user_id);
			} else if (login == 3) {
				System.exit(0);
			} else {
				user_id = uLogin.register();
				System.out.println("User ID for you is:" + user_id + "\nNow you can login");
				uLogin.login();
				logger.info("REGISTERED " + user_id);
			}
			if (user_id.contains("adm")) {
				System.out.println("You are logged in as Admin");

				while (true) {
					System.out.println("---------------------------------");
					System.out.println("||Press [1] to Manage hotels   ||");
					System.out.println("---------------------------------");
					System.out.println("||Press [2] to manage Rooms    ||");
					System.out.println("---------------------------------");
					System.out.println("||Press [3] to generate Reports||");
					System.out.println("---------------------------------");
					System.out.println("||Press [4] to Exit            ||");
					System.out.println("---------------------------------");
					check = s.nextInt();
					switch (check) {

					case 1: {
						mngmt.hotelmngmt();
					}
						break;
					case 2: {
						mngmt.room_mngmt();
					}
						break;
					case 4: {
						System.exit(0);
						logger.info("EXITED");
					}
						break;
					case 3: {
						System.out
								.println("--------------------------------------------------------------------------");
						System.out.println("||Press [1] to view all hotels||Press [2] to view hotels w.r.t to city||");
						System.out
								.println("--------------------------------------------------------------------------");
						System.out.println("||Press [3] to view all users ||Press [4] to view booking of specific hotel");
						System.out
								.println("--------------------------------------------------------------------------");
						check = s.nextInt();
						switch (check) {

						case 1: {
							hotel=s_admin.view_all_hotel();
							System.out
							.println("--------------------------------------------------------------------------");
							   System.out.println("||Hotel ID:					||"+hotel.getHotel_id()
							   				  + "\n||Hotel City:        		||"+ hotel.getCity() 
									   		  + "\n||Hotel Name:        		||"+ hotel.getHotel_name());
					System.out
							.println("--------------------------------------------------------------------------");
							logger.info("VIEWED ALL HOTELS");
						}
							break;
						case 2: {
							System.out.println("Enter the city:");
							String city = s.next();
							hotel=s_admin.view_hotel_city(city);
							System.out
							.println("--------------------------------------------------------------------------");
					System.out.println("||Hotel City:        		||"
							+ hotel.getCity() + "\n||Hotel Name:        		||"
							+ hotel.getHotel_name() + "\n||Hotel Address:     		||"
							+ hotel.getAddress() + "\n||Hotel description: 		||"
							+ hotel.getDescription()
							+ "\n||Hotel rate of room per night: ||"
							+ hotel.getAvg_rate_per_night() + "\n||Hotel phone 1:     		||"
							+ hotel.getPhone_no1() + "\n||Hotel phone 2:     		||"
							+ hotel.getPhone_no2() + "\n||Hotel rating:      		||"
							+ hotel.getRating() + "\n||Hotel email:       		||"
							+ hotel.getEmail() + "\n||Hotel fax:         		||"
							+ hotel.getFax());
					System.out
							.println("--------------------------------------------------------------------------");
						
							logger.info("VIEWED ALL HOTELS by city");
						}
							break;
						case 3: {
							System.out.println("All the Registered users are:");
							s_admin.view_all_user();
							logger.info("VIEWED ALL users");
						}
							break;
						case 4:
						{
							System.out.println("Enter the hotel Id:");
							String hotel_id=s.next();
							book=s_admin.view_booking(hotel_id);
							System.out.println("Bookings are:");
							System.out.println("||Booking ID: 	 ||"+book.getBooking_id()
											+"\n||Room ID:	 ||"+book.getRoom_id()
											+"\n||User ID:	 ||"+book.getUser_id()
											+"\n||Booked From:	 ||"+book.getBooked_from()
											+"\n||Booked till:	 ||"+book.getBooked_to()
											+"\n||No of adults:	 ||"+book.getNo_of_adults()
											+"\n||No of children:||"+book.getNo_of_children()
											+"\n||Amount:	 ||"+book.getAmount());
						}
						}
					}
					}
				}

			} else if ((user_id.contains("cus")) || (user_id.contains("emp"))) {
				System.out.println("You are logged in as Customer/Employee");
				while (true) {
					System.out.println("--------------------------------------------------------------------------");
					System.out.println("||Press [1] for all hotels\t\t||Press [2] for hotels w.r.t to city");
					System.out.println("--------------------------------------------------------------------------");
					System.out.println("||Press [3] to Make a booking\t\t||Press [4] to view booking status");
					System.out.println("--------------------------------------------------------------------------");	
					System.out.println("||Press [5] to exit\t||");
					System.out.println("--------------------------------------------------------------------------");

					check = s.nextInt();
					switch (check) {

					case 1: {
						hotel=service.view_all_hotel();
						System.out
						.println("--------------------------------------------------------------------------");
				System.out.println("||Hotel City:        		||"
						+ hotel.getCity() + "\n||Hotel Name:        		||"
						+ hotel.getHotel_name() + "\n||Hotel Address:     		||"
						+ hotel.getAddress() + "\n||Hotel description: 		||"
						+ hotel.getDescription()
						+ "\n||Hotel rate of room per night: ||"
						+ hotel.getAvg_rate_per_night() + "\n||Hotel phone 1:     		||"
						+ hotel.getPhone_no1() + "\n||Hotel phone 2:     		||"
						+ hotel.getPhone_no2() + "\n||Hotel rating:      		||"
						+ hotel.getRating() + "\n||Hotel email:       		||"
						+ hotel.getEmail() + "\n||Hotel fax:         		||"
						+ hotel.getFax());
				System.out
						.println("--------------------------------------------------------------------------");
						
					}
						break;
					case 2: {
						System.out.println("Enter the city in which you need hotel:");
						String city = s.next();
						hotel=service.view_hotel_city(city);
						System.out
						.println("--------------------------------------------------------------------------");
				System.out.println("||Hotel City:        		||"
						+ hotel.getCity() + "\n||Hotel Name:        		||"
						+ hotel.getHotel_name() + "\n||Hotel Address:     		||"
						+ hotel.getAddress() + "\n||Hotel description: 		||"
						+ hotel.getDescription()
						+ "\n||Hotel rate of room per night: ||"
						+ hotel.getAvg_rate_per_night() + "\n||Hotel phone 1:     		||"
						+ hotel.getPhone_no1() + "\n||Hotel phone 2:     		||"
						+ hotel.getPhone_no2() + "\n||Hotel rating:      		||"
						+ hotel.getRating() + "\n||Hotel email:       		||"
						+ hotel.getEmail() + "\n||Hotel fax:         		||"
						+ hotel.getFax());
				System.out
						.println("--------------------------------------------------------------------------");
					}
						break;
					case 5:
						System.exit(0);
						break;
					case 3:
					{
						System.out.println("Choose the options to make a booking:");
						mngmt.booking_mngmt(user_id);
					}
					break;
					case 4:
					{
						book=service.view_booking(user_id);
						System.out.println("Bookings made are:");
						System.out.println("||Booking ID: 	 ||"+book.getBooking_id()
										+"\n||Room ID:	 ||"+book.getRoom_id()
										+"\n||User ID:	 ||"+book.getUser_id()
										+"\n||Booked From:	 ||"+book.getBooked_from()
										+"\n||Booked till:	 ||"+book.getBooked_to()
										+"\n||No of adults:	 ||"+book.getNo_of_adults()
										+"\n||No of children:||"+book.getNo_of_children()
										+"\n||Amount:	 ||"+book.getAmount());
					}
					}
				}
			}

		} catch (InputMismatchException e) {
			throw new hotelException("Please enter the right option");
		}
	}
}
