package com.capgemini.hms.login;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;
import com.capgemini.hms.management.Management;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

public class LoginUsers {

	static Scanner s = null;
	static BufferedReader bf = null;
	static UserDetails user = new UserDetails();
	static HotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static LoginUsers uLogin = null;
	static Logger logger = Logger.getRootLogger();
	static Management mngmt = null;

	//------------------------ Hotel Management System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	Register function
		 - Input Parameters	:	Scanner User Input
		 - Throws			:  	hotelException
		 - Author			:	Anisha
		 - Creation Date	:	03/09/2018
		 - Description		:	Registers a new user and displays the user ID to the user.
		 ********************************************************************************************************/
	
	public String register() throws HotelException {
		bf = new BufferedReader(new InputStreamReader(System.in));
		s = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		System.out.println("Register new user:");
		System.out.print("Enter name:");
		String user_name = s.next();
		user.setUser_name(user_name);
		System.out.print("Enter Password: ");
		String pass = s.next();
		user.setPassword(pass);
		System.out.print("Choose your role: (Choose one:\n[1]:Employee [2]:Customer)");
		int role = s.nextInt();
		if (role == 1)
			user.setRole("Employee");
		else if (role == 2)
			user.setRole("Customer");
		System.out.print("Enter phone number");
		String phone = s.next();
		while (service.isValidNumber(phone) == false) {
			System.out.print("Enter valid phone number");
			phone = s.next();
		}
		user.setPhone(phone);
		System.out.print("Enter Address:");
		String address;
		try {
			address = bf.readLine();
			user.setAddress(address);
		} catch (IOException e) {
			throw new HotelException(e.getMessage());
		}
		System.out.print("Enter email:");
		String email = s.next();
		while (service.isValidEmail(email) == false) {
			System.out.print("Enter valid email");
			email = s.next();
		}
		if (user.getRole().equals("Admin")) {
			System.out.println("NO registration for Admin");
			uLogin.register();
		} else if (user.getRole().equals("Customer")) {
			service.register_new_customer(user);
		} else if (user.getRole().equals("Employee")) {
			service.register_new_employee(user);
		}
		return user.getUser_id();

	}

	
	//------------------------ Hotel Management System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	Login function
		 - Input Parameters	:	Scanner User Input
		 - Throws			:  	hotelException
		 - Author			:	Anisha
		 - Creation Date	:	03/09/2018
		 - Description		:	Logins an existing user and shows warning when the user is not found.
		 ********************************************************************************************************/
	
	public String login() throws HotelException {

		bf = new BufferedReader(new InputStreamReader(System.in));
		s = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		boolean flag = true;
		System.out.print("User ID:");
		String user_id = s.next();
		System.out.print("Password:");
		String password = s.next();
		user.setUser_id(user_id);
		user.setPassword(password);
		flag = service.checklogin(user);
		if (flag == false) {
			System.err.println("!----check again----!");
			System.err.println("!--Enter right credentials--!");
			logger.error("wrong user id or password");
			System.out.println("--------------------------------------------------");
			System.out.println("||\t\tPress [1] to login\t\t||");
			System.out.println("||\t\tPress [2] to Register\t\t||");
			System.out.println("||\t\tPress [3] to Exit\t\t||");
			System.out.println("--------------------------------------------------");
			int login = s.nextInt();
		if (login == 1) {
				uLogin.login();
			} else if(login==2) {
				uLogin.register();
			}
			else{
				System.exit(0);
			}
		}
		return user_id;
	}

}
