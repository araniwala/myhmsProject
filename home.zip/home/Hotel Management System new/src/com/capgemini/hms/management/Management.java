package com.capgemini.hms.management;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hms.UI.Hotel;
import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;
import com.capgemini.hms.login.LoginUsers;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

public class Management {
	static Scanner s = null;
	static BufferedReader bf = null;
	static UserDetails user = new UserDetails();
	static HotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static LoginUsers uLogin = null;

	static Logger logger = Logger.getRootLogger();
	static Management mngmt = null;
	static RoomDetails room = null;
	static BookingDetails book = null;

	public boolean hotelmngmt() throws HotelException {
		s = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		bf = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("--------------------------");
			System.out
					.println("||Hotel Management Tasks:||\n[1]:Add Hotel\n [2]:Delete Hotel\n [3]:Modify Hotel\n [4]:To exit");
			System.out.println("--------------------------");
			int choice = s.nextInt();
			switch (choice) {
			case 1: {
				System.out.print("Enter the Details for The hotel");
				System.out.print("Name:");
				String name = s.next();
				hotel.setHotel_name(name);
				System.out.print("City:");
				String city = s.next();
				while (service.isValidName(city) == false) {
					System.out.print("Enter valid city");
					city = s.next();
				}
				hotel.setCity(city);
				System.out.print("Address:");

				String address = bf.readLine();
				hotel.setAddress(address);
				System.out.print("Description:");
				String desc = bf.readLine();
				hotel.setDescription(desc);

				System.out.print("Average Rate Per night:");
				float rate = s.nextFloat();
				hotel.setAvg_rate_per_night(rate);
				System.out.print("Phone Number 1:");
				String phone1 = s.next();
				while (service.isValidNumber(phone1) == false) {
					System.out.print("Enter valid phone number");
					phone1 = s.next();
				}
				hotel.setPhone_no1(phone1);
				System.out.print("Phone Number 2:");
				String phone2 = s.next();
				while (service.isValidNumber(phone2) == false) {
					System.out.print("Enter valid phone number");
					phone2 = s.next();
				}
				hotel.setPhone_no2(phone2);
				System.out.print("Rating:");
				String rating = s.next();
				hotel.setRating(rating);
				System.out.print("Email:");
				String email = s.next();
				while (service.isValidEmail(email) == false) {
					System.out.print("Enter valid email");
					email = s.next();
				}
				hotel.setEmail(email);
				System.out.print("Fax:");
				String fax = s.next();
				while (service.isValidNumber(fax) == false) {
					System.out.print("Enter valid phone number");
					fax = s.next();
				}
				hotel.setFax(fax);

				s_admin.add_hotel(hotel);

				System.out.println("Hotel ID for the added hotel is:"
						+ hotel.getHotel_id());

			}
				break;
			case 2: {
				ArrayList<String> ids = new ArrayList<String>();
				System.out.println("Available hotel IDs are:");
				ids = s_admin.display_ids();
				for (String id1 : ids) {
					System.out.println(id1);
				}
				System.out.print("Enter the hotel Id to be deleted");
				String id = s.next();
				boolean flag = s_admin.delete_hotel(id);
				if (flag == true) {
					System.out.println("Hotel with ID: " + id + " is delted");
				} else {
					System.out.println("Entered ID does not exist");
				}
			}
				break;

			case 3: {
				// System.out.println("Enter the hotel Id to be modify");
				// String id = s.next();
			}
				break;
			case 4: {
				return false;
			}

			}

		} catch (InputMismatchException e) {
			System.out.println("Please enter the right option");
			String[] args = null;
			Hotel.main(args);
		} catch (IOException e) {
			System.out.println("Please enter the right option");
			String[] args = null;
			Hotel.main(args);
		}
		return true;
	}

	public boolean room_mngmt() throws HotelException {
		s = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		room = new RoomDetails();
		mngmt = new Management();
		try {
			System.out
					.println("||Room Management Tasks:|| \n[1]:View Rooms\t [2]:Add Room\t [3]:Delete Room\t [4]:Modify Room\t [5]:To exit");
			int choice = s.nextInt();
			switch (choice) {
			case 1: {
				ArrayList<RoomDetails> roomdetails = new ArrayList<>();
				String flag = "";
				s_admin.display_ids();
				System.out.print("Enter the hotel ID, to view rooms");
				String h_id = s.next();
				roomdetails = s_admin.room_view(h_id);
				if (roomdetails == null) {
					System.out.println("No rooms in this hotel.");
				} else {
					for (RoomDetails room : roomdetails) {
						if (room.getAvailability() == 0)
							flag = "avaialable";
						else
							flag = "not available";
						System.out.println("\nRoom id:" + room.getRoom_id()
								+ "\nRoom number:" + room.getRoom_no()
								+ "\nRoom Type:" + room.getRoom_type()
								+ "\nRoom rate per night:"
								+ room.getPer_night_rate() + "\nAvailability:"
								+ flag);
					}
				}
			}
				break;
			case 2: {
				s_admin.display_ids();
				System.out.println("Enter details of the room to be added");
				System.out.print("Enter the hotel ID:");
				String hotel_id = s.next();
				room.setHotel_id(hotel_id);
				System.out.print("Enter the room number:");
				String room_no = s.next();
				room.setRoom_no(room_no);
				System.out.print("Enter the room type:(choose one)");
				System.out.println("[1] AC-Delux");
				System.out.println("[2] Non-AC-Delux");
				System.out.println("[3] AC-Standard");
				System.out.println("[4] Non-AC-Standard");
				int choose = s.nextInt();
				if (choose == 1)
					room.setRoom_type("AC-Delux");
				else if (choose == 2)
					room.setRoom_type("Non-AC-Delux");
				else if (choose == 3)
					room.setRoom_type("AC-Standard");
				else if (choose == 4)
					room.setRoom_type("Non-AC-Standard");
				else
					System.out.print("choose one of the above");

				System.out.print("Enter the rate per night");
				float rate = s.nextFloat();
				room.setPer_night_rate(rate);
				System.out.print("Enter the Availability:(choose one)");
				System.out.print("[0] Avaialable");
				System.out.println("[1] Unavaialable");
				int choose1 = s.nextInt();
				if (choose1 == 0)
					room.setAvailability(0);
				else if (choose1 == 1)
					room.setAvailability(1);
				else
					System.out.print("choose correctly");

				s_admin.add_room(room);

				System.out.println("Room ID for the added room is:"
						+ room.getRoom_id());
			}
				break;
			case 3: {
				System.out.println("available room ids are:");
				ArrayList<String> ids = new ArrayList<>();
				ids = service.room_ids();
				for (String id : ids) {
					System.out.println(id);
				}
				System.out.print("enter the room Id to be deleted");
				String room_id = s.next();
				boolean flag = s_admin.delete_room(room_id);
				if (flag == true) {
					System.out.println("room with id " + room_id
							+ " is deleted");
				} else
					System.out.println("Room ID does not exist");
			}
				break;
			case 5:
				return false;
			}
		} catch (InputMismatchException e) {
			System.out.println("Please enter the right option");
			String[] args = null;
			Hotel.main(args);
		}
		return true;
	}

	public void booking_mngmt(String user_id) throws HotelException {
		s = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		book = new BookingDetails();
		bf = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out
					.println("--------------------------------------------------------------------------");
			System.out.println("||Press [1] to show rooms by hotel name\t||");
			System.out
					.println("||Press [2] to show rooms by type and are available||");
			System.out.println("||Press [3] to book your selected room\t||");
			System.out.println("||Press [4] to exit||");
			System.out
					.println("--------------------------------------------------------------------------");
			int option1 = s.nextInt();
			switch (option1) {
			case 1: {
				System.out
						.println("Enter the hotel name in which you need rooms");
				ArrayList<RoomDetails> roomdetails = new ArrayList<>();

				String name = bf.readLine();
				roomdetails = service.view_room_hotel(name);
				if (roomdetails == null) {
					System.out.println("No rooms in this hotel.");
				} else {
					for (RoomDetails room : roomdetails) {
						String flag = "";
						if (room.getAvailability() == 0)
							flag = "avaialable";
						else
							flag = "not available";
						System.out.println("\nRoom id:" + room.getRoom_id()
								+ "\nRoom number:" + room.getRoom_no()
								+ "\nRoom Type:" + room.getRoom_type()
								+ "\nRoom rate per night:"
								+ room.getPer_night_rate() + "\nAvailability:"
								+ flag);
					}
				}

			}
				break;
			case 2: {
				ArrayList<RoomDetails> roomdetails = new ArrayList<>();
				System.out.println("Select one of the room types:");
				System.out
						.println("[1] AC-Delux\t[2] Non-AC-Delux\t[3] AC-standard\t[4] Non-AC-standard");
				int option = s.nextInt();
				if (option == 1)
					roomdetails = service.room_type_available("AC-Delux");
				else if (option == 2)
					roomdetails = service.room_type_available("Non-AC-Delux");
				else if (option == 3)
					roomdetails = service.room_type_available("AC-standard");
				else if (option == 4)
					roomdetails = service
							.room_type_available("Non-AC-standard");
				else
					System.out.println("select a valid option");

				if (roomdetails == null) {
					System.out.println("No rooms in this hotel.");
				} else {
					for (RoomDetails room : roomdetails) {
						String flag = "";
						if (room.getAvailability() == 0)
							flag = "avaialable";
						else
							flag = "not available";
						System.out.println("\nRoom id:" + room.getRoom_id()
								+ "\nRoom number:" + room.getRoom_no()
								+ "\nRoom Type:" + room.getRoom_type()
								+ "\nRoom rate per night:"
								+ room.getPer_night_rate() + "\nAvailability:"
								+ flag);
					}
				}
			}
				break;

			case 3: {
				System.out.println("Enter the room Id you want to book");
				String room_id = s.next();
				book.setRoom_id(room_id);
				System.out.println("Enter the date to book from (dd/mm/yyyy)");
				String startDate = s.next();
				while (service.isValidDate(startDate) == false) {
					System.out
							.println("Enter valid Date in the given format: (dd/mm/yyyy)");
					startDate = s.next();
				}
				LocalDate date = service.dateChange(startDate);
				if (date.isEqual(LocalDate.now())
						|| date.isAfter(LocalDate.now())) {
					book.setBooked_from(date);
				} else {
					System.out
							.println("Booking intial date should be today or date after today");
					startDate = s.next();
					while (service.isValidDate(startDate) == false) {
						System.out
								.println("Enter valid Date in the given format: (dd/mm/yyyy)");
						startDate = s.next();
					}
				}
				System.out.println("Enter the date to book till (dd/mm/yyyy)");
				String endDate = s.next();
				while (service.isValidDate(endDate) == false) {
					System.out
							.println("Enter valid Date in the given format: (dd/mm/yyyy)");
					endDate = s.next();
				}
				LocalDate to_date = service.dateChange(endDate);
				if (to_date.isEqual(date) || to_date.isBefore(date)) {
					System.out
							.println("Booking till date should be one or more day(s) after booking date");
					startDate = s.next();
					while (service.isValidDate(startDate) == false) {
						System.out
								.println("Enter valid Date in the given format: (dd/mm/yyyy)");
						startDate = s.next();
					}
				} else {

					book.setBooked_to(service.dateChange(endDate));
				}
				System.out.println("enter the number of adults");
				int no_adult = s.nextInt();
				book.setNo_of_adults(no_adult);
				System.out.println("Enter the number of children");
				int no_child = s.nextInt();
				book.setNo_of_children(no_child);
				book.setUser_id(user_id);
				String book_id = service.book_room(book);
				System.out
						.println("------------------------------------------------------------");
				System.out.println("your booking id is:" + book_id);
				System.out.println("You've booked the room from: "
						+ book.getBooked_from() + " to:" + book.getBooked_to()
						+ " for amount: " + book.getAmount() + " for "
						+ book.getNo_of_adults() + " adults and "
						+ book.getNo_of_children() + " children.");
				System.out
						.println("------------------------------------------------------------");

			}
				break;
			}
		} catch (InputMismatchException e) {
			System.out.println("Please enter the right option");
			String[] args = null;
			Hotel.main(args);
		} catch (IOException e) {
			System.out.println("Please enter the right option");
			String[] args = null;
			Hotel.main(args);
		}
	}

}
