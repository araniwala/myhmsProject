package com.capgemini.hms.service;

import com.capgemini.hms.bean.bookingDetails;
import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.roomDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.dao.HotelAdminDaoImp;
import com.capgemini.hms.dao.IHotelAdminDao;
import com.capgemini.hms.exception.hotelException;

public class HotelAdminServiceImp implements IHotelAdminService{

	IHotelAdminDao hd1 = new HotelAdminDaoImp();
	IHotelService hs=new HotelServiceImp();
	@Override
	public boolean checklogin(userDetails user) throws hotelException {
		return false;
	}

	@Override
	public hotelDetails view_all_hotel() throws hotelException {
		return hd1.view_all_hotel();
	}

	@Override
	public hotelDetails view_hotel_city(String city) throws hotelException {
		if (hs.isValidName(city) == true)
			return hs.view_hotel_city(city);
		else
			return null;
	}

	@Override
	public void view_all_user() throws hotelException {
		hd1.view_all_user();
	}

	@Override
	public void add_hotel(hotelDetails hotel) throws hotelException {
		hd1.add_hotel(hotel);
	}

	@Override
	public void delete_hotel(String id) throws hotelException {
		hd1.delete_hotel(id);
	}

	@Override
	public void room_view(String h_id) throws hotelException {
		
		hd1.room_view(h_id);
	}

	@Override
	public void display_ids() throws hotelException {
		hd1.display_ids();
	}

	@Override
	public void add_room(roomDetails room) throws hotelException {
		hd1.add_room(room);
	}

	@Override
	public void delete_room(String room_id) throws hotelException {
		hd1.delete_room(room_id);
	}

	@Override
	public bookingDetails view_booking(String hotel_id) throws hotelException {
		return hd1.view_booking(hotel_id);
	}

}
