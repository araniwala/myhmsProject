package com.capgemini.hms.service;

import java.util.ArrayList;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;

//------------------------ Hotel Management System --------------------------
	/*******************************************************************************************************
	 - Interface Name	:	IHotelAdminService (Service interface for Admin)
	 - Throws			:  	hotelException
	 - Author			:	Anisha
	 - Creation Date	:	03/09/2018
	 - Description		:	function signatures for Admin.
	 ********************************************************************************************************/

public interface IHotelAdminService {

	public abstract boolean checklogin(UserDetails user) throws HotelException;

	public abstract ArrayList<HotelDetails> view_all_hotel() throws HotelException;

	public abstract ArrayList<HotelDetails> view_hotel_city(String city) throws HotelException;
	
	public abstract ArrayList<UserDetails> view_all_user() throws HotelException;

	public abstract void add_hotel(HotelDetails hotel) throws HotelException;

	public abstract boolean delete_hotel(String id) throws HotelException;

	public abstract ArrayList<RoomDetails> room_view(String h_id) throws HotelException;

	public abstract ArrayList<String> display_ids() throws HotelException;

	public abstract void add_room(RoomDetails room) throws HotelException;

	public abstract boolean delete_room(String room_id) throws HotelException;

	public abstract ArrayList<BookingDetails> view_booking(String hotel_id) throws HotelException;
}
