package com.capgemini.hms.service;

import com.capgemini.hms.bean.bookingDetails;
import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.roomDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;

public interface IHotelAdminService {

	public abstract boolean checklogin(userDetails user) throws hotelException;

	public abstract hotelDetails view_all_hotel() throws hotelException;

	public abstract hotelDetails view_hotel_city(String city) throws hotelException;
	
	public abstract void view_all_user() throws hotelException;

	public abstract void add_hotel(hotelDetails hotel) throws hotelException;

	public abstract void delete_hotel(String id) throws hotelException;

	public abstract void room_view(String h_id) throws hotelException;

	public abstract void display_ids() throws hotelException;

	public abstract void add_room(roomDetails room) throws hotelException;

	public abstract void delete_room(String room_id) throws hotelException;

	public abstract bookingDetails view_booking(String hotel_id) throws hotelException;
}
