package com.capgemini.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.roomDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;

public class HotelAdminDaoImp implements IHotelAdminDao {

	Connection conn = DBUtil.getCon();

	

	@Override
	public void view_all_hotel() throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.HOTEL_ALL);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out
						.println("--------------------------------------------------------------------------");
				System.out.println("||Hotel ID:          ||" + rs.getString(1)
						+ "\n||Hotel City:        ||" + rs.getString(2)
						+ "\n||Hotel Name:        ||" + rs.getString(3));

				System.out
						.println("--------------------------------------------------------------------------");

			}

		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public void view_hotel_city(String city) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.HOTEL_CITY);
			pstmt.setString(1, city);
			pstmt.setString(2, city);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				System.out.println("No hotel in this city");
			} else {
				while (rs.next()) {
					System.out
							.println("--------------------------------------------------------------------------");
					System.out.println("||Hotel ID:          ||"
							+ rs.getString(1) + "\n||Hotel City:        ||"
							+ rs.getString(2) + "\n||Hotel Name:        ||"
							+ rs.getString(3) + "\n||Hotel Address:     ||"
							+ rs.getString(4) + "\n||Hotel description: ||"
							+ rs.getString(5) + "\n||Hotel rate of room:||"
							+ rs.getFloat(6) + "\n||Hotel phone 1:     ||"
							+ rs.getString(7) + "\n||Hotel phone 2:     ||"
							+ rs.getString(8) + "\n||Hotel rating:      ||"
							+ rs.getString(9) + "\n||Hotel email:       ||"
							+ rs.getString(10) + "\n||Hotel fax:         ||"
							+ rs.getString(11));
					System.out
							.println("--------------------------------------------------------------------------");
				}
			}
		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public void view_all_user() throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.VIEW_ALL_USER);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out
						.println("--------------------------------------------------------------------------");
				System.out.println("||User ID:      ||" + rs.getString(1)
						+ "\n||User Role:    ||" + rs.getString(3)
						+ "\n||User Name:   ||" + rs.getString(4)
						+ "\n||User Address:||" + rs.getString(6)
						+ "\n||User phone:   ||" + rs.getString(5)
						+ "\n||User email:   ||" + rs.getString(7));
				System.out
						.println("--------------------------------------------------------------------------");

			}

		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public void add_hotel(hotelDetails hotel) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.ADD_HOTEL);
			pstmt.setString(1, hotel.getCity());
			pstmt.setString(2, hotel.getHotel_name());
			pstmt.setString(3, hotel.getAddress());
			pstmt.setString(4, hotel.getDescription());
			pstmt.setFloat(5, hotel.getAvg_rate_per_night());
			pstmt.setString(6, hotel.getPhone_no1());
			pstmt.setString(7, hotel.getPhone_no2());
			pstmt.setString(8, hotel.getRating());
			pstmt.setString(9, hotel.getEmail());
			pstmt.setString(10, hotel.getFax());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.GET_HOTEL_ID);
			pstmt.setString(1, hotel.getHotel_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String hid = rs.getString(1);
				hotel.setHotel_id(hid);
			}
		} catch (SQLException e) {

			throw new hotelException(e.getMessage());
		}

	}

	@Override
	public void delete_hotel(String id) throws hotelException {
		try {
			boolean a = true;
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryManager.HOTEL_ALL);
			System.out.println("Available hotel IDs are:");
			ResultSet rs = pstmt1.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(1));
				if ((rs.getString(1)).equals(id)) {
					a = true;
					break;
				} else {
					a = false;
				}
			}
			if (a == true) {
				PreparedStatement pstmt = conn
						.prepareStatement(IQueryManager.DELETE_HOTEL);
				pstmt.setString(1, id);
				pstmt.executeUpdate();
				System.out.println("hotel with id " + id + " is deleted");
			} else {
				System.out.println("ID does not exist");
			}

		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}
	}

	@Override
	public void room_view(String h_id) throws hotelException {
		display_ids();
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.ROOM_VIEW);
			pstmt.setString(1,h_id);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				System.out
						.println("No hotel with this ID or no rooms in this hotel");
			} else {
				while (rs.next()) {
					if(h_id.equals(rs.getString(1))) {
					String flag = "";
					if ((rs.getString(6)).equals("0")) {
						flag = "avaialable";
					} else
						flag = "not available";

					System.out.println("Room no:" + rs.getString(2)
							+ "\nRoom number:" + rs.getString(3)
							+ "\nRoom Type:" + rs.getString(4)
							+ "\nRoom rate per night:" + rs.getString(5)
							+ "\nAvailability:" + flag);
				}
				}
			}
		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public void display_ids() throws hotelException {
		try {

			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryManager.HOTEL_ALL);
			System.out.println("Available hotel IDs are:");
			ResultSet rs = pstmt1.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(1));
			}
		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}
	}

	@Override
	public void add_room(roomDetails room) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.ADD_ROOM);
			pstmt.setString(1, room.getHotel_id());
			pstmt.setString(2, room.getRoom_no());
			pstmt.setString(3, room.getRoom_type());
			pstmt.setFloat(4, room.getPer_night_rate());
			if (room.getAvailability() == 0)
				pstmt.setString(5, "0");
			else if (room.getAvailability() == 1)
				pstmt.setString(5, "1");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.ROOM_VIEW);
			pstmt.setString(1, room.getHotel_id());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String rid = rs.getString(1);
				room.setRoom_id(rid);
			}
		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}

	}

	@Override
	public void delete_room(String room_id) throws hotelException {
		
		try {
			boolean a = true;
			PreparedStatement pstmt1 = conn
					.prepareStatement(IQueryManager.ROOM_ALL);
			System.out.println("Available room IDs are:");
			ResultSet rs = pstmt1.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(1));
				if ((rs.getString(1)).equals(room_id)) {
					a = true;
					break;
				} else {
					a = false;
				}
			}
			if (a == true) {
				PreparedStatement pstmt = conn
						.prepareStatement(IQueryManager.DELETE_ROOM);
				pstmt.setString(1, room_id);
				pstmt.executeUpdate();
				System.out.println("room with id " + room_id + " is deleted");
			} else {
				System.out.println("ID does not exist");
			}

		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}
		
	}

}
