package com.capgemini.hms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class DBUtil {
	static Logger logger = Logger.getRootLogger();
	static Connection conn = null;

	public static Connection getCon() {
		try {
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "system",
					"anisha");
		} catch (SQLException e) {
			logger.error(e.getMessage());

		}
		return conn;
	}
}
