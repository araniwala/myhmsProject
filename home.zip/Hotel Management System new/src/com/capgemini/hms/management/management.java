package com.capgemini.hms.management;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.roomDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;
import com.capgemini.hms.login.loginUsers;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

public class management {
	static Scanner s = null;
	static BufferedReader bf = null;
	static userDetails user = new userDetails();
	static hotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static loginUsers uLogin = null;
	static Logger logger = Logger.getRootLogger();
	static management mngmt = null;
	static roomDetails room = null;

	public boolean hotelmngmt() throws hotelException {
		s = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new loginUsers();
		hotel = new hotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new management();
		bf = new BufferedReader(new InputStreamReader(System.in));
		System.out.println(
				"||Hotel Management Tasks:|| \n[1]:Add Hotel\t [2]:Delete Hotel\t [3]:Modify Hotel\t [4]:To exit");
		int choice = s.nextInt();
		switch (choice) {
		case 1: {
			System.out.println("Enter the Details for The hotel");
			System.out.println("Name:");
			String name = s.next();
			hotel.setHotel_name(name);
			System.out.println("City:");
			String city = s.next();
			while (service.isValidName(city) == false) {
				System.out.println("Enter valid city");
				city = s.next();
			}
			hotel.setCity(city);
			System.out.println("Address:");
			try {
				String address = bf.readLine();
				hotel.setAddress(address);
				System.out.println("Description:");
				String desc = bf.readLine();
				hotel.setDescription(desc);
			} catch (IOException e) {
				throw new hotelException(e.getMessage());
			}

			System.out.println("Average Rate Per night:");
			float rate = s.nextFloat();
			hotel.setAvg_rate_per_night(rate);
			System.out.println("Phone Number 1:");
			String phone1 = s.next();
			while (service.isValidNumber(phone1) == false) {
				System.out.println("Enter valid phone number");
				phone1 = s.next();
			}
			hotel.setPhone_no1(phone1);
			System.out.println("Phone Number 2:");
			String phone2 = s.next();
			while (service.isValidNumber(phone2) == false) {
				System.out.println("Enter valid phone number");
				phone2 = s.next();
			}
			hotel.setPhone_no2(phone2);
			System.out.println("Rating:");
			String rating = s.next();
			hotel.setRating(rating);
			System.out.println("Email:");
			String email = s.next();
			while (service.isValidEmail(email) == false) {
				System.out.println("Enter valid email");
				email = s.next();
			}
			hotel.setEmail(email);
			System.out.println("Fax:");
			String fax = s.next();
			while (service.isValidNumber(fax) == false) {
				System.out.println("Enter valid phone number");
				fax = s.next();
			}
			hotel.setFax(fax);

			s_admin.add_hotel(hotel);

			System.out.println("Hotel ID for the added hotel is:" + hotel.getHotel_id());

		}
			break;
		case 2: {
			s_admin.display_ids();
			System.out.println("Enter the hotel Id to be deleted");
			String id = s.next();
			s_admin.delete_hotel(id);
		}
			break;

		case 3: {
			System.out.println("Enter the hotel Id to be modify");
			String id = s.next();
		}
			break;
		case 4: {
			return false;
		}

		}
		return true;

	}

	public boolean room_mngmt() throws hotelException {
		s = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new loginUsers();
		hotel = new hotelDetails();
		s_admin = new HotelAdminServiceImp();
		room = new roomDetails();
		mngmt = new management();
		System.out.println(
				"||Room Management Tasks:|| \n[1]:View Rooms\t [2]:Add Room\t [3]:Delete Room\t [4]:Modify Room\t [5]:To exit");
		int choice = s.nextInt();
		switch (choice) {
		case 1: {
			System.out.println("Enter the hotel ID, to view rooms");
			String h_id = s.next();
			s_admin.room_view(h_id);
		}
			break;
		case 2: {
			s_admin.display_ids();
			System.out.println("Enter details of the room to be added");
			System.out.println("Enter the hotel ID:");
			String hotel_id = s.next();
			room.setHotel_id(hotel_id);
			System.out.println("Enter the room number:");
			String room_no = s.next();
			room.setRoom_no(room_no);
			System.out.println("Enter the room type:(choose one)");
			System.out.println("[1] AC-Delux");
			System.out.println("[2] Non-AC-Delux");
			System.out.println("[3] AC-Standard");
			System.out.println("[4] Non-AC-Standard");
			int choose = s.nextInt();
			if (choose == 1)
				room.setRoom_type("AC-Delux");
			else if (choose == 2)
				room.setRoom_type("Non-AC-Delux");
			else if (choose == 3)
				room.setRoom_type("AC-Standard");
			else if (choose == 4)
				room.setRoom_type("Non-AC-Standard");
			else
				System.out.println("choose one of the above");

			System.out.println("Enter the rate per night");
			float rate = s.nextFloat();
			room.setPer_night_rate(rate);
			System.out.println("Enter the Availability:(choose one)");
			System.out.println("[0] Avaialable");
			System.out.println("[1] Unavaialable");
			int choose1 = s.nextInt();
			if (choose1 == 0)
				room.setAvailability(0);
			else if (choose1 == 1)
				room.setAvailability(1);
			else
				System.out.println("choose correctly");

			s_admin.add_room(room);

			System.out.println("Room ID for the added room is:" + room.getRoom_id());
		}
			break;
		case 3: {
			System.out.println("enter the room Id to be deleted");
			String room_id = s.next();
			s_admin.delete_room(room_id);
		}
			break;
		case 5:
			return false;
		}
		return true;

	}
}
