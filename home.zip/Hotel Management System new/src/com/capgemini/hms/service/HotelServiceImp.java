package com.capgemini.hms.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.dao.HotelDaoImp;
import com.capgemini.hms.dao.IHotelDao;
import com.capgemini.hms.exception.hotelException;

public class HotelServiceImp implements IHotelService {

	IHotelDao hd = new HotelDaoImp();

	@Override
	public boolean checklogin(userDetails user) throws hotelException {

		return hd.checklogin(user);
	}

	@Override
	public void view_all_hotel() throws hotelException {
		hd.view_all_hotel();

	}

	@Override
	public void view_hotel_city(String city) throws hotelException {
		if (isValidName(city) == true)
			hd.view_hotel_city(city);
		else
			System.out.println("Enter valid city name");
	}

	@Override
	public void register_new_customer(userDetails user) throws hotelException {
		hd.register_new_customer(user);
	}

	@Override
	public void register_new_employee(userDetails user) throws hotelException {
		hd.register_new_employee(user);
	}

	@Override
	public void view_room_hotel(String name) throws hotelException {
		if (isValidName(name) == true)
			hd.view_room_hotel(name);
		else
			System.out.println("Enter valid hotel name");
	}

	@Override
	public void room_type(String option) throws hotelException {
		hd.room_type(option);
	}

	@Override
	public boolean isValidName(String name) {

		Pattern p = Pattern.compile("^[A-Za-z\\s]{1,}$");
		Matcher m = p.matcher(name);
		return m.matches();
	}

	@Override
	public boolean isValidUser(String user) {
		Pattern p = Pattern.compile("^(emp|cus|adm)[0-9]{1,2}$");
		Matcher m = p.matcher(user);
		return m.matches();
	}

	@Override
	public boolean isValidNumber(String phone) {
		Pattern p = Pattern.compile("(9|8|7){1}[0-9]{9}$");
		Matcher m = p.matcher(phone);
		return m.matches();
	}

	@Override
	public boolean isValidEmail(String email) {
		Pattern p = Pattern.compile("[A-Za-z0-9]{1,20}@[A-Za-z0-9]{1,7}.[a-z]{1,3}$");
		Matcher m = p.matcher(email);
		return m.matches();
	}
	
	

}
