package com.capgemini.hms.login;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;
import com.capgemini.hms.management.management;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

public class loginUsers {

	static Scanner s = null;
	static BufferedReader bf = null;
	static userDetails user = new userDetails();
	static hotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static loginUsers uLogin = null;
	static Logger logger = Logger.getRootLogger();
	static management mngmt = null;

	public String register() throws hotelException {
		bf = new BufferedReader(new InputStreamReader(System.in));
		s = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new loginUsers();
		hotel = new hotelDetails();
		s_admin = new HotelAdminServiceImp();
		System.out.println("Register new user:");
		System.out.println("Enter name:");
		String user_name = s.next();
		user.setUser_name(user_name);
		System.out.println("Enter Password: ");
		String pass = s.next();
		user.setPassword(pass);
		System.out.println("Enter your role: (Choose one:\n[1]:Employee [2]:Customer)");
		int role = s.nextInt();
		if (role == 1)
			user.setRole("Employee");
		else if (role == 2)
			user.setRole("Customer");
		System.out.println("Enter phone number");
		String phone = s.next();
		while (service.isValidNumber(phone) == false) {
			System.out.println("Enter valid phone number");
			phone = s.next();
		}
		user.setPhone(phone);
		System.out.println("Enter Address:");
		String address;
		try {
			address = bf.readLine();
			user.setAddress(address);
		} catch (IOException e) {
			throw new hotelException(e.getMessage());
		}
		System.out.println("Enter email:");
		String email = s.next();
		while (service.isValidEmail(email) == false) {
			System.out.println("Enter valid email");
			email = s.next();
		}
		if (user.getRole().equals("Admin")) {
			System.out.println("NO registration for Admin");
			uLogin.register();
		} else if (user.getRole().equals("Customer")) {
			service.register_new_customer(user);
		} else if (user.getRole().equals("Employee")) {
			service.register_new_employee(user);
		}
		return user.getUser_id();

	}

	public String login() throws hotelException {

		bf = new BufferedReader(new InputStreamReader(System.in));
		s = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new loginUsers();
		hotel = new hotelDetails();
		s_admin = new HotelAdminServiceImp();
		boolean flag = true;
		System.out.println("User ID:");
		String user_id = s.next();
		System.out.println("Password:");
		String password = s.next();
		user.setUser_id(user_id);
		user.setPassword(password);
		flag = service.checklogin(user);
		if (flag == true) {
			System.out.println("user exsists");
		} else {
			System.out.println("check again");
			System.out.println("Enter right credentials");
			System.out.println("Login if exsisting user or Register for further operations");
			System.out.println("Press 1 to login");
			System.out.println("Press 2 to Register");
			int login = s.nextInt();
		if (login == 1) {
				uLogin.login();
			} else {
				uLogin.register();
			}
		}
		return user_id;
	}

}
