
select * from users where user_id='emp4';

delete from users where user_id='adm4';

select * from hotel where (LOWER(city)='chennai' or upper(city)='CHENNAI') order by hotel_id;

select * from hotel;

delete from HOTEL where hotel_id='hot01';

SELECT * FROM ROOM_DETAILS;
SELECT * FROM BOOKING_DETAILS;
SELECT * FROM ROOM_DETAILS WHERE HOTEL_ID='hot01';

drop sequence hotel_id_seq;
insert into USERS values(('adm'||to_char(user_id_admin.nextval)),'abc','admin','anisha','9876543210','residence','anisha@cg.com');
insert into USERS values(('cus'||to_char(user_id_cust.nextval)),'cherry','customer','Cherry','9876543210','residence','cherry@cg.com');

drop table booking_details;

ALTER TABLE room_details ADD CONSTRAINT check_avail CHECK (availability IN ('0','1'));

insert into ROOM_DETAILS values('hot1',('room'||to_char(room_id_seq.nextval)),'101','AC-Delux',5000,'0');
insert into ROOM_DETAILS values('hot2',('room'||to_char(room_id_seq.nextval)),'101','Non-AC-Delux',2500,'0');
select * from ROOM_DETAILS;

drop table hotel;

alter table hotel modify avg_rate_per_night number(10,2);
alter table hotel modify email varchar(30);


insert into HOTEL values('hot1','agra','Oberoi Amar Villas','Taj Road,Agra','5 star hotel',5000,'9876543210','9876543210','5','amarvilla.com','022-12546');
insert into HOTEL values('hot2','delhi','The taj','modern town','4 star hotel',3000,'9876543210','9876543210','4','taj.com','022-1254689');

delete from hotel where hotel_id='hot3';

SELECT r.*,h.hotel_name from room_details r,hotel h where room_type='AC-Delux' and r.hotel_id=h.hotel_id;


select * from room_details where hotel_id in (select hotel_id from hotel where lower(hotel_name)='oberoi amar villas');