package com.capgemini.hms.UI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;
import com.capgemini.hms.login.LoginUsers;
import com.capgemini.hms.management.EmployeeManagement;
import com.capgemini.hms.management.Management;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

//------------------------ Hotel Management System --------------------------
/*******************************************************************************************************
 * - Class Name : Main class - Input Parameters : Scanner User Input - Throws :
 * hotelException - Author : Anisha - Creation Date : 03/09/2018 - Description :
 * Calls all the functions and displays output accordingly.
 ********************************************************************************************************/

public class Hotel {

	static Scanner scanner = null;
	static BufferedReader buffer = null;
	static UserDetails user = null;
	static HotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static LoginUsers uLogin = null;
	static Logger logger = Logger.getRootLogger();
	static Management mngmt = null;
	static BookingDetails book = null;

	public static void main(String[] args) throws HotelException {

		scanner = new Scanner(System.in);
		user = new UserDetails();
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		book = new BookingDetails();
		buffer = new BufferedReader(new InputStreamReader(System.in));
		int check = 0;
		String user_id = null;

		try {
			System.out.println("--------------------------------------------------");
			System.out.println("||\tWelcome to Hotel Booking portal\t\t||");
			System.out.println("--------------------------------------------------");
			System.out.println("||\t\tPress [1] to login\t\t||");
			System.out.println("||\t\tPress [2] to Register\t\t||");
			System.out.println("||\t\tPress [3] to Exit\t\t||");
			System.out.println("--------------------------------------------------");
			int login = scanner.nextInt();
			if (login == 1) {
				user_id = uLogin.login();
				logger.info("LOGGED IN " + user_id);
			} else if (login == 3) {
				System.exit(0);
			} else if (login == 2) {
				user_id = uLogin.register();
				System.out.println("User ID for you is:" + user_id + "\nNow you can login");
				uLogin.login();
				logger.info("REGISTERED " + user_id);
			} else {
				System.out.println("Enter valid option");
				main(args);
			}
			if (user_id.contains("adm")) {

				System.out.println("You are logged in as Admin");

				while (true) {
					System.out.println("---------------------------------");
					System.out.println("||Press [1] to Manage hotels   ||");
					System.out.println("||Press [2] to manage Rooms    ||");
					System.out.println("||Press [3] to generate Reports||");
					System.out.println("||Press [4] to Exit            ||");
					System.out.println("---------------------------------");

					String dummy = "";
					int forward = 0;
					dummy = buffer.readLine();
					for (int i = 1; i < 5; i++) {
						if (dummy.equals(Integer.toString(i))) {
							forward = 1;
							break;
						}
					}

					if (forward == 1) {
						check = Integer.parseInt(dummy);
						switch (check) {
						case 1: {
							mngmt.hotelMngmt();
						}
							break;
						case 2: {
							mngmt.roomMngmt();
						}
							break;
						case 4: {
							System.out.println("You are logged out");
							System.exit(0);
							logger.info("EXITED");
						}
							break;

						case 3: {
							String option="";
							do {
								System.out
										.println("------------------------------------------------------------------");
								System.out.println("||\tPress [1] to view all hotels\t\t\t\t||");
								System.out.println("||\tPress [2] to view hotels w.r.t to city\t\t\t||");
								System.out.println("||\tPress [3] to view all users\t\t\t\t||");
								System.out.println("||\tPress [4] to view booking of specific hotel\t\t||");
								System.out.println("||\tPress [5] to view booking by date\t\t\t||");
								System.out.println("||\tPress [6] to generate guest list of particular hotel\t||");
								System.out.println("||\tPress [7] to login as different user\t\t\t||");
								System.out.println("||\tPress [8] to Exit\t\t\t");
								System.out
										.println("------------------------------------------------------------------");
								option = buffer.readLine();
								switch (option) {
								case "1": {
									ArrayList<HotelDetails> hotelDetails = new ArrayList<>();
									hotelDetails = s_admin.viewAllHotel();
									if (hotelDetails == null) {
										System.out.println("no hotels");
									} else {
										System.out.println(
												"--------------------------------------------------------------------------");
										System.out.println("||Hotel ID:\t\t||Hotel City:\t\t||Hotel Name:\t\t||");
										System.out.println(
												"--------------------------------------------------------------------------");
										for (HotelDetails hotel1 : hotelDetails) {
											System.out.println("||" + hotel1.getHotel_id() + "\t\t\t||"
													+ hotel1.getCity() + "\t\t\t||" + hotel1.getHotel_name() + "\t||");
										}
										System.out.println(
												"--------------------------------------------------------------------------");
									}
									logger.info("VIEWED ALL HOTELS");
								}
									break;
								case "5": {
									ArrayList<BookingDetails> booking = new ArrayList<>();
									System.out.println("Enter date to see the bookings: (dd/mm/yyyy)");
									String startDate = buffer.readLine();
									while (service.isValidDate(startDate) == false) {
										System.out.println("Enter valid Date in the given format: (dd/mm/yyyy)");
										startDate = buffer.readLine();
									}
									booking = s_admin.viewByDate(service.dateChange(startDate));
									if (booking == null) {
										System.out.println("No bookings for this date");
									} else {
										System.out.println("Bookings are:");
										for (BookingDetails book : booking) {

											System.out.println("\n||Booking ID: 	 ||" + book.getBooking_id()
													+ "\n||Room ID:	 ||" + book.getRoom_id() + "\n||User ID:	 ||"
													+ book.getUser_id() + "\n||Booked From:	 ||" + book.getBooked_from()
													+ "\n||Booked till:	 ||" + book.getBooked_to()
													+ "\n||No of adults:	 ||" + book.getNo_of_adults()
													+ "\n||No of children:||" + book.getNo_of_children()
													+ "\n||Amount:	 ||" + book.getAmount());
										}
									}
									logger.info("Viewed all bookings for a particular date:" + startDate);
								}
									break;
								case "7":
									main(args);
									break;

								case "6": {
									System.out.print("Enter the hotel ID for which the report has to be generated");
									String hotel_id = buffer.readLine();
									while (service.isValidHotel_id(hotel_id) == false) {
										System.out.println("Enter valid hotel ID");
										hotel_id = buffer.readLine();
									}
									ArrayList<String[]> guests = new ArrayList<>();
									guests = s_admin.guestList(hotel_id);
									if (guests == null) {
										System.out.println("no guests in this hotel");
									} else {
										System.out
												.println("----------------------------------------------------------");
										System.out.println("||Booking ID\t||User ID\t||User Name\t||");
										System.out
												.println("----------------------------------------------------------");

										for (String[] guest : guests) {
											System.out.println(
													"||" + guest[1] + "\t||" + guest[2] + "\t\t||" + guest[3] + "\t||");
										}
										System.out
												.println("----------------------------------------------------------");
									}
								}
									break;
								case "2": {
									System.out.println("Enter the city:");
									String city = buffer.readLine();
									while(service.isValidName(city)==false)
									{
										System.out.println("Enter valid city");
										city=buffer.readLine();
									}
									ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
									hotelDetail = s_admin.viewHotelByCity(city);
									if (hotelDetail == null) {
										System.out.println("no hotels in this city");
									} else {
										for (HotelDetails hotel1 : hotelDetail) {
											System.out.println(
													"--------------------------------------------------------------------------");
											System.out.println("||Hotel City:        		||" + hotel1.getCity()
													+ "\n||Hotel Name:        		||" + hotel1.getHotel_name()
													+ "\n||Hotel Address:     		||" + hotel1.getAddress()
													+ "\n||Hotel description: 		||" + hotel1.getDescription()
													+ "\n||Hotel rate of room per night: ||"
													+ hotel1.getAvg_rate_per_night() + "\n||Hotel phone 1:     		||"
													+ hotel1.getPhone_no1() + "\n||Hotel phone 2:     		||"
													+ hotel1.getPhone_no2() + "\n||Hotel rating:      		||"
													+ hotel1.getRating() + "\n||Hotel email:       		||"
													+ hotel1.getEmail() + "\n||Hotel fax:         		||"
													+ hotel1.getFax());
											System.out.println(
													"--------------------------------------------------------------------------");
										}
									}
									logger.info("VIEWED ALL HOTELS by city");
								}
									break;
								case "3": {
									System.out.println("All the Registered users are:");
									ArrayList<UserDetails> userdetails = new ArrayList<>();
									userdetails = s_admin.viewAllUser();
									for (UserDetails user1 : userdetails) {
										System.out.println(
												"--------------------------------------------------------------------------");
										System.out.println("||User ID:      ||" + user1.getUser_id()
												+ "\n||User Role:    ||" + user1.getRole() + "\n||User Name:    ||"
												+ user1.getUser_name() + "\n||User Address: ||" + user1.getAddress()
												+ "\n||User phone:   ||" + user1.getPhone() + "\n||User email:   ||"
												+ user1.getEmail());
										System.out.println(
												"--------------------------------------------------------------------------");
									}
									logger.info("VIEWED ALL users");
								}
									break;
								case "4": {
									ArrayList<BookingDetails> booking = new ArrayList<>();
									System.out.println("Enter the hotel Id:");
									String hotel_id = buffer.readLine();
									while (service.isValidHotel_id(hotel_id) == false) {
										System.out.println("Enter valid hotel ID");
										hotel_id = buffer.readLine();
									}
									booking = s_admin.viewBooking(hotel_id);
									if (booking == null) {
										System.out.println("No bookings in this hotel");
									} else {
										System.out.println("Bookings are:");
										for (BookingDetails book : booking) {

											System.out.println("||Booking ID: 	 ||" + book.getBooking_id()
													+ "\n||Room ID:	 ||" + book.getRoom_id() + "\n||User ID:	 ||"
													+ book.getUser_id() + "\n||Booked From:	 ||" + book.getBooked_from()
													+ "\n||Booked till:	 ||" + book.getBooked_to()
													+ "\n||No of adults:	 ||" + book.getNo_of_adults()
													+ "\n||No of children:||" + book.getNo_of_children()
													+ "\n||Amount:	 ||" + book.getAmount());
										}
									}
									logger.info("Viewed all bookings for a particular hotel");
								}
									break;
								}
							} while (Integer.parseInt(option)<0 || Integer.parseInt(option)>8 );
						}
						break;
						}

					} else {
						System.err.println("Enter valid option");
					}

				}

			} else if ((user_id.contains("cus"))) {
				System.out.println("You are logged in as Customer");

				while (true) {
					System.out.println("--------------------------------------------------------------------------");
					System.out.println("||\tPress [1] for all hotels\t\t||");
					System.out.println("||\tPress [2] for hotels w.r.t to city\t||");
					System.out.println("||\tPress [3] to Make a booking\t\t||");
					System.out.println("||\tPress [4] to view booking status\t||");
					System.out.println("||\tPress [5] to login as different user\t||");
					System.out.println("||\tPress [6] to exit\t\t\t||");
					System.out.println("--------------------------------------------------------------------------");

					String dummy = "";
					int forward = 0;
					dummy = buffer.readLine();
					for (int i = 1; i < 7; i++) {
						if (dummy.equals(Integer.toString(i))) {
							forward = 1;
							break;
						}
					}

					if (forward == 1) {
						check = Integer.parseInt(dummy);
						switch (check) {

						case 1: {
							ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
							hotelDetail = service.viewAllHotel();
							for (HotelDetails hotel1 : hotelDetail) {
								System.out.println(
										"--------------------------------------------------------------------------");
								System.out.println("||Hotel City:        		||" + hotel1.getCity()
										+ "\n||Hotel Name:        		||" + hotel1.getHotel_name()
										+ "\n||Hotel Address:     		||" + hotel1.getAddress()
										+ "\n||Hotel description: 		||" + hotel1.getDescription()
										+ "\n||Hotel rate of room per night: ||" + hotel1.getAvg_rate_per_night()
										+ "\n||Hotel phone 1:     		||" + hotel1.getPhone_no1()
										+ "\n||Hotel phone 2:     		||" + hotel1.getPhone_no2()
										+ "\n||Hotel rating:      		||" + hotel1.getRating()
										+ "\n||Hotel email:       		||" + hotel1.getEmail()
										+ "\n||Hotel fax:         		||" + hotel1.getFax());
								System.out.println(
										"--------------------------------------------------------------------------");
							}
							logger.info("VIEWED ALL hotels");
						}
							break;
						case 2: {
							System.out.println("Enter the city:");
							String city = buffer.readLine();
							while (service.isValidName(city) == false) {
								System.out.println("Enter valid hotel ID");
								city = buffer.readLine();
							}
							ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
							hotelDetail = service.viewHotelByCity(city);
							if (hotelDetail == null) {
								System.out.println("no hotel in this city");
							} else {
								for (HotelDetails hotel1 : hotelDetail) {
									System.out.println(
											"--------------------------------------------------------------------------");
									System.out.println("||Hotel City:        		||" + hotel1.getCity()
											+ "\n||Hotel Name:        		||" + hotel1.getHotel_name()
											+ "\n||Hotel Address:     		||" + hotel1.getAddress()
											+ "\n||Hotel description: 		||" + hotel1.getDescription()
											+ "\n||Hotel rate of room per night: ||" + hotel1.getAvg_rate_per_night()
											+ "\n||Hotel phone 1:     		||" + hotel1.getPhone_no1()
											+ "\n||Hotel phone 2:     		||" + hotel1.getPhone_no2()
											+ "\n||Hotel rating:      		||" + hotel1.getRating()
											+ "\n||Hotel email:       		||" + hotel1.getEmail()
											+ "\n||Hotel fax:         		||" + hotel1.getFax());
									System.out.println(
											"--------------------------------------------------------------------------");
								}
							}
							logger.info("VIEWED ALL HOTELS by city");
						}
							break;
						case 5:
							main(args);
							break;
						case 6:
							System.exit(0);

							break;
						case 3: {
							System.out.println("||\tChoose the options to make a booking:\t||");
							mngmt.bookingMngmt(user_id);
							logger.info("booking made");
						}
							break;
						case 4: {
							ArrayList<BookingDetails> booking = new ArrayList<>();
							booking = service.viewBooking(user_id);

							if (booking == null) {
								System.out.println("No bookings done");
							} else {
								System.out.println("Bookings made are:");

								for (BookingDetails book : booking) {
									System.out.println("\n||Booking ID: 	 ||" + book.getBooking_id()
											+ "\n||Room ID:	 ||" + book.getRoom_id() + "\n||User ID:	 ||"
											+ book.getUser_id() + "\n||Booked From:	 ||" + book.getBooked_from()
											+ "\n||Booked till:	 ||" + book.getBooked_to() + "\n||No of adults:	 ||"
											+ book.getNo_of_adults() + "\n||No of children:||"
											+ book.getNo_of_children() + "\n||Amount:	 ||" + book.getAmount());
								}
								logger.info("booking status viewed");
							}
						}
						}
					} else {
						System.err.println("Enter valid option");
					}
				}
			} else if (user_id.contains("emp")) {
				EmployeeManagement emp_mngmt = new EmployeeManagement();
				emp_mngmt.employee();
			}
		} catch (InputMismatchException e) {
			logger.error(e);
			System.err.println("check again");
			
			Hotel.main(args);
		} catch (IOException e) {
			logger.error(e);
			System.err.println("check again");
			
			Hotel.main(args);
		}
	}
}
