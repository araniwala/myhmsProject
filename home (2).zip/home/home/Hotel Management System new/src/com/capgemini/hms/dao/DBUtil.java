package com.capgemini.hms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class DBUtil {
	static Logger logger = Logger.getRootLogger();
	static Connection conn = null;

	public static Connection getCon() {
		try {
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg207",
					"training207");
		} catch (SQLException e) {
			logger.error(e);

		}
		
		return conn;
		
	}
}
