package com.capgemini.hms.dao;



//------------------------ Hotel Management System --------------------------
	/*******************************************************************************************************
	 - Interface Name	:	IQueryMapper 
	 - Throws			:  	hotelException
	 - Author			:	Anisha
	 - Creation Date	:	03/09/2018
	 - Description		:	All the queries used in this project for transaction with database.
	 ********************************************************************************************************/

public interface IQueryMapper {
	
//USERS TABLE
	public final static String USERID_CHECK="SELECT user_id,user_name from users where user_id=?";
	public final static String USER_LOGIN_QUERY="Select user_id,password from users where user_id=? and password=?";
	public final static String USERID_GET = "SELECT user_id FROM users where user_name=?";
	public final static String USER_ALL_VIEW="SELECT * FROM users order by user_id";
	public final static String REGISTER_NEW_CUSTOMER="INSERT INTO USERS VALUES(('cus'||to_char(user_id_cust.nextval)),?,?,?,?,?,?)";
	public final static String REGISTER_NEW_EMPLOYEE="INSERT INTO USERS VALUES(('emp'||to_char(user_id_staff.nextval)),?,?,?,?,?,?)";
	
//HOTEL TABLE
	public final static String HOTEL_ALL="select * from hotel order by hotel_id";
	public final static String HOTEL_ALL_ID="select * from hotel where hotel_id=?";
	public final static String HOTEL_MODIFY="update hotel set "+ HotelAdminDaoImp.column_name1 +"=? where hotel_id=?";
	public final static String HOTEL_ID_GET = "SELECT hotel_id FROM hotel where hotel_name=? order by hotel_id";
	public final static String HOTEL_ADD="INSERT INTO HOTEL VALUES(('hot'||to_char(hotel_id_seq.nextval)),?,?,?,?,?,?,?,?,?,?)";
	public final static String HOTEL_DELETE="DELETE FROM HOTEL WHERE hotel_id=?";
	public final static String HOTEL_CITY="select * from hotel where (lower(city)=? OR UPPER(CITY)=?) order by hotel_id";
//ROOM TABLE
	public final static String ROOM_MODIFY="update hotel set "+ HotelAdminDaoImp.column_name1 +"=? where room_id=?";
	public final static String ROOM_VIEW="SELECT * FROM ROOM_DETAILS WHERE lower(HOTEL_ID)=?";
	public final static String ROOM_ALL="SELECT room_id FROM ROOM_DETAILS";
	public final static String ROOM_AMOUNT="SELECT per_night_rate FROM ROOM_DETAILS WHERE ROOM_ID=?";
	public final static String ROOM_ADD="INSERT INTO ROOM_DETAILS VALUES(?,('room'||to_char(room_id_seq.nextval)),?,?,?,?)";
	public final static String ROOM_DELETE="DELETE FROM ROOM_DETAILS WHERE ROOM_ID=?";
	public final static String ROOM_BY_ID="SELECT * FROM ROOM_DETAILS WHERE ROOM_ID=?";
	public final static String ROOM_TYPE="SELECT r.*,h.hotel_name from room_details r,hotel h where room_type=? and r.hotel_id=h.hotel_id";
	public final static String ROOM_HOTEL="SELECT * from room_details where hotel_id in (select hotel_id from hotel where (lower(hotel_name)=? or upper(hotel_name)=?))";
	public final static String ROOM_TYPE_AVAIL="SELECT r.*,h.hotel_name from room_details r,hotel h where room_type=? and r.hotel_id=h.hotel_id and availability='0'";
	
//BOOKING TABLE
	public final static String BOOKING_VIEW="SELECT ROOM_ID,booked_from,booked_to FROM BOOKING_DETAILS where room_id=?";
	public final static String BOOK_ROOM="INSERT INTO BOOKING_DETAILS VALUES(booking_seq.nextval,?,?,?,?,?,?,?)";
	public final static String BOOKING_BY_USERID_VIEW="SELECT booking_id,room_id,user_id,to_char(booked_from,'dd/mm/yyyy'),to_char(booked_to,'dd/mm/yyyy'),no_of_adults,no_of_children,amount FROM BOOKING_Details WHERE USER_ID=?";
	public final static String BOOKING_HOTEL_VIEW="SELECT b.booking_id,b.room_id,b.user_id,to_char(b.booked_from,'dd/mm/yyyy'),to_char(b.booked_to,'dd/mm/yyyy'),b.no_of_adults,b.no_of_children,b.amount FROM BOOKING_Details b,room_details r WHERE r.hotel_id=? and r.room_id=b.room_id";
	public final static String BOOKING_BY_DATE_VIEW="SELECT b.booking_id,b.room_id,b.user_id,to_char(b.booked_from,'dd/mm/yyyy'),to_char(b.booked_to,'dd/mm/yyyy'),b.no_of_adults,b.no_of_children,b.amount FROM BOOKING_DETAILS b WHERE BOOKED_FROM<=? AND BOOKED_TO>=?";
	public final static String BOOKED_GUEST_LIST="SELECT B.BOOKING_ID,u.USER_ID,u.user_name FROM BOOKING_DETAILS B,ROOM_DETAILS R,HOTEL H,USERS U WHERE B.ROOM_ID=R.ROOM_ID AND R.HOTEL_ID=H.HOTEL_ID AND B.user_id=u.user_id and h.hotel_id=?";
}
