/*USER TABLE CREATION*/
CREATE TABLE USERS (user_id varchar(6) PRIMARY KEY,
password varchar(7),
role varchar(10),
user_name varchar (20),
phone varchar(10),
address varchar(25),
email varchar(15));

 drop table users;
/*HOTEL TABLE CREATION*/
CREATE TABLE HOTEL (hotel_id varchar(6) PRIMARY KEY,
city varchar(10),
hotel_name varchar (20),
address varchar(25),
description varchar(50),
avg_rate_per_night number(10,2),
phone_no1 varchar(10),
phone_no2 varchar(10),
rating varchar(4),
email varchar(15),
fax varchar(15));

drop table hotel;

alter table hotel modify avg_rate_per_night number(10,2);


insert into HOTEL values('hot'||to_char(hotel_id_seq.nextval),'agra','Oberoi Amar Villas','Taj Road,Agra','5 star hotel',5000,'9876543210','9876543210','5','amarvilla.com','022-12546');
insert into HOTEL values('hot'||to_char(hotel_id_seq.nextval),'delhi','The taj','modern town','4 star hotel',3000,'9876543210','9876543210','4','taj.com','022-1254689');

delete from hotel where hotel_id='hot3';

/*Room Details table creation*/
CREATE TABLE ROOM_DETAILS(
hotel_id varchar(6) REFERENCES HOTEL(hotel_id),
room_id varchar(6) PRIMARY KEY,
room_no varchar(3),
room_type varchar(20),
per_night_rate number(10,2),
availability varchar(1),
photo blob
);
drop table room_details;
/*booking_details table creation*/
CREATE TABLE BOOKING_DETAILS(
booking_id varchar(6) PRIMARY KEY,
room_id varchar(6) REFERENCES room_details(room_id),
user_id varchar(6) REFERENCES users(user_id),
booked_from date,
booked_to date,
no_of_adults number(2),
no_of_children number(2),
amount number(6,2)
);
drop table booking_details;
ALTER TABLE room_details ADD CONSTRAINT check_avail CHECK (availability IN ('0','1'));

CREATE SEQUENCE user_id_cust start with 01 increment by 1;

CREATE SEQUENCE user_id_staff start with 01 increment by 1;

CREATE SEQUENCE user_id_admin start with 01 increment by 1;

CREATE SEQUENCE hotel_id_seq start with 01 increment by 1;

CREATE SEQUENCE room_id_seq start with 01 increment by 1;

drop sequence hotel_id_seq;
insert into USERS values(('adm'||to_char(user_id_admin.nextval)),'abc','admin','anisha','9876543210','residence','anisha@cg.com');
insert into USERS values(('cus'||to_char(user_id_cust.nextval)),'cherry','customer','Cherry','9876543210','residence','cherry@cg.com');


select * from users;


delete from users where user_id='adm4';


select * from hotel;