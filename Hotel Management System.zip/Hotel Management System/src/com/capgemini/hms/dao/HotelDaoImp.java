package com.capgemini.hms.dao;

import java.sql.*;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;

public class HotelDaoImp implements IHotelDao {
	static boolean flag;
	Connection conn = DBUtil.getCon();

	@Override
	public boolean checklogin(userDetails user) throws hotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.LOGIN_QUERY);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				if ((rs.getString(1).equals(user.getUser_id()))
						&& rs.getString(2).equals(user.getPassword())) {
					flag = true;
					break;
				} else
					flag = false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new hotelException(e.getLocalizedMessage());
		}

		return flag;
	}

	@Override
	public void view_all_hotel() throws hotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.HOTEL_ALL);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println("\nHotel ID:" + rs.getString(1)
						+ "\nHotel City:" + rs.getString(2) + "\nHotel Name:"
						+ rs.getString(3) + "\nHotel Address:"
						+ rs.getString(4) + "\nHotel description:"
						+ rs.getString(5) + "\nHotel rate of room:"
						+ rs.getFloat(6) + "\nHotel phone 1:" + rs.getString(7)
						+ "\nHotel phone 2:" + rs.getString(8)
						+ "\nHotel rating:" + rs.getString(9)
						+ "\nHotel phone email:" + rs.getString(10)
						+ "\nHotel fax:" + rs.getString(11));

			}

		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public void view_hotel_city(String city) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.HOTEL_CITY);
			System.out.println(city);
			pstmt.setString(1, city);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println("\nHotel ID:" + rs.getString(1)
						+ "\nHotel City:" + rs.getString(2) + "\nHotel Name:"
						+ rs.getString(3) + "\nHotel Address:"
						+ rs.getString(4) + "\nHotel description:"
						+ rs.getString(5) + "\nHotel rate of room:"
						+ rs.getFloat(6) + "\nHotel phone 1:" + rs.getString(7)
						+ "\nHotel phone 2:" + rs.getString(8)
						+ "\nHotel rating:" + rs.getString(9)
						+ "\nHotel phone email:" + rs.getString(10)
						+ "\nHotel fax:" + rs.getString(11));
			}

		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
	}

	/*@Override
	public void register_new_admin(userDetails user) throws hotelException {
		Connection conn = DBUtil.getCon();
		Logger logger = Logger.getRootLogger();
		System.out.println(user.getUser_name());

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.REGISTER_NEW_ADMIN);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getRole());
			pstmt.setString(3, user.getUser_name());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.GET_ID);
			pstmt.setString(1, user.getUser_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String uid = rs.getString(1);
				user.setUser_id(uid);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new hotelException(e.getMessage());
		}

	}*/

	@Override
	public void register_new_customer(userDetails user) throws hotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.REGISTER_NEW_CUSTOMER);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getRole());
			pstmt.setString(3, user.getUser_name());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.GET_ID);
			pstmt.setString(1, user.getUser_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String uid = rs.getString(1);
				user.setUser_id(uid);
			}
		} catch (SQLException e) {

			throw new hotelException(e.getMessage());
		}
	}

	@Override
	public void register_new_employee(userDetails user) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.REGISTER_NEW_EMPLOYEE);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getRole());
			pstmt.setString(3, user.getUser_name());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.GET_ID);
			pstmt.setString(1, user.getUser_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String uid = rs.getString(1);
				user.setUser_id(uid);
			}
		} catch (SQLException e) {

			throw new hotelException(e.getMessage());
		}
	}

	@Override
	public void view_all_user() throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.VIEW_ALL_USER);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println("\nUser ID:" + rs.getString(1)
						+ "\nUser Role:" + rs.getString(3) + "\nHotel Name:"
						+ rs.getString(4) + "\nHotel Address:"
						+ rs.getString(6) + "\nUser phone:" + rs.getString(5)
						+ "\nUser email:" + rs.getString(7));

			}

		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public void add_hotel(hotelDetails hotel) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.ADD_HOTEL);
			pstmt.setString(1, hotel.getCity());
			pstmt.setString(2, hotel.getHotel_name());
			pstmt.setString(3, hotel.getAddress());
			pstmt.setString(4, hotel.getDescription());
			pstmt.setFloat(5, hotel.getAvg_rate_per_night());
			pstmt.setString(6, hotel.getPhone_no1());
			pstmt.setString(7, hotel.getPhone_no2());
			pstmt.setString(8, hotel.getRating());
			pstmt.setString(9, hotel.getEmail());
			pstmt.setString(10, hotel.getFax());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.GET_HOTEL_ID);
			pstmt.setString(1, hotel.getHotel_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String hid = rs.getString(1);
				hotel.setHotel_id(hid);
			}
		} catch (SQLException e) {

			throw new hotelException(e.getMessage());
		}

	}

	@Override
	public void delete_hotel(String id) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.DELETE_HOTEL);
			pstmt.setString(1, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}
	}

}
