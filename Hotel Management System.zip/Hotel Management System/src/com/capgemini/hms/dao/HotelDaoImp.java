package com.capgemini.hms.dao;

import java.sql.*;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;

public class HotelDaoImp implements IHotelDao {
	static boolean flag;
	Connection conn = DBUtil.getCon();

	@Override
	public boolean checklogin(userDetails user) throws hotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.LOGIN_QUERY);
			pstmt.setString(1, user.getUser_id());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				flag = false;

			} else {
				while (rs.next()) {
					if (user.getUser_id().equals(rs.getString(1))
							&& user.getPassword().equals(rs.getString(2))) {
						System.out.println(rs.getString(1));
						flag = true;
						break;
					}
				}
				System.out.println(flag);

			}
		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}

		return flag;
	}

	@Override
	public void view_all_hotel() throws hotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.HOTEL_ALL);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out
						.println("--------------------------------------------------------------------------");
				System.out.println("||Hotel City:        		||"
						+ rs.getString(2) + "\n||Hotel Name:        		||"
						+ rs.getString(3) + "\n||Hotel Address:     		||"
						+ rs.getString(4) + "\n||Hotel description: 		||"
						+ rs.getString(5)
						+ "\n||Hotel rate of room per night: ||"
						+ rs.getFloat(6) + "\n||Hotel phone 1:     		||"
						+ rs.getString(7) + "\n||Hotel phone 2:     		||"
						+ rs.getString(8) + "\n||Hotel rating:      		||"
						+ rs.getString(9) + "\n||Hotel email:       		||"
						+ rs.getString(10) + "\n||Hotel fax:         		||"
						+ rs.getString(11));
				System.out
						.println("--------------------------------------------------------------------------");

			}

		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}

	}

	@Override
	public void view_hotel_city(String city) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.HOTEL_CITY);
			pstmt.setString(1, city);
			pstmt.setString(2, city);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				System.out.println("No hotel in this city");
			} else {
				while (rs.next()) {
					System.out
							.println("--------------------------------------------------------------------------");
					System.out.println("||Hotel ID:          ||"
							+ rs.getString(1) + "\n||Hotel City:        ||"
							+ rs.getString(2) + "\n||Hotel Name:        ||"
							+ rs.getString(3) + "\n||Hotel Address:     ||"
							+ rs.getString(4) + "\n||Hotel description: ||"
							+ rs.getString(5) + "\n||Hotel rate of room:||"
							+ rs.getFloat(6) + "\n||Hotel phone 1:     ||"
							+ rs.getString(7) + "\n||Hotel phone 2:     ||"
							+ rs.getString(8) + "\n||Hotel rating:      ||"
							+ rs.getString(9) + "\n||Hotel email:       ||"
							+ rs.getString(10) + "\n||Hotel fax:         ||"
							+ rs.getString(11));
					System.out
							.println("--------------------------------------------------------------------------");
				}
			}
		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
	}

	/*
	 * @Override public void register_new_admin(userDetails user) throws
	 * hotelException { Connection conn = DBUtil.getCon(); Logger logger =
	 * Logger.getRootLogger(); System.out.println(user.getUser_name());
	 * 
	 * try { PreparedStatement pstmt = conn
	 * .prepareStatement(IQueryManager.REGISTER_NEW_ADMIN); pstmt.setString(1,
	 * user.getPassword()); pstmt.setString(2, user.getRole());
	 * pstmt.setString(3, user.getUser_name()); pstmt.setString(4,
	 * user.getPhone()); pstmt.setString(5, user.getAddress());
	 * pstmt.setString(6, user.getEmail()); pstmt.executeUpdate(); } catch
	 * (SQLException e) { throw new hotelException(e.getMessage()); } try {
	 * PreparedStatement pstmt = conn .prepareStatement(IQueryManager.GET_ID);
	 * pstmt.setString(1, user.getUser_name()); ResultSet rs =
	 * pstmt.executeQuery(); while (rs.next()) { String uid = rs.getString(1);
	 * user.setUser_id(uid); } } catch (SQLException e) {
	 * logger.error(e.getMessage()); throw new hotelException(e.getMessage()); }
	 * 
	 * }
	 */

	@Override
	public void register_new_customer(userDetails user) throws hotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.REGISTER_NEW_CUSTOMER);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getRole());
			pstmt.setString(3, user.getUser_name());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.GET_ID);
			pstmt.setString(1, user.getUser_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String uid = rs.getString(1);
				user.setUser_id(uid);
			}
		} catch (SQLException e) {

			throw new hotelException(e.getMessage());
		}
	}

	@Override
	public void register_new_employee(userDetails user) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.REGISTER_NEW_EMPLOYEE);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getRole());
			pstmt.setString(3, user.getUser_name());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new hotelException(e.getMessage());
		}
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.GET_ID);
			pstmt.setString(1, user.getUser_name());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String uid = rs.getString(1);
				user.setUser_id(uid);
			}
		} catch (SQLException e) {

			throw new hotelException(e.getMessage());
		}
	}

	@Override
	public void view_room_hotel(String name) throws hotelException {

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.ROOM_HOTEL);
			pstmt.setString(1, name);
			pstmt.setString(2, name);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				System.out.println("No room in this hotel");
			} else {
				while (rs.next()) {
					String flag = "";
					if ((rs.getString(6)).equals("0")) {
						flag = "avaialable";
					} else
						flag = "not available";

					System.out.println("Room ID:" + rs.getString(2)
							+ "\nRoom number:" + rs.getString(3)
							+ "\nRoom Type:" + rs.getString(4)
							+ "\nRoom rate per night:" + rs.getString(5)
							+ "\nAvailability:" + flag);
				}
			}

		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}
	}

	@Override
	public void room_type(String option) throws hotelException {
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryManager.ROOM_TYPE);
			pstmt.setString(1, option);
			ResultSet rs = pstmt.executeQuery();
			if (!rs.isBeforeFirst()) {
				System.out.println("No rooms of this type");
			} else {
				while (rs.next()) {

					String flag = "";
					if ((rs.getString(6)).equals("0")) {
						flag = "avaialable";
					} else
						flag = "not available";

					System.out.println("Hotel Name: 		||" + rs.getString(7)
							+ "\nRoom ID:    		||" + rs.getString(2)
							+ "\nRoom number:		||" + rs.getString(3)
							+ "\nRoom Type:  		||" + rs.getString(4)
							+ "\nRoom rate per night:||" + rs.getString(5)
							+ "\nAvailability:		||" + flag);
				}
			}

		} catch (SQLException e) {
			throw new hotelException(e.getLocalizedMessage());
		}

	}

}
