package com.capgemini.hms.dao;

public interface IQueryManager {
	
	public final static String LOGIN_QUERY="Select user_id,password from users";
	public final static String HOTEL_ALL="select * from hotel";
	public final static String HOTEL_CITY="select * from hotel where city=?";
	//public final static String REGISTER_NEW_ADMIN="INSERT INTO USERS VALUES(('adm'||to_char(user_id_admin.nextval)),?,?,?,?,?,?)";
	public final static String REGISTER_NEW_CUSTOMER="INSERT INTO USERS VALUES(('cus'||to_char(user_id_cust.nextval)),?,?,?,?,?,?)";
	public final static String REGISTER_NEW_EMPLOYEE="INSERT INTO USERS VALUES(('emp'||to_char(user_id_staff.nextval)),?,?,?,?,?,?)";
	public final static String GET_ID = "SELECT user_id FROM users where user_name=?";
	public final static String GET_HOTEL_ID = "SELECT hotel_id FROM hotel where hotel_name=?";
	public final static String VIEW_ALL_USER="SELECT * FROM users";
	public final static String ADD_HOTEL="INSERT INTO HOTEL VALUES(('hot'||to_char(hotel_id_seq.nextval)),?,?,?,?,?,?,?,?,?,?)";
	public final static String DELETE_HOTEL="DELETE FROM HOTEL WHERE hotel_id=?";
}
