package com.capgemini.hms.UI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;
import com.capgemini.hms.login.loginUsers;
import com.capgemini.hms.management.management;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

public class hotel {

	static Scanner s = null;
	static BufferedReader bf = null;
	static userDetails user = null;
	static hotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static loginUsers uLogin = null;
	static Logger logger = Logger.getRootLogger();
	static management mngmt = null;

	public static void main(String[] args) throws hotelException {
		s = new Scanner(System.in);
		user = new userDetails();
		service = new HotelServiceImp();
		uLogin = new loginUsers();
		hotel = new hotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new management();
		bf = new BufferedReader(new InputStreamReader(System.in));
		int check = 0;
		String user_id = null;
		try {
			System.out.println("\tWelcome to Hotel Booking portal");
			System.out
					.println("--------------------------------------------------------------------------");
			System.out
					.println("Login if exsisting user or Register for further operations");
			System.out
					.println("-----------------------------------------------------------------");
			System.out
					.println("||Press 1 to login\t||Press 2 to Register\t||Press 3 to exit");
			System.out
					.println("-----------------------------------------------------------------");
			int login = s.nextInt();
			if (login == 1) {
				user_id = uLogin.login();
				logger.info("LOGGED IN " + user_id);
				if (user_id.contains("adm")) {
					System.out.println("You are logged in as Admin");
					while (true) {

						System.out.println("||Press [1] to Manage hotels   ||");
						System.out
								.println("--------------------------------------------------------------------------");
						System.out.println("||Press [2] to manage Rooms    ||");
						System.out
								.println("--------------------------------------------------------------------------");
						System.out
								.println("||Press [3] to generate Reports         ||");
						System.out
								.println("--------------------------------------------------------------------------");
						System.out.println("||Press [4] to Exit         ||");
						System.out
								.println("----------------------------------------------");
						check = s.nextInt();
						switch (check) {

						case 1: {
							mngmt.hotelmngmt();
						}
							break;
						case 2: {
							mngmt.room_mngmt();
						}
							break;
						case 4: {
							System.exit(0);
							logger.info("EXITED");
						}
							break;
						case 3: {
							System.out
									.println("--------------------------------------------------------------------------");
							System.out
									.println("||Press [1] to view all hotels||Press [2] to view hotels w.r.t to city||");
							System.out
									.println("--------------------------------------------------------------------------");
							System.out
									.println("||Press [3] to view all users||");
							System.out
									.println("--------------------------------------------------------------------------");
							check = s.nextInt();
							switch (check) {

							case 1: {
								s_admin.view_all_hotel();
								logger.info("VIEWED ALL HOTELS");
							}
								break;
							case 2: {
								System.out.println("Enter the city:");
								String city = s.next();
								s_admin.view_hotel_city(city);
								logger.info("VIEWED ALL HOTELS by city");
							}
								break;
							case 3: {
								System.out
										.println("All the Registered users are:");
								s_admin.view_all_user();
								logger.info("VIEWED ALL users");
							}
								break;
							}
						}
						}
					}

				} else if ((user_id.contains("cus"))
						|| (user_id.contains("emp"))) {
					System.out
							.println("You are logged in as Customer/Employee");
					while (true) {
						System.out
								.println("--------------------------------------------------------------------------");
						System.out
								.println("||Press [1] for all hotels\t\t||Press [2] for hotels w.r.t to city");
						System.out
								.println("--------------------------------------------------------------------------");
						System.out
								.println("||Press [3] to show rooms by hotel name\t||Press [4] to show room by type");
						System.out
								.println("--------------------------------------------------------------------------");
						System.out.println("||Press [5] to Exit");
						System.out
								.println("--------------------------------------------------------------------------");

						check = s.nextInt();
						switch (check) {

						case 1: {
							service.view_all_hotel();
						}
							break;
						case 2: {
							System.out
									.println("Enter the city in which you need hotel:");
							String city = s.next();
							service.view_hotel_city(city);
						}
							break;
						case 3: {
							System.out
									.println("Enter the hotel name in which you need rooms");

							try {
								String name = bf.readLine();
								service.view_room_hotel(name);

							} catch (IOException e) {
								throw new hotelException(e.getMessage());
							}

						}
							break;
						case 4: {
							System.out.println("Select one of the room types:");
							System.out
									.println("[1] AC-Delux\t[2] Non-AC-Delux\t[3] AC-standard\t[4] Non-AC-standard");
							int option = s.nextInt();
							if (option == 1)
								service.room_type("AC-Delux");
							else if (option == 2)
								service.room_type("Non-AC-Delux");
							else if (option == 3)
								service.room_type("AC-standard");
							else if (option == 4)
								service.room_type("Non-AC-standard");
							else
								System.out.println("select a valid option");
						}
							break;
						case 5:
							System.exit(0);

						}
					}
				}
			} else if (login == 3) {
				System.exit(0);
			} else {
				user_id = uLogin.register();
				System.out.println("User ID for you is:" + user_id
						+ "\nNow you can login");
				uLogin.login();
				logger.info("REGISTERED " + user_id);
			}

		} catch (InputMismatchException e) {
			throw new hotelException("Please enter the right option ");
		}
	}
}
