package com.capgemini.hms.UI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelService;

public class hotel {

	static Scanner s = null;
	static BufferedReader bf = null;
	static userDetails user = null;
	static hotelDetails hotel = null;
	static IHotelService service = null;
	static hotel uLogin = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws hotelException {
		s = new Scanner(System.in);
		user = new userDetails();
		service = new HotelServiceImp();
		uLogin = new hotel();
		hotel = new hotelDetails();
		int check = 0;

		System.out.println("\tWelcome to Hotel Booking portal");
		System.out
				.println("=========================================================");
		System.out
				.println("Login if exsisting user or Register for further operations");
		System.out.println("----------------------------------------------");
		System.out.println("||Press 1 to login   ||   Press 2 to Register||");
		System.out.println("----------------------------------------------");
		int login = s.nextInt();
		if (login == 1) {
			uLogin.login();
			logger.info("LOGGED IN");
		} else {
			uLogin.register();
			logger.info("REGISTERED");
		}

		if (user.getUser_id().contains("adm")) {
			while (true) {
				System.out.println("\nPress 1 to all hotels");
				System.out.println("Press 2 to hotels w.r.t to city");
				System.out.println("Press 3 to view all users");
				System.out.println("Press 4 to Manage hotels");
				System.out.println("Press 5 to Manage Rooms");
				System.out.println("Press 6 to generate Reports");
				System.out.println("Press 7 to Exit");
				check = s.nextInt();
				switch (check) {

				case 1: {
					service.view_all_hotel();
					logger.info("VIEWED ALL HOTELS");
				}
					break;
				case 2: {
					System.out.println("Enter the city:");
					String city = s.next();
					service.view_hotel_city(city);
				}
					break;
				case 3: {

					System.out.println("All the Registered users are:");
					service.view_all_user();
				}
					break;
				case 7:
					System.exit(0);
					logger.info("EXITED");
					break;
				case 4: {
					System.out
							.println("Hotel Management Tasks: \n1:Add Hotel\t 2:Delete Hotel\t 3:Modify Hotel ");
					int choice = s.nextInt();
					switch (choice) {
					case 1: {
						System.out.println("Enter the Details for The hotel");
						System.out.println("Name:");
						String name = s.next();
						hotel.setHotel_name(name);
						System.out.println("City:");
						String city = s.next();
						hotel.setCity(city);
						System.out.println("Address:");
						try {
							String address = bf.readLine();
							hotel.setAddress(address);
							System.out.println("Description:");
							String desc = bf.readLine();
							hotel.setDescription(desc);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							throw new hotelException(e.getMessage());
						}

						System.out.println("Average Rate Per night:");
						float rate = s.nextFloat();
						hotel.setAvg_rate_per_night(rate);
						System.out.println("Phone Number 1:");
						String phone1 = s.next();
						hotel.setPhone_no1(phone1);
						System.out.println("Phone Number 2:");
						String phone2 = s.next();
						hotel.setPhone_no2(phone2);
						System.out.println("Rating:");
						String rating = s.next();
						hotel.setRating(rating);
						System.out.println("Email:");
						String email = s.next();
						hotel.setEmail(email);
						System.out.println("Fax:");
						String fax = s.next();
						hotel.setFax(fax);

						service.add_hotel(hotel);

						System.out.println("Hotel ID for the added hotel is:"
								+ hotel.getHotel_id());

					}
						break;
					case 2: {
						System.out.println("Enter the hotel Id to be deleted");
						String id = s.next();
						service.delete_hotel(id);

						System.out.println("hotel with " + id + " is deleted");
					}
						break;

					case 3: {
						System.out.println("Enter the hotel Id to be modify");
						String id = s.next();
					}
						break;
					case 4: {

					}
						break;
					}

				}
					break;
				case 5: {
					System.out
							.println("Room Management Tasks: \n1:Add Hotel\t 2:Delete Hotel\t 3:Modify Hotel");
					int choice = s.nextInt();
					switch (choice) {
					case 1: {

					}
						break;
					}
					break;
				}

				}
			}
		} else {
			while (true) {
				System.out.println("\nPress 1 for all hotels");
				System.out.println("Press 2 for hotels w.r.t to city");
				System.out.println("Press 3 to do a Booking");
				System.out.println("Press 4 to show previous bookings");
				System.out.println("Press 5 to Exit");
				check = s.nextInt();
				switch (check) {

				case 1: {
					service.view_all_hotel();
				}
					break;
				case 2: {
					System.out.println("Enter the city:");
					String city = s.next();
					service.view_hotel_city(city);
				}
					break;
				case 3: {
					System.out
							.println("Enter the details asked for making a booking");

				}
					break;
				case 5:
					System.exit(0);

				}
			}
		}
	}

	public void register() throws hotelException {

		bf = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Register new user:");
		System.out.println("Enter name:");
		String user_name = s.next();
		user.setUser_name(user_name);
		System.out.println("Enter Password: ");
		String pass = s.next();
		user.setPassword(pass);
		System.out.println("Enter your role: (Employee/Customer)");
		String role = s.next();
		user.setRole(role);
		System.out.println("Enter phone number");
		String phone = s.next();
		user.setPhone(phone);
		System.out.println("Enter Address:");
		String address;
		try {
			address = bf.readLine();
			user.setAddress(address);
		} catch (IOException e) {
			throw new hotelException(e.getMessage());
		}

		System.out.println("Enter email:");
		String email = s.next();
		user.setEmail(email);
		if (user.getRole().equals("Admin")) {
			// service.register_new_admin(user);
			System.out.println("NO registration for Admin");
			uLogin.register();
		} else if (user.getRole().equals("Customer")) {
			service.register_new_customer(user);
		} else if (user.getRole().equals("Employee")) {
			service.register_new_employee(user);
		}

		System.out.println("User ID for you is:" + user.getUser_id()
				+ "\nNow you can login");

		uLogin.login();

	}

	public void login() throws hotelException {

		bf = new BufferedReader(new InputStreamReader(System.in));
		boolean flag = true;
		System.out.println("User ID:");
		String user_id = s.next();
		System.out.println("Password:");
		String password = s.next();
		user.setUser_id(user_id);
		user.setPassword(password);

		flag = service.checklogin(user);
		if (flag == true) {
			System.out.println("user exsists");
		} else {
			System.out.println("check again");
			System.out.println("Enter right credentials");
			System.out
					.println("Login if exsisting user or Register for further operations");
			System.out.println("Press 1 to login");
			System.out.println("Press 2 to Register");
			int login = s.nextInt();
			if (login == 1) {
				uLogin.login();
			} else {
				uLogin.register();
			}
		}
	}

}
