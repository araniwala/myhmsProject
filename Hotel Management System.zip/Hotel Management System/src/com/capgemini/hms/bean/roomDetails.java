package com.capgemini.hms.bean;

public class roomDetails {

	private String hotel_id;
	private String room_id;
	private String room_no;
	private String room_type;
	private float per_night_rate;
	private String availability;
	private String photo;

	public roomDetails() {
		super();
	}

	public roomDetails(String hotel_id, String room_id, String room_no,
			String room_type, float per_night_rate, String availability,
			String photo) {
		super();
		this.hotel_id = hotel_id;
		this.room_id = room_id;
		this.room_no = room_no;
		this.room_type = room_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;
		this.photo = photo;
	}

	public String getHotel_id() {
		return hotel_id;
	}

	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}

	public String getRoom_id() {
		return room_id;
	}

	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}

	public String getRoom_no() {
		return room_no;
	}

	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}

	public String getRoom_type() {
		return room_type;
	}

	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}

	public float getPer_night_rate() {
		return per_night_rate;
	}

	public void setPer_night_rate(float per_night_rate) {
		this.per_night_rate = per_night_rate;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

}
