package com.capgemini.hms.service;

import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.dao.HotelDaoImp;
import com.capgemini.hms.dao.IHotelDao;
import com.capgemini.hms.exception.hotelException;

public class HotelServiceImp implements IHotelService {

	IHotelDao hd = new HotelDaoImp();

	@Override
	public boolean checklogin(userDetails user) throws hotelException {

		return hd.checklogin(user);

	}

	@Override
	public void view_all_hotel() throws hotelException {
		hd.view_all_hotel();

	}

	@Override
	public void view_hotel_city(String city) throws hotelException {
		hd.view_hotel_city(city);

	}

	//@Override
	/*public void register_new_admin(userDetails user) throws hotelException {
		hd.register_new_admin(user);

	}*/

	@Override
	public void register_new_customer(userDetails user) throws hotelException {
		hd.register_new_customer(user);
	}

	@Override
	public void register_new_employee(userDetails user) throws hotelException {
		hd.register_new_employee(user);
	}

	@Override
	public void view_all_user() throws hotelException {
		hd.view_all_user();
	}

	@Override
	public void add_hotel(hotelDetails hotel) throws hotelException {
		hd.add_hotel(hotel);
	}

	@Override
	public void delete_hotel(String id) throws hotelException {
		hd.delete_hotel(id);
	}

}
