package com.capgemini.hms.service;


import com.capgemini.hms.bean.hotelDetails;
import com.capgemini.hms.bean.userDetails;
import com.capgemini.hms.exception.hotelException;



public interface IHotelService {

	public abstract boolean checklogin(userDetails user) throws hotelException;

	public abstract void view_all_hotel() throws hotelException;

	public abstract void view_hotel_city(String city) throws hotelException;

	//public abstract void register_new_admin(userDetails user) throws hotelException;

	public abstract void register_new_customer(userDetails user) throws hotelException;

	public abstract void register_new_employee(userDetails user) throws hotelException;

	public abstract void view_all_user() throws hotelException;

	public abstract void add_hotel(hotelDetails hotel) throws hotelException;

	public abstract void delete_hotel(String id) throws hotelException;

	
	

}
