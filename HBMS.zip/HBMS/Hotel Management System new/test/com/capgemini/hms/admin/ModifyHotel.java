package com.capgemini.hms.admin;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.hms.dao.HotelAdminDaoImp;
import com.capgemini.hms.dao.IHotelAdminDao;
import com.capgemini.hms.exception.HotelException;

public class ModifyHotel {
	IHotelAdminDao had = new HotelAdminDaoImp();
	@Test
	public void testModifyHotel() throws HotelException {
		String column_name="hotel_name";
		String hotel_name="oberoi amar";
		assertEquals(true, had.modifyHotel(hotel_name,column_name, "hot1"));
	}

	@Test
	public void testModifyHotel1() throws HotelException {
		String column_name="hotel_name";
		String hotel_name="oberoi amar";
		assertEquals(true, had.modifyHotel(hotel_name,column_name, "hot11"));
	}

}
