package com.capgemini.hms.management;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hms.UI.Hotel;
import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;
import com.capgemini.hms.login.LoginUsers;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

public class EmployeeManagement {

	static Scanner scanner = null;
	static BufferedReader buffer = null;
	static UserDetails user = null;
	static HotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static LoginUsers uLogin = null;
	static Logger logger = Logger.getRootLogger();
	static Management mngmt = null;
	static BookingDetails book = null;

	//------------------------ Hotel Management System --------------------------
		/*******************************************************************************************************
		 * - Function Name : employee 
		 * - Input Parameters : Scanner User Input 
		 * - Throws : hotelException 
		 * - Author : Anisha 
		 * - Creation Date : 03/09/2018 
		 * - Description : all the functionality related to employee are in this function.
		 ********************************************************************************************************/
	
	public void employee() throws HotelException {
		scanner = new Scanner(System.in);
		user = new UserDetails();
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		book = new BookingDetails();
		buffer = new BufferedReader(new InputStreamReader(System.in));
		int check = 0;
		String user_id = null;
		try {
			System.out.println("You are logged in as Employee");
			while (true) {
				System.out
						.println("--------------------------------------------------------------------------");
				System.out.println("||\tPress [1] for all hotels\t\t\t||");
				System.out
						.println("||\tPress [2] for hotels w.r.t to city\t\t||");
				System.out
						.println("||\tPress [3] to Make a booking for customer\t||");
				System.out
						.println("||\tPress [4] to view bookings of a customer\t||");
				System.out
						.println("||\tPress [5] to login as different user\t\t||");
				System.out.println("||\tPress [6] to exit\t\t\t\t||");
				System.out
						.println("--------------------------------------------------------------------------");

				check = scanner.nextInt();
				switch (check) {
				default: {
					System.out.println();
					System.out.format("\n%-40s","Enter valid option");
					employee();
				}
					break;
				case 1: {
					ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
					hotelDetail = service.viewAllHotel();
					if (hotelDetail == null) {
						System.out.println("no hotels");
					} else {
						System.out
								.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out
								.format("%-20s %-30s %-20s %-20s %-25s %-10s %-10s %-7s %-30s %-10s",
										"City", "Name", "Address",
										"Description",
										"Rate of room per night", "Phone 1",
										"Phone 2", "Rating", "E-mail", "Fax");
						System.out.println();
						System.out
								.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

						for (HotelDetails hotel1 : hotelDetail) {
							System.out
									.format("\n%-20s %-30s %-20s %-20s %-25s %-10s %-10s %-7s %-30s %-10s",
											hotel1.getCity(),
											hotel1.getHotel_name(),
											hotel1.getAddress(),
											hotel1.getDescription(),
											hotel1.getAvg_rate_per_night(),
											hotel1.getPhone_no1(),
											hotel1.getPhone_no2(),
											hotel1.getRating(),
											hotel1.getEmail(), hotel1.getFax());

						}
						System.out.println();
						System.out
								.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
					}
					System.out.println();

					logger.info("VIEWED ALL hotels");
				}
					break;
				case 2: {
					System.out.println("Enter the city:");
					String city = buffer.readLine();
					ArrayList<HotelDetails> hotelDetail = new ArrayList<>();
					hotelDetail = service.viewHotelByCity(city);
					if (hotelDetail == null) {
						System.out.println("no hotel in this city.");
						System.err.println("check again");
					} else {
						System.out
								.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out
								.format("%-20s %-30s %-20s %-20s %-25s %-10s %-10s %-7s %-30s %-10s",
										"City", "Name", "Address",
										"Description",
										"Rate of room per night", "Phone 1",
										"Phone 2", "Rating", "E-mail", "Fax");
						System.out.println();
						System.out
								.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

						for (HotelDetails hotel1 : hotelDetail) {
							System.out
									.format("\n%-20s %-30s %-20s %-20s %-25s %-10s %-10s %-7s %-30s %-10s",
											hotel1.getCity(),
											hotel1.getHotel_name(),
											hotel1.getAddress(),
											hotel1.getDescription(),
											hotel1.getAvg_rate_per_night(),
											hotel1.getPhone_no1(),
											hotel1.getPhone_no2(),
											hotel1.getRating(),
											hotel1.getEmail(), hotel1.getFax());
						}
						System.out.println();
						System.out
								.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

					}
					logger.info("VIEWED ALL HOTELS by city");
				}
					break;
				case 5: {
					String[] args = null;
					// System.exit(0);
					Hotel.main(args);
				}
					break;
				case 6:
					System.exit(0);

					break;
				case 3: {
					System.out
							.println("||\tChoose the options to make a booking:\t||");
					booking(user_id);
					logger.info("booking made");
				}
					break;
				case 4: {
					ArrayList<BookingDetails> booking = new ArrayList<>();
					System.out.println("Enter the customer ID:");
					String custid = buffer.readLine();
					while (service.isValidUser(custid) == false) {
						System.out.println("Enter valid customer id:");
						custid = buffer.readLine();
					}
					booking = service.viewBooking(custid);
					if (booking == null) {
						System.out.println("No bookings done");
					} else {
						System.out.println("Bookings made are:");
						System.out
								.format("\n%-10s %-10s %-10s %-15s %-15s %-20s %-20s %-12s",
										"Booking ID", "Room ID", "User ID",
										"Booked From", "Booked till",
										"No of adults", "No of children",
										"Amount");
						System.out.println();
						System.out
								.println("------------------------------------------------------------------------------------------------------------------------");

						for (BookingDetails book : booking) {

							System.out
									.format("\n%-10s %-10s %-10s %-15s %-15s %-20s %-20s %-12s",
											book.getBooking_id(),
											book.getRoom_id(),
											book.getUser_id(),
											book.getBooked_from(),
											book.getBooked_to(),
											book.getNo_of_adults(),
											book.getNo_of_children(),
											book.getAmount());
						}
						System.out.println();
						logger.info("booking status viewed");
					}
				}
				}

			}
		} catch (InputMismatchException e) {
			logger.error(e);
			System.err.println("Check again");
			employee();
		} catch (IOException e) {
			logger.error(e);
			System.err.println("check again");
			employee();
		}
	}

	//------------------------ Hotel Management System --------------------------
		/*******************************************************************************************************
		 * - Function Name : booking
		 * - Input Parameters : Scanner User Input 
		 * - Throws : hotelException 
		 * - Author : Anisha 
		 * - Creation Date : 03/09/2018 
		 * - Description : all the functionality related to booking a room for a customer are in this function.
		 ********************************************************************************************************/
	
	public void booking(String user_id) throws HotelException {
		scanner = new Scanner(System.in);
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		book = new BookingDetails();
		buffer = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out
					.println("--------------------------------------------------------------------------");
			System.out.println("||Press [1] to show rooms by hotel name\t||");
			System.out.println("||Press [2] to show rooms by type||");
			System.out.println("||Press [3] to exit||");
			System.out
					.println("--------------------------------------------------------------------------");
			int option1 = scanner.nextInt();
			switch (option1) {
			case 1: {
				System.out
						.println("Enter the hotel name in which you need rooms");
				ArrayList<RoomDetails> roomdetails = new ArrayList<>();

				String name = buffer.readLine();
				roomdetails = service.viewRoomHotel(name);
				if (roomdetails == null) {
					System.out.println("No rooms in this hotel.");
				} else {

					System.out.format("\n%-10s %-12s %-20s %30s", "Room id",
							"Room number", "Room Type", "Room rate per night");
					System.out.println();
					System.out
							.println("------------------------------------------------------------------------------------------");
					for (RoomDetails room : roomdetails) {
						System.out.format("\n%-10s %-12s %-20s %30s",
								room.getRoom_id(), room.getRoom_no(),
								room.getRoom_type(), room.getPer_night_rate());

					}
					System.out.println();
					System.out
							.println("||Press [1] to book user selected room\t||");
					System.out.println("|| Press anything else to go back\t||");
					int option = scanner.nextInt();
					if (option == 1)
						makeBooking(user_id);
					else
						booking(user_id);
				}

			}
				break;
			case 2: {
				ArrayList<RoomDetails> roomdetails = new ArrayList<>();
				System.out.println("Select one of the room types:");
				System.out
						.println("[1] AC-Delux\t[2] Non-AC-Delux\t[3] AC-standard\t[4] Non-AC-standard");
				int option = scanner.nextInt();
				if (option == 1)
					roomdetails = service.roomTypeAvailable("AC-Delux");
				else if (option == 2)
					roomdetails = service.roomTypeAvailable("Non-AC-Delux");
				else if (option == 3)
					roomdetails = service.roomTypeAvailable("AC-standard");
				else if (option == 4)
					roomdetails = service.roomTypeAvailable("Non-AC-standard");
				else
					System.out.println("select a valid option");

				if (roomdetails == null) {
					System.out.println("No rooms in this hotel.");
				} else {
					System.out.format("\n%-10s %-12s %-20s %30s", "Room id",
							"Room number", "Room Type", "Room rate per night");
					System.out.println();
					System.out
							.println("------------------------------------------------------------------------------------------");
					
					for (RoomDetails room : roomdetails) {
						System.out.format("\n%-10s %-12s %-20s %30s",
								room.getRoom_id(), room.getRoom_no(),
								room.getRoom_type(), room.getPer_night_rate());

					}
					System.out.println();
					System.out.println();
					System.out
					.println("------------------------------------------------------------------------------------------");
			
					System.out
							.println("||Press [1] to book user selected room\t||");
					System.out.println("|| Press anything else to go back\t||");
					System.out
					.println("------------------------------------------------------------------------------------------");
			
					int option2 = scanner.nextInt();
					if (option2 == 1)
						makeBooking(user_id);
					else
						booking(user_id);
				}

			}
				break;
			case 3: {
				booking(user_id);
			}
				break;
			}
		} catch (InputMismatchException e) {
			logger.error(e);
			System.out.println("check again");
			employee();
		} catch (IOException e) {
			logger.error(e);
			System.out.println("check again");
			employee();
		}
	}

	public void makeBooking(String user_id) throws HotelException {
		scanner = new Scanner(System.in);
		user = new UserDetails();
		service = new HotelServiceImp();
		uLogin = new LoginUsers();
		hotel = new HotelDetails();
		s_admin = new HotelAdminServiceImp();
		mngmt = new Management();
		book = new BookingDetails();
		buffer = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Enter the customer ID:");
			String custid = buffer.readLine();
			if (service.checkUserId(custid) == false) {
				System.out
						.println("The customer is not registered.\nFirst complete the registration.");
				uLogin.register();

			} else {
				book.setUser_id(custid);
				System.out.println("Enter the room Id you want to book");
				String room_id = buffer.readLine();
				book.setRoom_id(room_id);
				System.out.println("Enter the date to book from (dd/mm/yyyy)");
				String startDate = buffer.readLine();
				while (service.isValidDate(startDate) == false) {
					System.out
							.println("Enter valid Date in the given format: (dd/mm/yyyy)");
					startDate = buffer.readLine();
				}
				LocalDate date = service.dateChange(startDate);
				if (date.isEqual(LocalDate.now())
						|| date.isAfter(LocalDate.now())) {
					book.setBooked_from(date);
				} else {
					System.out
							.println("Booking intial date should be today or date after today");
					startDate = buffer.readLine();
					while (service.isValidDate(startDate) == false) {
						System.out
								.println("Enter valid Date in the given format: (dd/mm/yyyy)");
						startDate = buffer.readLine();
					}
				}
				System.out.println("Enter the date to book till (dd/mm/yyyy)");
				String endDate = buffer.readLine();
				while (service.isValidDate(endDate) == false) {
					System.out
							.println("Enter valid Date in the given format: (dd/mm/yyyy)");
					endDate = buffer.readLine();
				}
				LocalDate to_date = service.dateChange(endDate);
				if (to_date.isEqual(date) || to_date.isBefore(date)) {
					System.out
							.println("Booking till date should be one or more day(s) after booking date");
					startDate = buffer.readLine();
					while (service.isValidDate(startDate) == false) {
						System.out
								.println("Enter valid Date in the given format: (dd/mm/yyyy)");
						startDate = buffer.readLine();
					}
				} else {

					book.setBooked_to(service.dateChange(endDate));
				}
				System.out.println("enter the number of adults");
				int no_adult = scanner.nextInt();
				book.setNo_of_adults(no_adult);
				System.out.println("Enter the number of children");
				int no_child = scanner.nextInt();
				book.setNo_of_children(no_child);
				book.setUser_id(user_id);
				String book_id = service.bookRoom(book);
				if (book_id == null) {
					System.out.println("this room is booked try another dates");
				}
				System.out
						.println("------------------------------------------------------------");
				System.out.println("your booking id is:" + book_id);
				System.out.println("You've booked the room from: "
						+ book.getBooked_from() + " to:" + book.getBooked_to()
						+ " for amount: " + book.getAmount() + " for "
						+ book.getNo_of_adults() + " adults and "
						+ book.getNo_of_children() + " children.");
				System.out
						.println("------------------------------------------------------------");

			}

		} catch (InputMismatchException e) {
			logger.error(e);
			System.out.println("check again");
			makeBooking(user_id);
		} catch (IOException e) {
			logger.error(e);
			System.out.println("check again");
			makeBooking(user_id);
		}
	}
}
