package com.capgemini.hms.test;

import static org.junit.Assert.*;


import org.junit.Test;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.dao.HotelDaoImp;
import com.capgemini.hms.dao.IHotelDao;
import com.capgemini.hms.exception.HotelException;

public class Booking {

	
	IHotelDao hd=new HotelDaoImp();
	@Test
	public void testBookRoom() throws HotelException{
		BookingDetails book=new BookingDetails("room4","cus1",hd.dateChange("10/09/2018"),hd.dateChange("11/09/2018"),2,2,5000);
		assertSame(book.getBooking_id(),hd.bookRoom(book));
	}

	
	@Test
	public void testBookRoom1() throws HotelException{
		BookingDetails book=new BookingDetails("room4","cus1",hd.dateChange("10/09/2018"),hd.dateChange("11/09/2018"),2,2,5000);
		assertSame("100022",hd.bookRoom(book));
	}
}
