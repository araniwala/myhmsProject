package com.capgemini.hms.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.dao.HotelDaoImp;
import com.capgemini.hms.dao.IHotelDao;
import com.capgemini.hms.exception.HotelException;

public class Login {
	IHotelDao hd = new HotelDaoImp();
	@Test
	public void testCheckLogin() throws HotelException {
		String user_id="cus1";
		String password="cherry";
		UserDetails user=new UserDetails(user_id,password);
		assertEquals(true,hd.checkLogin(user));
	}

	@Test
	public void testCheckLogin1() throws HotelException {
		String user_id="cus5";
		String password="cherry";
		UserDetails user=new UserDetails(user_id,password);
		assertEquals(true,hd.checkLogin(user));
	}
}
