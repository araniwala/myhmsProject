package com.capgemini.hms.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;

//------------------------ Hotel Management System --------------------------
	/*******************************************************************************************************
	 - Interface Name	:	IHotelAdminDao (Dao interface for Admin)
	 - Throws			:  	hotelException
	 - Author			:	Anisha
	 - Creation Date	:	03/09/2018
	 - Description		:	function signature for Admin.
	 ********************************************************************************************************/

public interface IHotelAdminDao {

	

	

	public abstract ArrayList<HotelDetails> viewAllHotel() throws HotelException;

	public abstract ArrayList<UserDetails> viewAllUser() throws HotelException;

	public abstract void addHotel(HotelDetails hotel) throws HotelException;

	public abstract boolean deleteHotel(String id) throws HotelException;

	public abstract ArrayList<RoomDetails> roomView(String h_id) throws HotelException;

	public abstract ArrayList<String> displayIds() throws HotelException;

	public abstract void addRoom(RoomDetails room) throws HotelException;

	public abstract boolean deleteRoom(String room_id) throws HotelException;

	public abstract ArrayList<BookingDetails> viewBooking(String hotel_id) throws HotelException;

	public abstract ArrayList<BookingDetails> viewByDate(LocalDate dateChange) throws HotelException;

	public abstract ArrayList<String[]> guestList(String hotel_id) throws HotelException;

	public abstract boolean modifyHotel(String modify, String name,String id) throws HotelException;

	public abstract HotelDetails viewHotelById(String hotel_id) throws HotelException;

	public abstract void modifyRoom(String room_id, String room_no,
			String column_name) throws HotelException;

	public abstract RoomDetails viewRoomById(String room_id) throws HotelException;



	
	
}
