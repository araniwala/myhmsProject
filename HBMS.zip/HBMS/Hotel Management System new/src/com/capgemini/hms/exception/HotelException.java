package com.capgemini.hms.exception;

//------------------------ Hotel Management System --------------------------
	/*******************************************************************************************************
	 * - Function Name : HotelException 
	 * - Input Parameters : String message 
	 * - Author : Anisha 
	 * - Creation Date : 03/09/2018 
	 * - Description : user defined exception.
	 ********************************************************************************************************/

public class HotelException extends Exception {

	
	private static final long serialVersionUID = 1L;
	
	public HotelException(String message)
	{
		super(message);
	}

	
}
