package com.capgemini.hms.login;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hms.UI.Hotel;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.exception.HotelException;
import com.capgemini.hms.management.Management;
import com.capgemini.hms.service.HotelAdminServiceImp;
import com.capgemini.hms.service.HotelServiceImp;
import com.capgemini.hms.service.IHotelAdminService;
import com.capgemini.hms.service.IHotelService;

public class LoginUsers {

	static Scanner scanner = null;
	static BufferedReader buffer = null;
	static UserDetails user = new UserDetails();
	static HotelDetails hotel = null;
	static IHotelService service = null;
	static IHotelAdminService s_admin = null;
	static LoginUsers uLogin = null;
	static Logger logger = Logger.getRootLogger();
	static Management mngmt = null;

	// ------------------------ Hotel Management System
	// --------------------------
	/*******************************************************************************************************
	 * - Function Name : Register function - Input Parameters : Scanner User
	 * Input - Throws : hotelException - Author : Anisha - Creation Date :
	 * 03/09/2018 - Description : Registers a new user and displays the user ID
	 * to the user.
	 ********************************************************************************************************/

	public String register() throws HotelException {
		try {
			buffer = new BufferedReader(new InputStreamReader(System.in));
			scanner = new Scanner(System.in);
			service = new HotelServiceImp();
			uLogin = new LoginUsers();
			hotel = new HotelDetails();
			s_admin = new HotelAdminServiceImp();
			String code = "";
			System.out.println("Register new user:");
			System.out.format("\n%-40s=","Enter your name:(max: 20 characters)");
			String user_name;
			user_name = buffer.readLine();
			while (service.isValidUserName(user_name) == false) {
				System.out.format("\n%-40s=","Enter valid name:");
				user_name = buffer.readLine();

			}
			user.setUser_name(user_name);

			System.out.format("\n%-40s=","Enter Password:(max: 7 characters) ");
			String pass = buffer.readLine();
			while (service.isValidPassword(pass) == false) {
				System.out.format("\n%-40s=","Enter valid passowrd");
				pass =  buffer.readLine();
			}
			user.setPassword(pass);

			System.out.format("\n%-40s=","Enter phone number");
			String phone = buffer.readLine();
			while (service.isValidNumber(phone) == false) {
				System.out.format("\n%-40s=","Enter valid phone number");
				phone = buffer.readLine();
			}
			user.setPhone(phone);
			System.out.format("\n%-40s=","Enter Address(50 characters):");
			String address = buffer.readLine();
			while (service.isValidAddress(address) == false) {
				System.out.format("\n%-40s=","Enter valid address");
				address = buffer.readLine();
			}
			user.setAddress(address);

			System.out.format("\n%-40s=","Enter email:");
			String email = buffer.readLine();
			while (service.isValidEmail(email) == false) {
				System.out.format("\n%-40s=","Enter valid email");
				email = buffer.readLine();
			}
			user.setEmail(email);
			System.out
					.format("\n%-60s=","Choose your role: (Choose one:\n[1]:Employee [2]:Customer)");
			String role = buffer.readLine();
			if (!role.equals("2") && !role.equals("1")) {
				System.out
						.format("\n%-60s=","Choose your role: (Choose one:\n[1]:Employee [2]:Customer)");
				role = buffer.readLine();
			}
			else if (role.equals("1")) {
				user.setRole("Employee");
				System.out.format("\n%-40s=","Enter the code:");
				code = buffer.readLine();
				if (code.equals("admin")) {
					System.out.println("correct code.");
				} else {
					System.out.println("incorrect code. Try Again.");
					uLogin.register();
				}
			} else if (role.equals("2")) {
				user.setRole("Customer");
			}

			if (user.getRole().equals("Customer")) {
				service.registerNewCustomer(user);
			} else if (user.getRole().equals("Employee")) {
				service.registerNewEmployee(user);
			}

		} catch (InputMismatchException e) {
			logger.error(e);
			System.out.println("You are logged out");
			String[] args = null;
			Hotel.main(args);
		} catch (IOException e) {
			logger.error(e);
			System.out.println("You are logged out");
			String[] args = null;
			Hotel.main(args);
		}
		return user.getUser_id();
	}

	// ------------------------ Hotel Management System
	// --------------------------
	/*******************************************************************************************************
	 * - Function Name : Login function - Input Parameters : Scanner User Input
	 * - Throws : hotelException - Author : Anisha - Creation Date : 03/09/2018
	 * - Description : Logins an existing user and shows warning when the user
	 * is not found.
	 ********************************************************************************************************/

	public String login() throws HotelException {
		String user_id = null;
		try {
			buffer = new BufferedReader(new InputStreamReader(System.in));
			scanner = new Scanner(System.in);
			service = new HotelServiceImp();
			uLogin = new LoginUsers();
			hotel = new HotelDetails();
			s_admin = new HotelAdminServiceImp();

			boolean flag = true;
			System.out.print("User ID:");
			user_id = buffer.readLine();
			System.out.print("Password:");
			String password = buffer.readLine();
			user.setUser_id(user_id);
			user.setPassword(password);
			flag = service.checkLogin(user);
			if (flag == false) {
				System.err.println("!----check again----!");
				System.err.println("!--Enter right credentials--!");
				logger.error("wrong user id or password");
				System.out
						.println("--------------------------------------------------");
				System.out.println("||\t\tPress [1] to login\t\t||");
				System.out.println("||\t\tPress [2] to Register\t\t||");
				System.out.println("||\t\tPress [3] to Exit\t\t||");
				System.out
						.println("--------------------------------------------------");
				int login = scanner.nextInt();
				if (login == 1) {
					uLogin.login();
				} else if (login == 2) {
					uLogin.register();
				} else
					System.exit(0);

			}
		} catch (InputMismatchException e) {
			logger.error(e);
			System.out.println("Enter the right option");
			String[] args = null;
			Hotel.main(args);
		} catch (IOException e) {
			logger.error(e);
			System.err.println("check again");
			String[] args = null;
			Hotel.main(args);
		}
		return user_id;
	}
}
