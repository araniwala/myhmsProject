package com.capgemini.hms.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.hms.bean.BookingDetails;
import com.capgemini.hms.bean.HotelDetails;
import com.capgemini.hms.bean.RoomDetails;
import com.capgemini.hms.bean.UserDetails;
import com.capgemini.hms.dao.HotelAdminDaoImp;
import com.capgemini.hms.dao.IHotelAdminDao;
import com.capgemini.hms.exception.HotelException;

public class HotelAdminServiceImp implements IHotelAdminService{

	IHotelAdminDao hd1 = new HotelAdminDaoImp();
	IHotelService hs=new HotelServiceImp();
	@Override
	public boolean checkLogin(UserDetails user) throws HotelException {
		return false;
	}

	@Override
	public ArrayList<HotelDetails> viewAllHotel() throws HotelException {
		return hd1.viewAllHotel();
	}

	@Override
	public ArrayList<HotelDetails> viewHotelByCity(String city) throws HotelException {
		if (hs.isValidName(city) == true)
			return hs.viewHotelByCity(city);
		else
			return null;
	}

	@Override
	public ArrayList<UserDetails> viewAllUser() throws HotelException {
		return hd1.viewAllUser();
	}

	@Override
	public void addHotel(HotelDetails hotel) throws HotelException {
		hd1.addHotel(hotel);
	}

	@Override
	public boolean deleteHotel(String id) throws HotelException {
		return hd1.deleteHotel(id);
	}

	@Override
	public ArrayList<RoomDetails> roomView(String h_id) throws HotelException {
		
		return hd1.roomView(h_id);
	}

	@Override
	public ArrayList<String> displayIds() throws HotelException {
		 return hd1.displayIds();
	}

	@Override
	public void addRoom(RoomDetails room) throws HotelException {
		hd1.addRoom(room);
	}

	@Override
	public boolean deleteRoom(String room_id) throws HotelException {
		return hd1.deleteRoom(room_id);
	}

	@Override
	public ArrayList<BookingDetails> viewBooking(String hotel_id) throws HotelException {
		return hd1.viewBooking(hotel_id);
	}

	@Override
	public ArrayList<BookingDetails> viewByDate(LocalDate dateChange) throws HotelException {
		return hd1.viewByDate(dateChange);
	}

	@Override
	public ArrayList<String[]> guestList(String hotel_id) throws HotelException {
		return hd1.guestList(hotel_id);
	}

	@Override
	public HotelDetails viewHotelById(String hotel_id) throws HotelException {
		return hd1.viewHotelById(hotel_id);
	}

	@Override
	public boolean modifyHotel(String modify,String name,String id)
			throws HotelException {
		return hd1.modifyHotel(modify,name,id);
	}

	@Override
	public void modifyRoom(String room_id, String modify, String column_name)
			throws HotelException {
		hd1.modifyRoom(room_id,modify,column_name);
	}

	@Override
	public RoomDetails viewRoomById(String room_id) throws HotelException {
		return hd1.viewRoomById(room_id);
	}



}
